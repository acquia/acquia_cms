<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* sites/default/files/cohesion/templates/component--cohesion-316b920d.html.twig */
class __TwigTemplate_db4a09bc1b8bdc03cc702d4f21986b760ce7010fcf5660d3e2329feb0f84e06c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohInstanceId(), "html", null, true);
        $context["coh_instance_class"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        if ((($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->hasDrupalPermission([0 => "access contextual links", 1 => "access components"]) &&  !($context["isPreview"] ?? null)) &&  !(isset($context["hideContextualLinks"]) || array_key_exists("hideContextualLinks", $context)))) {
            echo " <div class=\"dx-contextual-region contextual-region\" data-dx-contextual=\"coh-component-instance-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source), "html", null, true);
            echo "\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 3, $this->source), "html", null, true);
            echo "</div> ";
        }
        echo " <div class=\"coh-container coh-component coh-component-instance-";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source), "html", null, true);
        echo " contextual-component background-container ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "95b63b8f-f4af-42c2-97ae-c09517d6ca44"));
        echo " coh-ce-316b920d-3371787b\" > <div class=\"coh-container ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "6bd34f95-d8e4-4b68-8708-35ec046a5371"));
        echo "\" > <div class=\"coh-container ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "c5f15640-a350-4d59-94f9-f6b39408ad2d"));
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 3, $this->source), "html", null, true);
        echo " coh-ce-316b920d-315e667d\" > <div class=\"coh-container ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "95b63b8f-f4af-42c2-97ae-c09517d6ca44"));
        echo " dx8-parallax ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 3, $this->source), "html", null, true);
        echo " coh-ce-316b920d-a813a4ea\" data-coh-paroller=\"{&quot;xl&quot;:{&quot;factor&quot;:&quot;&quot;,&quot;type&quot;:&quot;background&quot;,&quot;direction&quot;:&quot;vertical&quot;,&quot;bgstart&quot;:&quot;&quot;,&quot;enabled&quot;:&quot;background&quot;}}\" > </div> ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "ae0e0859-e597-4acd-a0ad-7e63526b4624"), "html", null, true);
        echo " </div> </div> </div> 
";
        // line 4
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 4, $this->source));
        }
        ob_start(function () { return ''; });
        echo "<style>.";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 4, $this->source), "html", null, true);
        echo ".coh-ce-316b920d-315e667d { width: 100%; ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "3df021b2-3541-47b9-afb4-140ba9ac93b4"))) {
            echo " min-height: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "3df021b2-3541-47b9-afb4-140ba9ac93b4"));
            echo ";";
        }
        echo " display: -webkit-box; display: -webkit-flex; display: -ms-flexbox; display: flex; -webkit-flex-wrap: wrap; -ms-flex-wrap: wrap; flex-wrap: wrap; ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "10c8566a-18cd-4d55-9dcb-71389a3f8e33"))) {
            echo " -webkit-box-align: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "10c8566a-18cd-4d55-9dcb-71389a3f8e33"));
            echo ";";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "10c8566a-18cd-4d55-9dcb-71389a3f8e33"))) {
            echo " -webkit-align-items: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "10c8566a-18cd-4d55-9dcb-71389a3f8e33"));
            echo ";";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "10c8566a-18cd-4d55-9dcb-71389a3f8e33"))) {
            echo " -ms-flex-align: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "10c8566a-18cd-4d55-9dcb-71389a3f8e33"));
            echo ";";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "10c8566a-18cd-4d55-9dcb-71389a3f8e33"))) {
            echo " align-items: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "10c8566a-18cd-4d55-9dcb-71389a3f8e33"));
            echo ";";
        }
        echo " }

@media (max-width: 73.0625rem) { .";
        // line 6
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 6, $this->source), "html", null, true);
        echo ".coh-ce-316b920d-315e667d { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "0d534562-e619-4eaa-9490-cb024b552930"))) {
            echo " min-height: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "0d534562-e619-4eaa-9490-cb024b552930"));
            echo ";";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "79f871d3-21ca-4bfd-83b9-0cf073c60e70"))) {
            echo " padding: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "79f871d3-21ca-4bfd-83b9-0cf073c60e70"));
            echo ";";
        }
        echo " } }

@media (max-width: 63.9375rem) { .";
        // line 8
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 8, $this->source), "html", null, true);
        echo ".coh-ce-316b920d-315e667d { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "0d534562-e619-4eaa-9490-cb024b552930"))) {
            echo " min-height: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "0d534562-e619-4eaa-9490-cb024b552930"));
            echo ";";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "79f871d3-21ca-4bfd-83b9-0cf073c60e70"))) {
            echo " padding: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "79f871d3-21ca-4bfd-83b9-0cf073c60e70"));
            echo ";";
        }
        echo " } }

@media (max-width: 47.9375rem) { .";
        // line 10
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 10, $this->source), "html", null, true);
        echo ".coh-ce-316b920d-315e667d { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b"))) {
            echo " min-height: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b"));
            echo ";";
        }
        echo " } }

@media (max-width: 35.25rem) { .";
        // line 12
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 12, $this->source), "html", null, true);
        echo ".coh-ce-316b920d-315e667d { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "97212711-6b24-4f8c-918c-f61599c9b42b"))) {
            echo " padding: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "97212711-6b24-4f8c-918c-f61599c9b42b"));
            echo ";";
        }
        echo " } }
.";
        // line 13
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 13, $this->source), "html", null, true);
        echo ".coh-ce-316b920d-a813a4ea { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "48678110-97bf-4d83-9e51-f6da6ca57d5d"))) {
            echo " background-image: url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "48678110-97bf-4d83-9e51-f6da6ca57d5d"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "banner") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 13, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 13, $this->source)), "html", null, true);
            echo "\");";
        }
        echo " ";
        if (( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "a4303ec9-6dd6-4704-ab90-93b31448da49")) &&  !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "4c5b3681-938c-4edc-be29-00d9f0de0e35")))) {
            echo " background-position: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "a4303ec9-6dd6-4704-ab90-93b31448da49"));
            echo " ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "4c5b3681-938c-4edc-be29-00d9f0de0e35"));
            echo ";";
        }
        echo " background-size: cover; background-repeat: no-repeat; position: absolute; top: 0; bottom: 0; left: 0; right: 0; ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "8cd16587-61fa-47a7-a977-9a051af471c1"))) {
            echo " background-color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "8cd16587-61fa-47a7-a977-9a051af471c1"));
            echo ";";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "028cf87b-ada9-4c88-880d-7dd19de841bd"))) {
            echo " -webkit-filter: blur(";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "028cf87b-ada9-4c88-880d-7dd19de841bd"));
            echo ");";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "028cf87b-ada9-4c88-880d-7dd19de841bd"))) {
            echo " filter: blur(";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "028cf87b-ada9-4c88-880d-7dd19de841bd"));
            echo ");";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "301ad76b-785d-4615-af93-ce27b0968b26"))) {
            echo " opacity: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "301ad76b-785d-4615-af93-ce27b0968b26"));
            echo ";";
        }
        echo " z-index: -1; margin-top: -5px; margin-right: -5px; margin-bottom: -5px; margin-left: -5px; }

@media (max-width: 63.9375rem) { .";
        // line 15
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 15, $this->source), "html", null, true);
        echo ".coh-ce-316b920d-a813a4ea { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "48678110-97bf-4d83-9e51-f6da6ca57d5d"))) {
            echo " background-image: url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "48678110-97bf-4d83-9e51-f6da6ca57d5d"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "banner") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 15, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 15, $this->source)), "html", null, true);
            echo "\");";
        }
        echo " ";
        if (( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "933b8d97-ab50-494e-baec-eb8d733ca385")) &&  !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "6880626d-57df-49eb-9212-fb43231ce51c")))) {
            echo " background-position: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "933b8d97-ab50-494e-baec-eb8d733ca385"));
            echo " ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "6880626d-57df-49eb-9212-fb43231ce51c"));
            echo ", left top;";
        }
        echo " background-size: cover, auto; background-repeat: no-repeat, no-repeat; background-origin: border-box; background-clip: border-box; background-attachment: scroll; } }

@media (max-width: 35.25rem) { .";
        // line 17
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 17, $this->source), "html", null, true);
        echo ".coh-ce-316b920d-a813a4ea { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "48678110-97bf-4d83-9e51-f6da6ca57d5d"))) {
            echo " background-image: url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "48678110-97bf-4d83-9e51-f6da6ca57d5d"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "banner") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 17, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 17, $this->source)), "html", null, true);
            echo "\");";
        }
        echo " ";
        if (( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "030c9f3a-e75f-4900-ae69-c4492eaadc08")) &&  !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "a501d536-f42f-474f-a866-7a4b01d9494a")))) {
            echo " background-position: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "030c9f3a-e75f-4900-ae69-c4492eaadc08"));
            echo " ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "a501d536-f42f-474f-a866-7a4b01d9494a"));
            echo ";";
        }
        echo " background-size: cover; background-repeat: no-repeat; } }
</style>";
        $context["compiledCSS"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 18
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderInlineStyle($this->sandbox->ensureToStringAllowed(($context["compiledCSS"] ?? null), 18, $this->source)));
    }

    public function getTemplateName()
    {
        return "sites/default/files/cohesion/templates/component--cohesion-316b920d.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  272 => 18,  249 => 17,  226 => 15,  179 => 13,  169 => 12,  158 => 10,  141 => 8,  124 => 6,  84 => 4,  46 => 3,  43 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "sites/default/files/cohesion/templates/component--cohesion-316b920d.html.twig", "/home/ide/project/docroot/sites/default/files/cohesion/templates/component--cohesion-316b920d.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "if" => 3);
        static $filters = array("escape" => 1, "raw" => 3, "render" => 4);
        static $functions = array("coh_instanceid" => 1, "attach_library" => 3, "has_drupal_permission" => 3, "getComponentFieldValue" => 3, "cohesion_image_style" => 13, "renderInlineStyle" => 18);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['escape', 'raw', 'render'],
                ['coh_instanceid', 'attach_library', 'has_drupal_permission', 'getComponentFieldValue', 'cohesion_image_style', 'renderInlineStyle']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
