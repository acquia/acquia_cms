<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* sites/default/files/cohesion/templates/views-view--cohesion-view-tpl-articles.html.twig */
class __TwigTemplate_ee86ba6992d75e888cb6c86487145645a95ff3648e1db8396594c5831263918e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.accordion-tabs-container"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.row-for-columns"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.drupal-view"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["elementClasses"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["extraClasses"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["classes"] = [0 => "view", 1 => ("view-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["view"] ?? null), "id", [], "any", false, false, true, 1), 1, $this->source))), 2 => ("view-id-" . $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["view"] ?? null), "id", [], "any", false, false, true, 1), 1, $this->source)), 3 => ("view-display-id-" . $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["view"] ?? null), "display_id", [], "any", false, false, true, 1), 1, $this->source)), 4 => ((twig_get_attribute($this->env, $this->source, ($context["view"] ?? null), "dom_id", [], "any", false, false, true, 1)) ? (("js-view-dom-id-" . $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["view"] ?? null), "dom_id", [], "any", false, false, true, 1), 1, $this->source))) : ("")), 5 => "coh-view", 6 => ($context["elementClasses"] ?? null), 7 => ($context["extraClasses"] ?? null)];
        echo " <div ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => ($context["classes"] ?? null)], "method", false, false, true, 1), 1, $this->source), "html", null, true);
        echo "  > ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->setViewIterate($context), "html", null, true);
        echo " ";
        $context["view_rows"] = twig_length_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["view"] ?? null), "result", [], "any", false, false, true, 1), 1, $this->source));
        echo " <div> <h1 class=\"coh-heading\"> ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[view:title]", ["view" => ($context["view"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 1, $this->source), true), "html", null, true);
        echo " </h1> ";
        if (($context["empty"] ?? null)) {
            echo " ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["empty"] ?? null), 1, $this->source), "html", null, true);
            echo " ";
        }
        echo " <div class=\"coh-row coh-row-xl coh-row-visible-xl\" data-coh-row-match-heights=\"{&quot;xl&quot;:{&quot;target&quot;:&quot;none&quot;}}\"> <div class=\"coh-row-inner default-listing-view coh-ce-5cbe1723\"> <div class=\"coh-column coh-style-margin-bottom-small coh-visible-sm coh-col-sm-12 coh-visible-md coh-col-md-4 coh-visible-xl coh-col-xl-3\" > <div class=\"coh-accordion-tabs\"> <div class=\"coh-accordion-tabs-inner coh-accordion-tabs-horizontal-left coh-accordion-tabs-display-accordion-xl coh-style-accordion-tabs-solid\" data-coh-accordion=\"{&quot;title&quot;:&quot;Accordion tabs container&quot;,&quot;styles&quot;:{&quot;xl&quot;:{&quot;accordionOrTab&quot;:&quot;accordion&quot;,&quot;collapsible&quot;:true,&quot;startCollapsed&quot;:false,&quot;animation&quot;:&quot;slide&quot;,&quot;offsetPositionAgainst&quot;:&quot;px&quot;,&quot;duration&quot;:400,&quot;active&quot;:1,&quot;scrollToAccordionOffset&quot;:0,&quot;accordionTabWidth&quot;:-2,&quot;accordionTabBleed&quot;:&quot;retain_gutters&quot;},&quot;sm&quot;:{&quot;startCollapsed&quot;:true}},&quot;scrollToAccordion&quot;:false,&quot;setHash&quot;:false,&quot;horizontalVertical&quot;:&quot;horizontal_top&quot;,&quot;HorizontalPosition&quot;:&quot;left_aligned&quot;,&quot;VerticalPosition&quot;:&quot;left&quot;,&quot;settings&quot;:{&quot;styles&quot;:{&quot;xl&quot;:{&quot;accordionOrTab&quot;:&quot;accordion&quot;,&quot;collapsible&quot;:true,&quot;animation&quot;:&quot;slide&quot;,&quot;duration&quot;:700,&quot;startCollapsed&quot;:false,&quot;active&quot;:1,&quot;offsetPositionAgainst&quot;:&quot;px&quot;,&quot;scrollToAccordionOffset&quot;:0}},&quot;scrollToAccordion&quot;:false,&quot;setHash&quot;:false,&quot;horizontalVertical&quot;:&quot;horizontal_top&quot;,&quot;HorizontalPosition&quot;:&quot;left_aligned&quot;},&quot;customStyle&quot;:null}\"> <ul class=\"coh-accordion-tabs-nav\"></ul> <div class=\"coh-accordion-tabs-content-wrapper\"> <div class=\"coh-accordion-title\" data-coh-tab-settings='[]'><a href=\"#3958181979";
        if (array_key_exists("componentUuid", $context)) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("-" . $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohCrc32($this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 1, $this->source))), "html", null, true);
        }
        if (twig_get_attribute($this->env, $this->source, ($context["loop"] ?? null), "index", [], "any", true, true, true, 1)) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("-" . $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["loop"] ?? null), "index", [], "any", false, false, true, 1), 1, $this->source)), "html", null, true);
        }
        echo "\" >";
        echo t("Filters", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        echo "</a></div> <div id=\"3958181979";
        if (array_key_exists("componentUuid", $context)) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("-" . $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohCrc32($this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 1, $this->source))), "html", null, true);
        }
        if (twig_get_attribute($this->env, $this->source, ($context["loop"] ?? null), "index", [], "any", true, true, true, 1)) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("-" . $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["loop"] ?? null), "index", [], "any", false, false, true, 1), 1, $this->source)), "html", null, true);
        }
        echo "\" class=\"coh-accordion-tabs-content\"  > ";
        $context["block_name"] = ('' === $tmp = "clear_facet_filters") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " <div class=\"coh-block coh-style-clear-facets-block\"> ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->drupalBlock($this->sandbox->ensureToStringAllowed(($context["block_name"] ?? null), 1, $this->source)), "html", null, true);
        echo " </div> <div class=\"coh-container coh-style-padding-top-small coh-style-facet-accordion\" > ";
        $context["block_name"] = ('' === $tmp = "articles_article_type") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " <div class=\"coh-block\"> ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->drupalBlock($this->sandbox->ensureToStringAllowed(($context["block_name"] ?? null), 1, $this->source)), "html", null, true);
        echo " </div> ";
        $context["block_name"] = ('' === $tmp = "articles_category") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " <div class=\"coh-block\"> ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->drupalBlock($this->sandbox->ensureToStringAllowed(($context["block_name"] ?? null), 1, $this->source)), "html", null, true);
        echo " </div> </div> </div> </div> </div> </div> </div> <div class=\"coh-column coh-visible-sm coh-col-sm-12 coh-visible-xl coh-col-xl-8\" > <div class=\"coh-view-contents views-infinite-scroll-content-wrapper clearfix\" data-drupal-views-infinite-scroll-content-wrapper> ";
        $context["patterncount"] = 1000;
        echo " ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, ($context["patterncount"] ?? null)));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            if (( !array_key_exists("view_rows", $context) || ($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getViewIterate($context) < ($context["view_rows"] ?? null)))) {
                echo " ";
                $context["pass"] = true;
                echo " ";
                if ((((array_key_exists("patternOperand", $context) && array_key_exists("patternOperator", $context)) && array_key_exists("patternValue", $context)) && array_key_exists("current_page", $context))) {
                    echo " ";
                    if ((($context["patternOperator"] ?? null) == "eq")) {
                        echo " ";
                        if ((($context["current_page"] ?? null) == ($context["patternValue"] ?? null))) {
                            $context["pass"] = true;
                        } else {
                            $context["pass"] = false;
                        }
                        echo " ";
                    }
                    echo " ";
                    if ((($context["patternOperator"] ?? null) == "lt")) {
                        echo " ";
                        if ((($context["current_page"] ?? null) < ($context["patternValue"] ?? null))) {
                            $context["pass"] = true;
                        } else {
                            $context["pass"] = false;
                        }
                        echo " ";
                    }
                    echo " ";
                    if ((($context["patternOperator"] ?? null) == "gt")) {
                        echo " ";
                        if ((($context["current_page"] ?? null) > ($context["patternValue"] ?? null))) {
                            $context["pass"] = true;
                        } else {
                            $context["pass"] = false;
                        }
                        echo " ";
                    }
                    echo " ";
                }
                echo " ";
                if ((($context["pass"] ?? null) == true)) {
                    echo " <div class=\"coh-container coh-style-search-result-container\" > ";
                    if (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getViewIterate($context) < ($context["view_rows"] ?? null))) {
                        echo " ";
                        $context["view_modes"] = [];
                        $context["view_mode"] = ('' === $tmp = "teaser") ? '' : new Markup($tmp, $this->env->getCharset());
                        $context["view_modes"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["view_modes"] ?? null), 1, $this->source), [0 => ["entity_type" => "node", "bundle" => "article", "view_mode" => ($context["view_mode"] ?? null)]]);
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->drupalViewItem($this->sandbox->ensureToStringAllowed(($context["view_modes"] ?? null), 1, $this->source), $this->sandbox->ensureToStringAllowed((($__internal_compile_0 = ($context["rows"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[$this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getViewIterate($context)] ?? null) : null), 1, $this->source)), "html", null, true);
                        echo " ";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->incrementViewIterate($context), "html", null, true);
                        echo " ";
                    }
                    echo " </div> ";
                }
                echo " ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo " </div> <div class=\"coh-container coh-ce-a90d796f\" > ";
        if (($context["pager"] ?? null)) {
            echo " ";
            $context["variables"] = $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionViewsPagination($this->sandbox->ensureToStringAllowed(($context["view"] ?? null), 1, $this->source), "{\"settings\":{\"title\":\"Pagination\",\"pager\":{\"view\":\"articles\",\"view_display\":\"page\",\"view_pager\":\"full\",\"full\":{\"firstText\":\"« First\",\"firstTextCustomStyle\":\"\",\"previousText\":\"‹\",\"previousTextCustomStyle\":\"\",\"hellipCustomStyle\":\"\",\"currentTextCustomStyle\":\"\",\"nextText\":\"›\",\"nextTextCustomStyle\":\"\",\"lastText\":\"Last »\",\"lastTextCustomStyle\":\"\"}},\"customStyle\":\"coh-style-view-pagination\"},\"styles\":{\"settings\":{\"element\":\"pagination\"}}}");
            echo " ";
            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "view_pager", [], "any", true, true, true, 1) && twig_in_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "view_pager", [], "any", false, false, true, 1), [0 => "infinite_scroll", 1 => "full", 2 => "mini"]))) {
                echo " ";
                if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "view_pager", [], "any", false, false, true, 1) == "infinite_scroll")) {
                    echo " ";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("views_infinite_scroll/views-infinite-scroll"), "html", null, true);
                    echo " ";
                    if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "next", [], "any", false, false, true, 1)) {
                        echo " <ul ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "markup", [], "any", false, true, true, 1), "id", [], "any", true, true, true, 1)) {
                            echo " id=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "markup", [], "any", false, false, true, 1), "id", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\"";
                        }
                        echo " class=\"";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, true, true, 1), "storage", [], "any", false, true, true, 1), "class", [], "any", true, true, true, 1)) {
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, false, true, 1), "storage", [], "any", false, false, true, 1), "class", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                        }
                        echo " coh-style-view-pagination\" data-drupal-views-infinite-scroll-pager=\"";
                        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "infinite", [], "any", false, true, true, 1), "loadAutomatically", [], "any", true, true, true, 1) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "infinite", [], "any", false, false, true, 1), "loadAutomatically", [], "any", false, false, true, 1) == true))) {
                            echo "automatic";
                        }
                        echo "\" > <li class=\"pager__item\"> <a class=\"button\" href=\"";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "next", [], "any", false, false, true, 1), "href", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                        echo "\" title=\"";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Go to next page"));
                        echo "\" rel=\"next\">";
                        if ((((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "infinite", [], "any", false, false, true, 1), "loadAutomatically", [], "any", false, false, true, 1) != true) && twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "infinite", [], "any", false, true, true, 1), "buttonText", [], "any", true, true, true, 1)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "infinite", [], "any", false, false, true, 1), "buttonText", [], "any", false, false, true, 1) != ""))) {
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->castToString($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "infinite", [], "any", false, false, true, 1), "buttonText", [], "any", false, false, true, 1), 1, $this->source))));
                        } elseif ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "options", [], "any", false, false, true, 1), "button_text", [], "any", false, false, true, 1) != "")) {
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->castToString($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "options", [], "any", false, false, true, 1), "button_text", [], "any", false, false, true, 1), 1, $this->source))));
                        }
                        echo "</a> </li> </ul> ";
                    }
                    echo " ";
                }
                echo " ";
                if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "view_pager", [], "any", false, false, true, 1) == "mini")) {
                    echo " ";
                    if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "previous", [], "any", false, false, true, 1) || twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "next", [], "any", false, false, true, 1))) {
                        echo " <nav class=\"pager\" role=\"navigation\" aria-labelledby=\"pagination-heading\"> <ul ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "markup", [], "any", false, true, true, 1), "id", [], "any", true, true, true, 1)) {
                            echo " id=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "markup", [], "any", false, false, true, 1), "id", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\"";
                        }
                        echo " class=\"pager__items js-pager__items";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, true, true, 1), "storage", [], "any", false, true, true, 1), "class", [], "any", true, true, true, 1)) {
                            echo " ";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, false, true, 1), "storage", [], "any", false, false, true, 1), "class", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                        }
                        echo " coh-style-view-pagination\" ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, true, true, 1), "storage", [], "any", true, true, true, 1)) {
                            echo " ";
                            $context['_parent'] = $context;
                            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, false, true, 1), "storage", [], "any", false, false, true, 1));
                            foreach ($context['_seq'] as $context["key"] => $context["value"]) {
                                if (($context["key"] != "class")) {
                                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($context["key"], 1, $this->source), "html", null, true);
                                    echo "=\"";
                                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($context["value"], 1, $this->source), "html", null, true);
                                    echo "\"";
                                }
                            }
                            $_parent = $context['_parent'];
                            unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
                            $context = array_intersect_key($context, $_parent) + $_parent;
                            echo " ";
                        }
                        echo " > ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, true, true, 1), "previous", [], "any", true, true, true, 1)) {
                            echo " <li class=\"pager__item pager__item--previous";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "previousCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "mini", [], "any", false, false, true, 1), "previousCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\"> <a href=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "previous", [], "any", false, false, true, 1), "href", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\" title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Go to previous page"));
                            echo "\" rel=\"prev\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "previous", [], "any", false, false, true, 1), "attributes", [], "any", false, false, true, 1), 1, $this->source), "href", "title", "rel"), "html", null, true);
                            echo "> <span class=\"visually-hidden\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Previous page"));
                            echo "</span> <span aria-hidden=\"true\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t(((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "previousText", [], "any", true, true, true, 1)) ? (_twig_default_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "previousText", [], "any", false, false, true, 1), 1, $this->source), "‹‹")) : ("‹‹"))));
                            echo "</span> </a> </li> ";
                        }
                        echo " ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, true, true, 1), "current", [], "any", true, true, true, 1)) {
                            echo " <li class=\"pager__item is-active";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "pageTextCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "mini", [], "any", false, false, true, 1), "pageTextCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\"> ";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t(((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "pageText", [], "any", true, true, true, 1)) ? (_twig_default_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "pageText", [], "any", false, false, true, 1), 1, $this->source), "Page")) : ("Page"))));
                            echo " ";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "current", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo " </li> ";
                        }
                        echo " ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, true, true, 1), "next", [], "any", true, true, true, 1)) {
                            echo " <li class=\"pager__item pager__item--next";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "nextCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "mini", [], "any", false, false, true, 1), "nextCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\"> <a href=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "next", [], "any", false, false, true, 1), "href", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\" title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Go to next page"));
                            echo "\" rel=\"next\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "next", [], "any", false, false, true, 1), "attributes", [], "any", false, false, true, 1), 1, $this->source), "href", "title", "rel"), "html", null, true);
                            echo "> <span class=\"visually-hidden\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Next page"));
                            echo "</span> <span aria-hidden=\"true\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t(((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "nextText", [], "any", true, true, true, 1)) ? (_twig_default_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "mini", [], "any", false, true, true, 1), "nextText", [], "any", false, false, true, 1), 1, $this->source), "››")) : ("››"))));
                            echo "</span> </a> </li> ";
                        }
                        echo " </ul> </nav> ";
                    }
                    echo " ";
                }
                echo " ";
                if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "view_pager", [], "any", false, false, true, 1) == "full")) {
                    echo " ";
                    if (twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1)) {
                        echo " <ul ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "markup", [], "any", false, true, true, 1), "id", [], "any", true, true, true, 1)) {
                            echo " id=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "markup", [], "any", false, false, true, 1), "id", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\"";
                        }
                        echo " class=\"pager__items js-pager__items";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, true, true, 1), "storage", [], "any", false, true, true, 1), "class", [], "any", true, true, true, 1)) {
                            echo " ";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, false, true, 1), "storage", [], "any", false, false, true, 1), "class", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                        }
                        echo " coh-style-view-pagination\" ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, true, true, 1), "storage", [], "any", true, true, true, 1)) {
                            echo " ";
                            $context['_parent'] = $context;
                            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "attributes", [], "any", false, false, true, 1), "storage", [], "any", false, false, true, 1));
                            foreach ($context['_seq'] as $context["key"] => $context["value"]) {
                                if (($context["key"] != "class")) {
                                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($context["key"], 1, $this->source), "html", null, true);
                                    echo "=\"";
                                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($context["value"], 1, $this->source), "html", null, true);
                                    echo "\"";
                                }
                            }
                            $_parent = $context['_parent'];
                            unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
                            $context = array_intersect_key($context, $_parent) + $_parent;
                            echo " ";
                        }
                        echo " > ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, true, true, 1), "first", [], "any", true, true, true, 1)) {
                            echo " <li class=\"pager__item pager__item--first";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "firstTextCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "full", [], "any", false, false, true, 1), "firstTextCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\"> <a href=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "first", [], "any", false, false, true, 1), "href", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\" title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Go to first page"));
                            echo "\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "first", [], "any", false, false, true, 1), "attributes", [], "any", false, false, true, 1), 1, $this->source), "href", "title"), "html", null, true);
                            echo "> <span class=\"visually-hidden\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("First page"));
                            echo "</span> <span aria-hidden=\"true\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t(((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "firstText", [], "any", true, true, true, 1)) ? (_twig_default_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "firstText", [], "any", false, false, true, 1), 1, $this->source), "&laquo; First")) : ("&laquo; First"))));
                            echo "</span> </a> </li> ";
                        }
                        echo " ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, true, true, 1), "previous", [], "any", true, true, true, 1)) {
                            echo " <li class=\"pager__item pager__item--previous";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "previousTextCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "full", [], "any", false, false, true, 1), "previousTextCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\"> <a href=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "previous", [], "any", false, false, true, 1), "href", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\" title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Go to previous page"));
                            echo "\" rel=\"prev\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "previous", [], "any", false, false, true, 1), "attributes", [], "any", false, false, true, 1), 1, $this->source), "href", "title", "rel"), "html", null, true);
                            echo "> <span class=\"visually-hidden\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Previous page"));
                            echo "</span> <span aria-hidden=\"true\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t(((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "previousText", [], "any", true, true, true, 1)) ? (_twig_default_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "previousText", [], "any", false, false, true, 1), 1, $this->source), "&laquo; Previous")) : ("&laquo; Previous"))));
                            echo "</span> </a> </li> ";
                        }
                        echo " ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "ellipses", [], "any", false, true, true, 1), "previous", [], "any", true, true, true, 1)) {
                            echo " <li class=\"pager__item pager__item--ellipsis";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "hellipCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "full", [], "any", false, false, true, 1), "hellipCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\" role=\"presentation\">&hellip;</li> ";
                        }
                        echo " ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "pages", [], "any", false, false, true, 1));
                        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
                            echo " <li class=\"pager__item";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($context["current_page"] ?? null) == $context["key"])) ? (" is-active") : ("")));
                            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "currentTextCustomStyle", [], "any", true, true, true, 1) && (($context["current_page"] ?? null) == $context["key"]))) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "full", [], "any", false, false, true, 1), "currentTextCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\"> ";
                            if ((($context["current_page"] ?? null) == $context["key"])) {
                                echo " ";
                                $context["title"] = t("Current page");
                                echo " ";
                            } else {
                                echo " ";
                                $context["title"] = t("Go to page @key", ["@key" => $context["key"]]);
                                echo " ";
                            }
                            echo " <a href=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\" title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title"] ?? null), 1, $this->source), "html", null, true);
                            echo "\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "attributes", [], "any", false, false, true, 1), 1, $this->source), "href", "title"), "html", null, true);
                            echo "> <span class=\"visually-hidden\"> ";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($context["current_page"] ?? null) == $context["key"])) ? (t("Current page")) : (t("Page"))));
                            echo " </span>";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($context["key"], 1, $this->source), "html", null, true);
                            echo "</a> </li> ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        echo " ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "ellipses", [], "any", false, true, true, 1), "next", [], "any", true, true, true, 1)) {
                            echo " <li class=\"pager__item pager__item--ellipsis";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "hellipCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "full", [], "any", false, false, true, 1), "hellipCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\" role=\"presentation\">&hellip;</li> ";
                        }
                        echo " ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "next", [], "any", false, false, true, 1)) {
                            echo " <li class=\"pager__item pager__item--next";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "nextTextCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "full", [], "any", false, false, true, 1), "nextTextCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\"> <a href=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "next", [], "any", false, false, true, 1), "href", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\" title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Go to next page"));
                            echo "\" rel=\"next\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "next", [], "any", false, false, true, 1), "attributes", [], "any", false, false, true, 1), 1, $this->source), "href", "title", "rel"), "html", null, true);
                            echo "> <span class=\"visually-hidden\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Next page"));
                            echo "</span> <span aria-hidden=\"true\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t(((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "nextText", [], "any", true, true, true, 1)) ? (_twig_default_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "nextText", [], "any", false, false, true, 1), 1, $this->source), "Next &raquo;")) : ("Next &raquo;"))));
                            echo "</span> </a> </li> ";
                        }
                        echo " ";
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, true, true, 1), "last", [], "any", true, true, true, 1)) {
                            echo " <li class=\"pager__item pager__item--last";
                            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "lastTextCustomStyle", [], "any", true, true, true, 1)) {
                                echo " ";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, false, true, 1), "pager", [], "any", false, false, true, 1), "full", [], "any", false, false, true, 1), "lastTextCustomStyle", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            }
                            echo "\"> <a href=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "last", [], "any", false, false, true, 1), "href", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                            echo "\" title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Go to last page"));
                            echo "\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "items", [], "any", false, false, true, 1), "last", [], "any", false, false, true, 1), "attributes", [], "any", false, false, true, 1), 1, $this->source), "href", "title"), "html", null, true);
                            echo "> <span class=\"visually-hidden\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Last page"));
                            echo "</span> <span aria-hidden=\"true\">";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t(((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "lastText", [], "any", true, true, true, 1)) ? (_twig_default_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["variables"] ?? null), "settings", [], "any", false, true, true, 1), "pager", [], "any", false, true, true, 1), "full", [], "any", false, true, true, 1), "lastText", [], "any", false, false, true, 1), 1, $this->source), "Last &raquo;")) : ("Last &raquo;"))));
                            echo "</span> </a> </li> ";
                        }
                        echo " </ul> ";
                    }
                    echo " ";
                }
                echo " ";
            }
            echo " ";
        }
        echo " </div> </div> </div> </div> ";
        if (($context["exposed"] ?? null)) {
            echo " <div class=\"hidden\"> ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["exposed"] ?? null), 1, $this->source), "html", null, true);
            echo " </div> ";
        }
        echo " </div> </div> 
";
        // line 2
        if (array_key_exists("content", $context)) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 2, $this->source));
        }
    }

    public function getTemplateName()
    {
        return "sites/default/files/cohesion/templates/views-view--cohesion-view-tpl-articles.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  477 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "sites/default/files/cohesion/templates/views-view--cohesion-view-tpl-articles.html.twig", "/app/docroot/sites/default/files/cohesion/templates/views-view--cohesion-view-tpl-articles.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "if" => 1, "trans" => 1, "for" => 1);
        static $filters = array("escape" => 1, "clean_class" => 1, "length" => 1, "crc32" => 1, "merge" => 1, "trans" => 1, "without" => 1, "default" => 1, "t" => 1, "render" => 2);
        static $functions = array("attach_library" => 1, "setViewIterate" => 1, "processtoken" => 1, "get_content_language" => 1, "drupal_block" => 1, "range" => 1, "getViewIterate" => 1, "drupal_view_item" => 1, "incrementViewIterate" => 1, "cohesion_views_pagination" => 1, "castToString" => 1);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'trans', 'for'],
                ['escape', 'clean_class', 'length', 'crc32', 'merge', 'trans', 'without', 'default', 't', 'render'],
                ['attach_library', 'setViewIterate', 'processtoken', 'get_content_language', 'drupal_block', 'range', 'getViewIterate', 'drupal_view_item', 'incrementViewIterate', 'cohesion_views_pagination', 'castToString']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
