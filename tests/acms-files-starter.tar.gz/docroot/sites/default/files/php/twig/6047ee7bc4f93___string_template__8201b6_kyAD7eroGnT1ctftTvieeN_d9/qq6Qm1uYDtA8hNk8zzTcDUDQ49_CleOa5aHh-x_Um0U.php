<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__8201b62821076b9b7a52ae0c7d9115e1208944b8d212b1573f199cc6b81daf94 */
class __TwigTemplate_6178eedc291282730ae91a58a2603d52d32a24366daf4dc69539ab6b0ba91e06 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block3700379502' => [$this, 'block_block3700379502'],
            'block481590291' => [$this, 'block_block481590291'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:7a392f6e-2ef8-4920-8a43-d7d1c8082434]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 1, $this->source), false), "html", null, true);
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = false;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3700379502', $context, $blocks);
        // line 4
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 4, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 4, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 4, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"]), "b9238d24-1008-4bbe-9f2c-c72bf0ada20b", ""), "html", null, true);
        echo " ";
        $context["component_variable_0f6c5766_c38d_4a0f_8c6b_ef0a6d0e5263"] = ('' === $tmp = "Pre heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_ebd29e60_421d_4ab6_83d0_fdb9a7900929"] = ('' === $tmp = "Text and card container") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_2b367d46_fc2c_45b9_956c_25ae023f8c10_text"] = ('' === $tmp = "<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 5
        echo " ";
        $context["component_variable_2b367d46_fc2c_45b9_956c_25ae023f8c10_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0c7e5fce_5201_4772_8f27_240150783115"] = ('' === $tmp = "Action link") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_751add96_cd65_49b0_a859_1e261a47273e"] = ('' === $tmp = "coh-style-padding-top-bottom---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_70ac2325_fffa_42f5_861d_5b6fc89c447d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block481590291', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 5, $this->source), ["987f98f3-b979-4530-a5cb-02c0f22ef90e" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("10b07136", false, $this->sandbox->ensureToStringAllowed($context, 5, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 5, $this->source), ["0f6c5766-c38d-4a0f-8c6b-ef0a6d0e5263" => "component_variable_0f6c5766_c38d_4a0f_8c6b_ef0a6d0e5263", "ebd29e60-421d-4ab6-83d0-fdb9a7900929" => "component_variable_ebd29e60_421d_4ab6_83d0_fdb9a7900929", "2b367d46-fc2c-45b9-956c-25ae023f8c10" => ["text" => "component_variable_2b367d46_fc2c_45b9_956c_25ae023f8c10_text", "textFormat" => "component_variable_2b367d46_fc2c_45b9_956c_25ae023f8c10_textFormat"], "0c7e5fce-5201-4772-8f27-240150783115" => "component_variable_0c7e5fce_5201_4772_8f27_240150783115", "751add96-cd65-49b0-a859-1e261a47273e" => "component_variable_751add96_cd65_49b0_a859_1e261a47273e", "70ac2325-fffa-42f5-861d-5b6fc89c447d" => "component_variable_70ac2325_fffa_42f5_861d_5b6fc89c447d"]), "64b5717b-62a2-4b0a-8de2-1f0df57c7d7b", ""), "html", null, true);
        echo " 
";
        // line 6
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 6, $this->source));
        }
    }

    // line 1
    public function block_block3700379502($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_text"] = ('' === $tmp = "<h1>Welcome to Acquia CMS</h1>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 4
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a581345e_9290_4d1d_ac78_20b3ba547743"] = ('' === $tmp = "Learn More") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_86d5677f_86b4_4f30_845a_25636792b9a3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741"] = ('' === $tmp = "coh-style-height--large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7"] = 5;
        echo " ";
        $context["component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f"] = 10;
        echo " ";
        $context["component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8"] = ('' === $tmp = "Left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd1d1cc_031f_438a_82fc_43edca962513"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84"] = 1;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_90226570_4c01_4971_8985_6564b065a63d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dc3d74f2_e281_4c18_8689_1f266560111b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d"] = ('' === $tmp = "flex-start;") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fee69872_6425_4df2_a336_61768fe7c265"] = ('' === $tmp = "coh-style-link-button") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_hero", false, $this->sandbox->ensureToStringAllowed($context, 4, $this->source), ["ec518aee-3987-4edc-8630-c679120136af" => ["text" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_text", "textFormat" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"], "1ca08220-ccc9-4171-a2d3-993ea04fe1d0" => "component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0", "a581345e-9290-4d1d-ac78-20b3ba547743" => "component_variable_a581345e_9290_4d1d_ac78_20b3ba547743", "86d5677f-86b4-4f30-845a-25636792b9a3" => "component_variable_86d5677f_86b4_4f30_845a_25636792b9a3", "fe487eb0-8848-4d8d-9901-bb5cb64c4741" => "component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741", "5311228f-f968-4346-bbe1-747dfde7b1f7" => "component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7", "35d8f0ae-b2db-4f9d-941f-ce47958aae5f" => "component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f", "29ff2bde-d589-4eb3-a0a8-ddcc23fa5aa8" => "component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8", "6bd1d1cc-031f-438a-82fc-43edca962513" => "component_variable_6bd1d1cc_031f_438a_82fc_43edca962513", "15bb3c39-f87e-4ace-a924-ae9ae1867c94" => "component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94", "5502b4d7-a6bd-467a-993d-625ef4002d84" => "component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84", "90226570-4c01-4971-8985-6564b065a63d" => "component_variable_90226570_4c01_4971_8985_6564b065a63d", "dc3d74f2-e281-4c18-8689-1f266560111b" => "component_variable_dc3d74f2_e281_4c18_8689_1f266560111b", "e330c7cb-1cb4-41a0-b3b0-ec95a9764b7d" => "component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d", "fee69872-6425-4df2-a336-61768fe7c265" => "component_variable_fee69872_6425_4df2_a336_61768fe7c265", "f30e5ad5-c3c7-44a3-bf47-882cb74da487" => "component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487"], "7bd97e54-358b-46eb-8e91-b46cfe30fec5", ""), "html", null, true);
        echo " ";
    }

    // line 5
    public function block_block481590291($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:58abfcde-c65e-4974-a445-65ceaa6def7b]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 5, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = "Pre heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "https://www.acquia.com") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 6;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(0, 0, 0, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 5, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "3364862d-ea5b-40d1-a927-14eeb349ca5d", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:58abfcde-c65e-4974-a445-65ceaa6def7b]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 5, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = "Pre heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "https://www.acquia.com") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 6;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(0, 0, 0, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 5, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "f9745a2f-cd01-477b-b23f-a813c0cc54d0", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:58abfcde-c65e-4974-a445-65ceaa6def7b]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 5, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = "Pre heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "https://www.acquia.com") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 6;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(0, 0, 0, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 5, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "fb10e8ae-b2b5-4455-ad5c-078ff1b94a3f", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:58abfcde-c65e-4974-a445-65ceaa6def7b]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 5, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = "Pre heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "https://www.acquia.com") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 6;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(0, 0, 0, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 5, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "9c2975f8-0c6a-49a6-bbb2-491a410115b5", ""), "html", null, true);
        echo " ";
    }

    public function getTemplateName()
    {
        return "__string_template__8201b62821076b9b7a52ae0c7d9115e1208944b8d212b1573f199cc6b81daf94";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  193 => 5,  151 => 4,  142 => 1,  136 => 6,  110 => 5,  92 => 4,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__8201b62821076b9b7a52ae0c7d9115e1208944b8d212b1573f199cc6b81daf94", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "block" => 1, "if" => 4);
        static $filters = array("escape" => 1, "merge" => 4, "render" => 6);
        static $functions = array("attach_library" => 1, "processtoken" => 1, "renderComponent" => 4);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'merge', 'render'],
                ['attach_library', 'processtoken', 'renderComponent']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
