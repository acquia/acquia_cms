<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* sites/default/files/cohesion/templates/component--cohesion-cpt-hero.html.twig */
class __TwigTemplate_85001e4da71edc1f564735192635dc471f03a31299799b571de40223822b1c77 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohInstanceId(), "html", null, true);
        $context["coh_instance_class"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        if (((($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->hasDrupalPermission([0 => "access contextual links", 1 => "access components"]) &&  !($context["isPreview"] ?? null)) &&  !array_key_exists("hideContextualLinks", $context)) &&  !$this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->isFrontendEditor())) {
            echo " <div class=\"dx-contextual-region contextual-region\" data-dx-contextual=\"coh-component-instance-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 1, $this->source), "html", null, true);
            echo "\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 1, $this->source), "html", null, true);
            echo "</div> ";
        }
        echo " <div class=\"coh-container coh-component coh-component-instance-";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 1, $this->source), "html", null, true);
        echo " contextual-component ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "3488ef37-a844-4cd1-be55-9cbe7097d1ca"));
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 1, $this->source), "html", null, true);
        echo " coh-ce-cpt_hero-453a75b5\" > ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "c205de8f-490a-45f5-bdf7-1302262dff29", ""), "html", null, true);
        $context["hideData"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if (((null === ($context["hideData"] ?? null)) || (twig_trim_filter(($context["hideData"] ?? null)) != ""))) {
            echo " <nav class=\"coh-container ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "c205de8f-490a-45f5-bdf7-1302262dff29"));
            echo " coh-ce-cpt_hero-fedf769c\" aria-label=\"Breadcrumb\" > ";
            $context["breadcrumb"] = $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getBreadCrumb();
            echo " ";
            if (($context["breadcrumb"] ?? null)) {
                echo " <ul class=\"coh-breadcrumb coh-style-breadcrumbs\"> ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["breadcrumb"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                    echo " <li> ";
                    if (twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 1)) {
                        echo " <a href=\"";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                        echo "\">";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "text", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                        echo "</a> ";
                    } else {
                        echo " ";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "text", [], "any", false, false, true, 1), 1, $this->source), "html", null, true);
                        echo " ";
                    }
                    echo " </li> ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                echo " </ul> ";
            }
            echo " </nav> ";
        }
        echo " <div class=\"coh-container ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "a81fe8e5-6819-419b-b672-1992944d6e0e"));
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "8f06b2b8-2cf7-46e4-a157-df4ecb82616e"));
        echo " coh-style-padding-top-bottom-large coh-ce-cpt_hero-55a54ec4 coh-container-boxed\" > <div class=\"coh-container text-content coh-ce-cpt_hero-77bc8a97\" > <h1 class=\"coh-heading heading ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "d2da98a2-83de-4f65-b9f1-3495b3eba524"));
        echo " coh-ce-cpt_hero-fd5ded85\"> ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "cd6ec798-08ed-410b-aff8-186718f29eba"));
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "33467589-5892-41d3-b1c1-fe04f053df8e"));
        echo " </h1> <div class=\"coh-wysiwyg ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "09a46fc3-8aad-4aab-aceb-efae824bb9c0"));
        echo "\"> ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "78ab8d68-8bc0-4ada-a668-3c24c67a94e0", "#text"), "html", null, true);
        $context["wysiwyg"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "78ab8d68-8bc0-4ada-a668-3c24c67a94e0", "#textFormat"), "html", null, true);
        $context["text_format"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "78ab8d68-8bc0-4ada-a668-3c24c67a94e0", ""), "html", null, true);
        $context["token_text"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->formatWysiwyg($this->sandbox->ensureToStringAllowed(($context["wysiwyg"] ?? null), 1, $this->source), $this->sandbox->ensureToStringAllowed(($context["text_format"] ?? null), 1, $this->source), $this->sandbox->ensureToStringAllowed(($context["token_text"] ?? null), 1, $this->source)), "html", null, true);
        echo " </div> ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "d7dc850d-3030-4316-b778-40aba3465abf"));
        $context["nid_485723338"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        ob_start(function () { return ''; });
        if ((($context["nid_485723338"] ?? null) != "")) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->pathRenderer($this->sandbox->ensureToStringAllowed(($context["nid_485723338"] ?? null), 1, $this->source)), "html", null, true);
        }
        $context["hideData"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if (((null === ($context["hideData"] ?? null)) || (twig_trim_filter(($context["hideData"] ?? null)) != ""))) {
            echo " <a href=\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "d7dc850d-3030-4316-b778-40aba3465abf"));
            $context["entityId"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            if ((($context["entityId"] ?? null) != "")) {
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->pathRenderer($this->sandbox->ensureToStringAllowed(($context["entityId"] ?? null), 1, $this->source)), "html", null, true);
            }
            echo "\" class=\"coh-link ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "de884b6a-5562-42c2-b6c7-2b10cde62135"));
            echo " coh-ce-cpt_hero-55f19225\" ";
            if (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "2870bc76-3def-451f-ae8e-c43c3315a3a6") != "")) {
                echo "target=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "2870bc76-3def-451f-ae8e-c43c3315a3a6"), "html", null, true);
                echo "\"";
            }
            echo " > ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "b7b68756-96df-45b6-a611-060f86836d06"));
            echo "    </a> ";
        }
        echo " </div> <div class=\"coh-container drop-zone-content coh-ce-cpt_hero-65b810ab\" > ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "c87df6db-a4d4-4710-a628-54bb5feda3af"), "html", null, true);
        echo " </div> </div> </div> 
";
        // line 2
        if (array_key_exists("content", $context)) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 2, $this->source));
        }
        ob_start(function () { return ''; });
        echo "<style>.";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 2, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "fd8a192f-0ba9-42b8-9d95-151291824a5f"))) {
            echo " background-color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "fd8a192f-0ba9-42b8-9d95-151291824a5f"));
            echo ";";
        }
        echo " }

.image-no-overlay.";
        // line 4
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 4, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            echo " background-image: url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 4, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 4, $this->source)), "html", null, true);
            echo "\");";
        }
        echo " background-position: center; background-size: cover; background-repeat: no-repeat; background-attachment: scroll; }

@media (max-width: 63.9375rem) { .image-no-overlay.";
        // line 6
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 6, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            echo " background-image: url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 6, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 6, $this->source)), "html", null, true);
            echo "\");";
        }
        echo " background-position: center; background-size: cover; background-repeat: no-repeat; background-attachment: scroll; } }

@media (max-width: 47.9375rem) { .image-no-overlay.";
        // line 8
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 8, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            echo " background-image: url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 8, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 8, $this->source)), "html", null, true);
            echo "\");";
        }
        echo " background-position: center; background-size: cover; background-repeat: no-repeat; background-attachment: scroll; } }

.image-dark-overlay.";
        // line 10
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 10, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-gradient(linear, left top, right top, color-stop(1%, rgba(0, 0, 0, 0.2)), to(rgba(0, 0, 0, 0.2)))") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 10, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 10, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-linear-gradient(left, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 10, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 10, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-o-linear-gradient(left, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 10, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 10, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "linear-gradient(90deg, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 10, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 10, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 10, $this->source), ", "), "html", null, true);
        echo "; background-position: center, center; background-size: auto, cover; background-repeat: no-repeat, no-repeat; background-attachment: scroll, scroll; }

@media (max-width: 63.9375rem) { .image-dark-overlay.";
        // line 12
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 12, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-gradient(linear, left top, right top, color-stop(1%, rgba(0, 0, 0, 0.2)), to(rgba(0, 0, 0, 0.2)))") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 12, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 12, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-linear-gradient(left, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 12, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 12, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-o-linear-gradient(left, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 12, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 12, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "linear-gradient(90deg, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 12, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 12, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 12, $this->source), ", "), "html", null, true);
        echo "; background-position: center, center; background-size: auto, cover; background-repeat: no-repeat, no-repeat; background-attachment: scroll, scroll; } }

@media (max-width: 47.9375rem) { .image-dark-overlay.";
        // line 14
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 14, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-gradient(linear, left top, right top, color-stop(1%, rgba(0, 0, 0, 0.2)), to(rgba(0, 0, 0, 0.2)))") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 14, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 14, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-linear-gradient(left, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 14, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 14, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-o-linear-gradient(left, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 14, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 14, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "linear-gradient(90deg, rgba(0, 0, 0, 0.2) 1%, rgba(0, 0, 0, 0.2) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 14, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 14, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 14, $this->source), ", "), "html", null, true);
        echo "; background-position: center, center; background-size: auto, cover; background-repeat: no-repeat, no-repeat; background-attachment: scroll, scroll; } }

.image-light-overlay.";
        // line 16
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 16, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-gradient(linear, left top, right top, color-stop(1%, rgba(255, 255, 255, 0.3)), to(rgba(255, 255, 255, 0.3)))") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 16, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 16, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-linear-gradient(left, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 16, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 16, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-o-linear-gradient(left, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 16, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 16, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_xx_large_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 16, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 16, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 16, $this->source), ", "), "html", null, true);
        echo "; background-position: center, center top; background-size: auto, cover; background-repeat: no-repeat, no-repeat; background-attachment: scroll, scroll; }

@media (max-width: 63.9375rem) { .image-light-overlay.";
        // line 18
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 18, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-gradient(linear, left top, right top, color-stop(1%, rgba(255, 255, 255, 0.3)), to(rgba(255, 255, 255, 0.3)))") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 18, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 18, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-linear-gradient(left, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 18, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 18, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-o-linear-gradient(left, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 18, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 18, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_medium_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 18, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 18, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 18, $this->source), ", "), "html", null, true);
        echo "; background-position: center, center; background-size: auto, cover; background-repeat: no-repeat, no-repeat; background-attachment: scroll, scroll; } }

@media (max-width: 47.9375rem) { .image-light-overlay.";
        // line 20
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 20, $this->source), "html", null, true);
        echo ".coh-ce-cpt_hero-453a75b5 { ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-gradient(linear, left top, right top, color-stop(1%, rgba(255, 255, 255, 0.3)), to(rgba(255, 255, 255, 0.3)))") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 20, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 20, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-webkit-linear-gradient(left, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 20, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 20, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "-o-linear-gradient(left, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 20, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 20, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), ", "), "html", null, true);
        echo "; ";
        $context["items"] = [];
        $context["item"] = ('' === $tmp = "linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1%, rgba(255, 255, 255, 0.3) 100%)") ? '' : new Markup($tmp, $this->env->getCharset());
        $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => ($context["item"] ?? null)]);
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"))) {
            ob_start(function () { return ''; });
            echo "url(\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "298f9e5d-49ed-428b-ac9c-5802cecb03fb"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "coh_small_landscape") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 20, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 20, $this->source)), "html", null, true);
            echo "\")";
            $context["item"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => ($context["item"] ?? null)]);
        } else {
            $context["items"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), [0 => "none"]);
        }
        echo "background-image: ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 20, $this->source), ", "), "html", null, true);
        echo "; background-position: center, center; background-size: auto, cover; background-repeat: no-repeat, no-repeat; background-attachment: scroll, scroll; } }
</style>";
        $context["compiledCSS"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 21
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderInlineStyle($this->sandbox->ensureToStringAllowed(($context["compiledCSS"] ?? null), 21, $this->source)));
    }

    public function getTemplateName()
    {
        return "sites/default/files/cohesion/templates/component--cohesion-cpt-hero.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  737 => 21,  652 => 20,  567 => 18,  482 => 16,  397 => 14,  312 => 12,  227 => 10,  212 => 8,  197 => 6,  182 => 4,  166 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "sites/default/files/cohesion/templates/component--cohesion-cpt-hero.html.twig", "/Users/katherine.druckman/Sites/acquia_cms/docroot/sites/default/files/cohesion/templates/component--cohesion-cpt-hero.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "if" => 1, "for" => 1);
        static $filters = array("escape" => 1, "raw" => 1, "trim" => 1, "render" => 2, "merge" => 10, "join" => 10);
        static $functions = array("coh_instanceid" => 1, "attach_library" => 1, "has_drupal_permission" => 1, "isFrontendEditor" => 1, "getComponentFieldValue" => 1, "cohesion_breadcrumb" => 1, "format_wysiwyg" => 1, "path_renderer" => 1, "cohesion_image_style" => 4, "renderInlineStyle" => 21);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'for'],
                ['escape', 'raw', 'trim', 'render', 'merge', 'join'],
                ['coh_instanceid', 'attach_library', 'has_drupal_permission', 'isFrontendEditor', 'getComponentFieldValue', 'cohesion_breadcrumb', 'format_wysiwyg', 'path_renderer', 'cohesion_image_style', 'renderInlineStyle']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
