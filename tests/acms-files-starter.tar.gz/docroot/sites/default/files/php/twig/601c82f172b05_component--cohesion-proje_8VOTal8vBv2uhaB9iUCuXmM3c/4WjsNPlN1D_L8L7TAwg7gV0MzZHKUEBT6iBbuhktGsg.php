<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* sites/default/files/cohesion/templates/component--cohesion-project-card.html.twig */
class __TwigTemplate_0bc7acb3449876424e903e8c056da9b521e4dec4f9792cddb04e584a1c67a98a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohInstanceId(), "html", null, true);
        $context["coh_instance_class"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.image"), "html", null, true);
        echo " ";
        if ((($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->hasDrupalPermission([0 => "access contextual links", 1 => "access components"]) &&  !($context["isPreview"] ?? null)) &&  !(isset($context["hideContextualLinks"]) || array_key_exists("hideContextualLinks", $context)))) {
            echo " <div class=\"dx-contextual-region contextual-region\" data-dx-contextual=\"coh-component-instance-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source), "html", null, true);
            echo "\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 3, $this->source), "html", null, true);
            echo "</div> ";
        }
        echo " <div class=\"coh-column coh-component coh-component-instance-";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source), "html", null, true);
        echo " contextual-component ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 3, $this->source), "html", null, true);
        echo " coh-ce-project_card-cda4096c ";
        if (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "ff1f20ef-f2b7-4c07-a491-55af03245114") ==  -1)) {
            echo "coh-hidden-ps";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "ff1f20ef-f2b7-4c07-a491-55af03245114") ==  -2)) {
            echo "coh-col-ps";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "ff1f20ef-f2b7-4c07-a491-55af03245114") ==  -3)) {
            echo "coh-col-ps-auto";
        } else {
            echo "coh-visible-ps coh-col-ps-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter(twig_split_filter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "ff1f20ef-f2b7-4c07-a491-55af03245114"), "."), "-"), "html", null, true);
        }
        echo " ";
        if (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "d56a1803-c41f-4c6e-890f-9aadbbc69870") ==  -1)) {
            echo "coh-hidden-md";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "d56a1803-c41f-4c6e-890f-9aadbbc69870") ==  -2)) {
            echo "coh-col-md";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "d56a1803-c41f-4c6e-890f-9aadbbc69870") ==  -3)) {
            echo "coh-col-md-auto";
        } else {
            echo "coh-visible-md coh-col-md-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter(twig_split_filter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "d56a1803-c41f-4c6e-890f-9aadbbc69870"), "."), "-"), "html", null, true);
        }
        echo " ";
        if (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "e7947ab1-db62-4e57-b3ec-1eda5d7d7249") ==  -1)) {
            echo "coh-hidden-xl";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "e7947ab1-db62-4e57-b3ec-1eda5d7d7249") ==  -2)) {
            echo "coh-col-xl";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "e7947ab1-db62-4e57-b3ec-1eda5d7d7249") ==  -3)) {
            echo "coh-col-xl-auto";
        } else {
            echo "coh-visible-xl coh-col-xl-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter(twig_split_filter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "e7947ab1-db62-4e57-b3ec-1eda5d7d7249"), "."), "-"), "html", null, true);
        }
        echo "\" > <a href=\"";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f"));
        $context["entityId"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        if ((($context["entityId"] ?? null) != "")) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->pathRenderer($this->sandbox->ensureToStringAllowed(($context["entityId"] ?? null), 3, $this->source)), "html", null, true);
        }
        echo "\" class=\"coh-container ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "daabd3ea-ef42-4be9-a492-9433da0df78e"));
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 3, $this->source), "html", null, true);
        echo " coh-ce-project_card-e838daa9\" target=\"_self\" > ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "5ecad84c-1903-402f-9d1b-a8c5b8d8a098", ""), "html", null, true);
        $context["hideData"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if (((null === ($context["hideData"] ?? null)) || (twig_trim_filter(($context["hideData"] ?? null)) != ""))) {
            echo " <img class=\"coh-image card-image ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 3, $this->source), "html", null, true);
            echo " coh-ce-project_card-4ca1877a coh-image-responsive-xl\" src=\"";
            ob_start(function () { return ''; });
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "5ecad84c-1903-402f-9d1b-a8c5b8d8a098"));
            $context["src"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            $context["imagestyle"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohesionImageStyle($this->sandbox->ensureToStringAllowed(($context["src"] ?? null), 3, $this->source), $this->sandbox->ensureToStringAllowed(($context["imagestyle"] ?? null), 3, $this->source)), "html", null, true);
            echo "\" title=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "e35ae154-1e7b-41cb-babb-9209c78c1ea2"));
            echo "\" alt=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "58c369ea-4a48-4ee4-aca4-9072ce0af7c5"));
            echo "\" /> ";
        }
        echo " <div class=\"coh-container coh-style-padding---small coh-ce-project_card-e938dfe3\" > <h2 class=\"coh-heading card-pre-heading coh-style-pre-heading\"> ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "f758f4c9-9588-4610-87f4-4f02423c0120"));
        echo " </h2> ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "03322899-56e0-401a-8ab7-730c5b569f6f", ""), "html", null, true);
        $context["hideData"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if (((null === ($context["hideData"] ?? null)) || (twig_trim_filter(($context["hideData"] ?? null)) != ""))) {
            echo " <h3 class=\"coh-heading card-heading\"> ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "03322899-56e0-401a-8ab7-730c5b569f6f"));
            echo " </h3> ";
        }
        echo " </div> </a> </div> 
";
        // line 4
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 4, $this->source));
        }
        ob_start(function () { return ''; });
        echo "<style>.";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 4, $this->source), "html", null, true);
        echo ".coh-ce-project_card-cda4096c { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "73c42747-0483-45df-8254-6dab03362d07"))) {
            echo " color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "73c42747-0483-45df-8254-6dab03362d07"));
            echo ";";
        }
        echo " }
.";
        // line 5
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 5, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9 { overflow: hidden; position: relative; z-index: 2; }

.";
        // line 7
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 7, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9:before { height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 2; background-color: black; opacity: 0.2; display: block; -webkit-transition: all 300ms ease; -o-transition: all 300ms ease; transition: all 300ms ease; }

.";
        // line 9
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 9, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9:hover:before { opacity: 0.6; }

.";
        // line 11
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 11, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9:hover .card-image { -webkit-transform: scaleX(1) scaleY(1); -ms-transform: scaleX(1) scaleY(1); transform: scaleX(1) scaleY(1); }

.";
        // line 13
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 13, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9:hover .card-pre-heading { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "74bef303-fa50-4e26-990d-23a8fd1ca8b5"))) {
            echo " color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "74bef303-fa50-4e26-990d-23a8fd1ca8b5"));
            echo ";";
        }
        echo " }

.";
        // line 15
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 15, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9:hover .card-heading { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "74bef303-fa50-4e26-990d-23a8fd1ca8b5"))) {
            echo " color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "74bef303-fa50-4e26-990d-23a8fd1ca8b5"));
            echo ";";
        }
        echo " }

.";
        // line 17
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 17, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9 .card-image { -webkit-transform: scaleX(1.3) scaleY(1.3); -ms-transform: scaleX(1.3) scaleY(1.3); transform: scaleX(1.3) scaleY(1.3); -webkit-transition: 300ms ease transform; -o-transition: 300ms ease transform; transition: 300ms ease transform; }

.";
        // line 19
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 19, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9 .card-pre-heading { -webkit-transition: color 300ms ease; -o-transition: color 300ms ease; transition: color 300ms ease; ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "73c42747-0483-45df-8254-6dab03362d07"))) {
            echo " color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "73c42747-0483-45df-8254-6dab03362d07"));
            echo ";";
        }
        echo " }

.";
        // line 21
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 21, $this->source), "html", null, true);
        echo ".coh-ce-project_card-e838daa9 .card-heading { -webkit-transition: color 300ms ease; -o-transition: color 300ms ease; transition: color 300ms ease; ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "73c42747-0483-45df-8254-6dab03362d07"))) {
            echo " color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "73c42747-0483-45df-8254-6dab03362d07"));
            echo ";";
        }
        echo " }
.";
        // line 22
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 22, $this->source), "html", null, true);
        echo ".coh-ce-project_card-4ca1877a { position: relative; z-index: 1; ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "28cc9630-243d-4f5d-9521-090cf6e4f662"))) {
            echo " -webkit-filter: blur(";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "28cc9630-243d-4f5d-9521-090cf6e4f662"));
            echo ");";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "28cc9630-243d-4f5d-9521-090cf6e4f662"))) {
            echo " filter: blur(";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "28cc9630-243d-4f5d-9521-090cf6e4f662"));
            echo ");";
        }
        echo " ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "341764d1-4b77-46a1-b86b-be128856b272"))) {
            echo " opacity: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "341764d1-4b77-46a1-b86b-be128856b272"));
            echo ";";
        }
        echo " }
</style>";
        $context["compiledCSS"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 23
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderInlineStyle($this->sandbox->ensureToStringAllowed(($context["compiledCSS"] ?? null), 23, $this->source)));
    }

    public function getTemplateName()
    {
        return "sites/default/files/cohesion/templates/component--cohesion-project-card.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  256 => 23,  233 => 22,  223 => 21,  212 => 19,  207 => 17,  196 => 15,  185 => 13,  180 => 11,  175 => 9,  170 => 7,  165 => 5,  150 => 4,  46 => 3,  43 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "sites/default/files/cohesion/templates/component--cohesion-project-card.html.twig", "/Users/kdruckman/Sites/acquia_cms/docroot/sites/default/files/cohesion/templates/component--cohesion-project-card.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "if" => 3);
        static $filters = array("escape" => 1, "join" => 3, "split" => 3, "raw" => 3, "trim" => 3, "render" => 4);
        static $functions = array("coh_instanceid" => 1, "attach_library" => 3, "has_drupal_permission" => 3, "getComponentFieldValue" => 3, "path_renderer" => 3, "cohesion_image_style" => 3, "renderInlineStyle" => 23);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['escape', 'join', 'split', 'raw', 'trim', 'render'],
                ['coh_instanceid', 'attach_library', 'has_drupal_permission', 'getComponentFieldValue', 'path_renderer', 'cohesion_image_style', 'renderInlineStyle']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
