<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* sites/default/files/cohesion/templates/component--cohesion-cpt-site-footer.html.twig */
class __TwigTemplate_cf2239fe8dfc856b1971e5ff8841138d1ab0464b7d6c2cb9f320c7c66d20215b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.drupal-menu"), "html", null, true);
        echo " ";
        if ((($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->hasDrupalPermission([0 => "access contextual links", 1 => "access components"]) &&  !($context["isPreview"] ?? null)) &&  !(isset($context["hideContextualLinks"]) || array_key_exists("hideContextualLinks", $context)))) {
            echo " <div class=\"dx-contextual-region contextual-region\" data-dx-contextual=\"coh-component-instance-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 1, $this->source), "html", null, true);
            echo "\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 1, $this->source), "html", null, true);
            echo "</div> ";
        }
        echo " <footer class=\"coh-container coh-component coh-component-instance-";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 1, $this->source), "html", null, true);
        echo " contextual-component ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "5e8437ec-afc1-49fe-8bbc-0323706449a1"));
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "32c0b885-cb2d-48cd-a01f-607b86ac4253"));
        echo " coh-style-focusable-content coh-ce-cpt_site_footer-a55124d3\" > <div class=\"coh-container primary-row coh-ce-cpt_site_footer-7db95991\" > <div class=\"coh-container coh-ce-cpt_site_footer-607d5298\" > </div> <div class=\"coh-container\" > <nav class=\"coh-container footer-menu coh-ce-cpt_site_footer-1a90bda\" > ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderMenu("footer", "menu_tpl_footer", false, 1), "html", null, true);
        echo " </nav> </div> <div class=\"coh-container coh-ce-cpt_site_footer-6c573274\" > ";
        ob_start(function () { return ''; });
        echo t("facebook", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_0_b7b48e2f_427c_41dd_8b1f_480be3bce017"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("https://www.facebook.com/acquia", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_0_523afe0e_2cab_42d3_a845_53944be67431"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("Follow us on Facebook", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_0_41e4bef4_fb24_4953_9bc1_e7896b7e2507"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("twitter", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_1_b7b48e2f_427c_41dd_8b1f_480be3bce017"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("https://www.twitter.com/acquia", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_1_523afe0e_2cab_42d3_a845_53944be67431"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("Follow us on Twitter", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_1_41e4bef4_fb24_4953_9bc1_e7896b7e2507"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("linkedin", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_2_b7b48e2f_427c_41dd_8b1f_480be3bce017"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("https://www.linkedin.com/acquia", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_2_523afe0e_2cab_42d3_a845_53944be67431"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("Follow us on Linked In", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_2_41e4bef4_fb24_4953_9bc1_e7896b7e2507"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("pinterest", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_3_b7b48e2f_427c_41dd_8b1f_480be3bce017"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("https://www.pinterest.com/acquia", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_3_523afe0e_2cab_42d3_a845_53944be67431"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("Follow us on Pinterest", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_3_41e4bef4_fb24_4953_9bc1_e7896b7e2507"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("facebook", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_b7b48e2f_427c_41dd_8b1f_480be3bce017"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("https://www.facebook.com/acquia", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_523afe0e_2cab_42d3_a845_53944be67431"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo t("Follow us on Facebook", array(), ["langcode" => $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getContentLanguage()]);
        $context["component_variable_41e4bef4_fb24_4953_9bc1_e7896b7e2507"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["hideContextualLinks"] = ('' === $tmp = "1") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_social_links", true, $this->sandbox->ensureToStringAllowed($context, 1, $this->source), ["8fa56baf-1a4e-482a-9631-c69d45e3079b" => [0 => ["b7b48e2f-427c-41dd-8b1f-480be3bce017" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_0_b7b48e2f_427c_41dd_8b1f_480be3bce017", "523afe0e-2cab-42d3-a845-53944be67431" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_0_523afe0e_2cab_42d3_a845_53944be67431", "41e4bef4-fb24-4953-9bc1-e7896b7e2507" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_0_41e4bef4_fb24_4953_9bc1_e7896b7e2507"], 1 => ["b7b48e2f-427c-41dd-8b1f-480be3bce017" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_1_b7b48e2f_427c_41dd_8b1f_480be3bce017", "523afe0e-2cab-42d3-a845-53944be67431" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_1_523afe0e_2cab_42d3_a845_53944be67431", "41e4bef4-fb24-4953-9bc1-e7896b7e2507" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_1_41e4bef4_fb24_4953_9bc1_e7896b7e2507"], 2 => ["b7b48e2f-427c-41dd-8b1f-480be3bce017" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_2_b7b48e2f_427c_41dd_8b1f_480be3bce017", "523afe0e-2cab-42d3-a845-53944be67431" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_2_523afe0e_2cab_42d3_a845_53944be67431", "41e4bef4-fb24-4953-9bc1-e7896b7e2507" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_2_41e4bef4_fb24_4953_9bc1_e7896b7e2507"], 3 => ["b7b48e2f-427c-41dd-8b1f-480be3bce017" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_3_b7b48e2f_427c_41dd_8b1f_480be3bce017", "523afe0e-2cab-42d3-a845-53944be67431" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_3_523afe0e_2cab_42d3_a845_53944be67431", "41e4bef4-fb24-4953-9bc1-e7896b7e2507" => "component_variable_8fa56baf_1a4e_482a_9631_c69d45e3079b_3_41e4bef4_fb24_4953_9bc1_e7896b7e2507"]], "b7b48e2f-427c-41dd-8b1f-480be3bce017" => "component_variable_b7b48e2f_427c_41dd_8b1f_480be3bce017", "523afe0e-2cab-42d3-a845-53944be67431" => "component_variable_523afe0e_2cab_42d3_a845_53944be67431", "41e4bef4-fb24-4953-9bc1-e7896b7e2507" => "component_variable_41e4bef4_fb24_4953_9bc1_e7896b7e2507"], "dd069b1c-3a85-4302-bcb5-d17b11ac82d0", ""), "html", null, true);
        echo " </div> </div> <div class=\"coh-container secondary-row coh-ce-cpt_site_footer-6b4ab1ad\" > <div class=\"coh-container coh-ce-cpt_site_footer-595b4965\" > <div class=\"coh-wysiwyg\"> ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "f9f11fad-85d9-46d9-adc8-7630861fbdac", "#text"), "html", null, true);
        $context["wysiwyg"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "f9f11fad-85d9-46d9-adc8-7630861fbdac", "#textFormat"), "html", null, true);
        $context["text_format"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "f9f11fad-85d9-46d9-adc8-7630861fbdac", ""), "html", null, true);
        $context["token_text"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->formatWysiwyg($this->sandbox->ensureToStringAllowed(($context["wysiwyg"] ?? null), 1, $this->source), $this->sandbox->ensureToStringAllowed(($context["text_format"] ?? null), 1, $this->source), $this->sandbox->ensureToStringAllowed(($context["token_text"] ?? null), 1, $this->source)), "html", null, true);
        echo " </div> </div> <div class=\"coh-container coh-ce-cpt_site_footer-7974db9e\" > <div class=\"coh-wysiwyg\"> ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "edd0c3b4-30a5-446c-bdea-adf60e363ff2", "#text"), "html", null, true);
        $context["wysiwyg"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "edd0c3b4-30a5-446c-bdea-adf60e363ff2", "#textFormat"), "html", null, true);
        $context["text_format"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "edd0c3b4-30a5-446c-bdea-adf60e363ff2", ""), "html", null, true);
        $context["token_text"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->formatWysiwyg($this->sandbox->ensureToStringAllowed(($context["wysiwyg"] ?? null), 1, $this->source), $this->sandbox->ensureToStringAllowed(($context["text_format"] ?? null), 1, $this->source), $this->sandbox->ensureToStringAllowed(($context["token_text"] ?? null), 1, $this->source)), "html", null, true);
        echo " </div> </div> </div> </footer> 
";
        // line 2
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 2, $this->source));
        }
    }

    public function getTemplateName()
    {
        return "sites/default/files/cohesion/templates/component--cohesion-cpt-site-footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "sites/default/files/cohesion/templates/component--cohesion-cpt-site-footer.html.twig", "/Users/kdruckman/Sites/acquia_cms/docroot/sites/default/files/cohesion/templates/component--cohesion-cpt-site-footer.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 1, "set" => 1, "trans" => 1);
        static $filters = array("escape" => 1, "raw" => 1, "render" => 2);
        static $functions = array("attach_library" => 1, "has_drupal_permission" => 1, "getComponentFieldValue" => 1, "render_menu" => 1, "get_content_language" => 1, "renderComponent" => 1, "format_wysiwyg" => 1);

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set', 'trans'],
                ['escape', 'raw', 'render'],
                ['attach_library', 'has_drupal_permission', 'getComponentFieldValue', 'render_menu', 'get_content_language', 'renderComponent', 'format_wysiwyg']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
