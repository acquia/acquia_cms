<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__e991e7e2c592e9aee9c510af433c51d827c282a307bae8a36c8d83e2b9537f08 */
class __TwigTemplate_b7791338a654a871a19f6d279f75514cd13e067badb498e69ee49df0ecab1401 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block1656450052' => [$this, 'block_block1656450052'],
            'block1071527019' => [$this, 'block_block1071527019'],
            'block1269039160' => [$this, 'block_block1269039160'],
            'block1833572258' => [$this, 'block_block1833572258'],
            'block1693841613' => [$this, 'block_block1693841613'],
            'block797572479' => [$this, 'block_block797572479'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        $context["component_variable_a79b4b56_70ee_420d_b0ff_be026391bc1a"] = false;
        echo " ";
        $context["component_variable_33467589_5892_41d3_b1c1_fe04f053df8e"] = ('' === $tmp = "Acquia CMS starter kit.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78ab8d68_8bc0_4ada_a668_3c24c67a94e0_text"] = ('' === $tmp = "<p>This is placeholder text. If you are reading this, it is here by mistake and we would appreciate it if you could email us with a link to the page you found it on.&nbsp;</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 2
        echo " ";
        $context["component_variable_78ab8d68_8bc0_4ada_a668_3c24c67a94e0_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d7dc850d_3030_4316_b778_40aba3465abf"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b7b68756_96df_45b6_a611_060f86836d06"] = ('' === $tmp = "Find out more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_2870bc76_3def_451f_ae8e_c43c3315a3a6"] = ('' === $tmp = "_self") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_de884b6a_5562_42c2_b6c7_2b10cde62135"] = ('' === $tmp = "coh-style-link-button-color") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_c205de8f_490a_45f5_bdf7_1302262dff29"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a81fe8e5_6819_419b_b672_1992944d6e0e"] = ('' === $tmp = "tall") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8f06b2b8_2cf7_46e4_a157_df4ecb82616e"] = ('' === $tmp = "left-align-content") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:12eb1358-0f9b-4885-8d72-1d991aff863f]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 2, $this->source), false), "html", null, true);
        $context["component_variable_298f9e5d_49ed_428b_ac9c_5802cecb03fb"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3488ef37_a844_4cd1_be55_9cbe7097d1ca"] = ('' === $tmp = "image-no-overlay") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d2da98a2_83de_4f65_b9f1_3495b3eba524"] = ('' === $tmp = "coh-style-text-color-dark-background") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_09a46fc3_8aad_4aab_aceb_efae824bb9c0"] = ('' === $tmp = "coh-style-text-color-dark-background") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1656450052', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if (twig_test_empty(twig_trim_filter(($context["dropZoneContent"] ?? null)))) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderInlineStyle("<style>.drop-zone-content { display: none; }</style>"));
        }
        echo " ";
        if ( !array_key_exists("dropZones", $context)) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["c87df6db-a4d4-4710-a628-54bb5feda3af" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_hero", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["a79b4b56-70ee-420d-b0ff-be026391bc1a" => "component_variable_a79b4b56_70ee_420d_b0ff_be026391bc1a", "33467589-5892-41d3-b1c1-fe04f053df8e" => "component_variable_33467589_5892_41d3_b1c1_fe04f053df8e", "78ab8d68-8bc0-4ada-a668-3c24c67a94e0" => ["text" => "component_variable_78ab8d68_8bc0_4ada_a668_3c24c67a94e0_text", "textFormat" => "component_variable_78ab8d68_8bc0_4ada_a668_3c24c67a94e0_textFormat"], "d7dc850d-3030-4316-b778-40aba3465abf" => "component_variable_d7dc850d_3030_4316_b778_40aba3465abf", "b7b68756-96df-45b6-a611-060f86836d06" => "component_variable_b7b68756_96df_45b6_a611_060f86836d06", "2870bc76-3def-451f-ae8e-c43c3315a3a6" => "component_variable_2870bc76_3def_451f_ae8e_c43c3315a3a6", "de884b6a-5562-42c2-b6c7-2b10cde62135" => "component_variable_de884b6a_5562_42c2_b6c7_2b10cde62135", "c205de8f-490a-45f5-bdf7-1302262dff29" => "component_variable_c205de8f_490a_45f5_bdf7_1302262dff29", "a81fe8e5-6819-419b-b672-1992944d6e0e" => "component_variable_a81fe8e5_6819_419b_b672_1992944d6e0e", "8f06b2b8-2cf7-46e4-a157-df4ecb82616e" => "component_variable_8f06b2b8_2cf7_46e4_a157_df4ecb82616e", "298f9e5d-49ed-428b-ac9c-5802cecb03fb" => "component_variable_298f9e5d_49ed_428b_ac9c_5802cecb03fb", "3488ef37-a844-4cd1-be55-9cbe7097d1ca" => "component_variable_3488ef37_a844_4cd1_be55_9cbe7097d1ca", "d2da98a2-83de-4f65-b9f1-3495b3eba524" => "component_variable_d2da98a2_83de_4f65_b9f1_3495b3eba524", "09a46fc3-8aad-4aab-aceb-efae824bb9c0" => "component_variable_09a46fc3_8aad_4aab_aceb_efae824bb9c0"]), "4a80ab86-2784-4d1a-a18d-7fd28da58981", ""), "html", null, true);
        echo " ";
        $context["component_variable_c469e24d_d155_46d5_a9ca_dc61028163c6"] = ('' === $tmp = "boxed") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_2647a498_53ac_4cf2_84d7_9a621dd838a0"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74a865c3_d896_45d6_ba96_5ac344ad9942"] = ('' === $tmp = "coh-style-padding-top-large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_2a2a10d2_02a6_4263_a8a7_6c84701354f9"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f8f8754f_4921_41ee_bb30_47fc98451736"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6b754e7a_6c7c_4ed2_9399_b64496075e6b"] = 12;
        echo " ";
        $context["component_variable_ad62c677_81e9_4361_b36d_905eceb8fce9"] =  -1;
        echo " ";
        $context["component_variable_4939e8b3_bae0_47ca_9527_5d7be5138e51"] =  -1;
        echo " ";
        $context["component_variable_d5dbd40f_6af7_413c_a38e_323fc3154a58"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0214b304_c34f_4155_8795_52cd1c5621cb"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5dcf43ba_fc68_44d2_a27c_03a042c3158e"] = 12;
        echo " ";
        $context["component_variable_d7af9c66_4d99_4107_8709_fd9f399d14cb"] =  -1;
        echo " ";
        $context["component_variable_6f05f900_24d3_4a0c_85ab_1e783ac9d8e7"] =  -1;
        echo " ";
        $context["component_variable_6e2005ad_103a_4e90_a28f_b12587182f5e"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_00ba9989_9e6f_40ba_b0a5_741c79bd5659"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_09032d58_36ec_4b7d_93f0_ce4110e125c0"] = 12;
        echo " ";
        $context["component_variable_8cf47e32_7b34_4185_a2ba_731420fd6d98"] = false;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1071527019', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !array_key_exists("dropZones", $context)) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["c0116a84-e80c-428d-b6ff-ae43dda904f7" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_1_column_layout", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["c469e24d-d155-46d5-a9ca-dc61028163c6" => "component_variable_c469e24d_d155_46d5_a9ca_dc61028163c6", "2647a498-53ac-4cf2-84d7-9a621dd838a0" => "component_variable_2647a498_53ac_4cf2_84d7_9a621dd838a0", "74a865c3-d896-45d6-ba96-5ac344ad9942" => "component_variable_74a865c3_d896_45d6_ba96_5ac344ad9942", "2a2a10d2-02a6-4263-a8a7-6c84701354f9" => "component_variable_2a2a10d2_02a6_4263_a8a7_6c84701354f9", "f8f8754f-4921-41ee-bb30-47fc98451736" => "component_variable_f8f8754f_4921_41ee_bb30_47fc98451736", "6b754e7a-6c7c-4ed2-9399-b64496075e6b" => "component_variable_6b754e7a_6c7c_4ed2_9399_b64496075e6b", "ad62c677-81e9-4361-b36d-905eceb8fce9" => "component_variable_ad62c677_81e9_4361_b36d_905eceb8fce9", "4939e8b3-bae0-47ca-9527-5d7be5138e51" => "component_variable_4939e8b3_bae0_47ca_9527_5d7be5138e51", "d5dbd40f-6af7-413c-a38e-323fc3154a58" => "component_variable_d5dbd40f_6af7_413c_a38e_323fc3154a58", "0214b304-c34f-4155-8795-52cd1c5621cb" => "component_variable_0214b304_c34f_4155_8795_52cd1c5621cb", "5dcf43ba-fc68-44d2-a27c-03a042c3158e" => "component_variable_5dcf43ba_fc68_44d2_a27c_03a042c3158e", "d7af9c66-4d99-4107-8709-fd9f399d14cb" => "component_variable_d7af9c66_4d99_4107_8709_fd9f399d14cb", "6f05f900-24d3-4a0c-85ab-1e783ac9d8e7" => "component_variable_6f05f900_24d3_4a0c_85ab_1e783ac9d8e7", "6e2005ad-103a-4e90-a28f-b12587182f5e" => "component_variable_6e2005ad_103a_4e90_a28f_b12587182f5e", "00ba9989-9e6f-40ba-b0a5-741c79bd5659" => "component_variable_00ba9989_9e6f_40ba_b0a5_741c79bd5659", "09032d58-36ec-4b7d-93f0-ce4110e125c0" => "component_variable_09032d58_36ec_4b7d_93f0_ce4110e125c0", "8cf47e32-7b34-4185-a2ba-731420fd6d98" => "component_variable_8cf47e32_7b34_4185_a2ba_731420fd6d98"]), "29ac92f0-2723-47a6-ba72-baf2a10da41e", ""), "html", null, true);
        echo " ";
        $context["component_variable_c8e8ad0b_bf8c_4e35_a411_a7a0bc930666"] = ('' === $tmp = "boxed") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_91837ed6_c3a6_4dbd_a638_16bc3565dd9c"] = ('' === $tmp = "space-between") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_87497e8f_9e82_4a35_910a_de7aa0bbd9fe"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_804390ef_6522_4ca5_9391_3d49799a92e0"] = ('' === $tmp = "coh-style-padding-bottom-large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3948be28_30af_4936_8373_7d02d7c5eea6"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_aa8d634d_187b_480c_83e3_3651ba58949c"] = 3;
        echo " ";
        $context["component_variable_5544549e_c784_4f2e_b390_b5cb420417bc"] = 0;
        echo " ";
        $context["component_variable_b745167a_cf1e_4e1c_aedd_c5bd83c81267"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9833feea_05df_45b2_97c0_c5059c0fa7e2"] =  -1;
        echo " ";
        $context["component_variable_e4a1fc19_0a73_4238_ab76_64266377b4c5"] =  -1;
        echo " ";
        $context["component_variable_b5fb5a18_4e0d_4e40_81e0_5fa0377422bb"] = 3;
        echo " ";
        $context["component_variable_74d9a7c5_ce24_4b96_b0eb_4cb380d48406"] = 1;
        echo " ";
        $context["component_variable_6f22f34c_d030_4f52_a878_d55621fb3028"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1183fbc4_fe8e_4543_9561_73d5bee1044e"] =  -1;
        echo " ";
        $context["component_variable_8e8d4b0f_d55d_4372_89ca_79153ac074d1"] =  -1;
        echo " ";
        $context["component_variable_70a89823_cca6_4032_9265_f8f68c7c64bd"] = 3;
        echo " ";
        $context["component_variable_20a655db_626f_44c7_9039_46f2fe4c944b"] = 2;
        echo " ";
        $context["component_variable_a2cd05e8_95f6_4a78_b171_e1b42b163b3a"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4b3d0ecb_fa6c_4746_a4b1_448b54935cf3"] =  -1;
        echo " ";
        $context["component_variable_90143a1f_3176_4024_b2d3_ccbce74eeed0"] =  -1;
        echo " ";
        $context["component_variable_6e05b8e1_e1a7_4591_88dd_2d660aad3692"] = 3;
        echo " ";
        $context["component_variable_d5125bc6_d059_4e76_b310_eec235df4995"] = 3;
        echo " ";
        $context["component_variable_6b6ea996_d0b0_4fdc_b40a_5f908d7b6943"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10a6a41c_b710_4705_8aed_2e5e442f74d8"] =  -1;
        echo " ";
        $context["component_variable_1c017e8d_b1e2_4df7_876c_1c85c4a3aad2"] =  -1;
        echo " ";
        $context["component_variable_25907a32_2fc3_47c7_8b36_3841e93e418b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a66d660b_1db4_476f_a101_f8e066fb5706"] = 6;
        echo " ";
        $context["component_variable_5d13ac9d_9e51_4f85_835a_d27c896ade8a"] = 0;
        echo " ";
        $context["component_variable_19de54be_4a19_4023_960d_3002a83b3db7"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_7a6c8310_cab8_4437_a1be_162b53814d7c"] =  -1;
        echo " ";
        $context["component_variable_b59809ab_67ed_4fe3_afb4_b9967d0cf9b8"] =  -1;
        echo " ";
        $context["component_variable_876e5c8c_f65e_42dc_ace0_a18a857772bf"] = 6;
        echo " ";
        $context["component_variable_c9fba716_0998_44c4_a6f0_9b7d0f2b3041"] = 1;
        echo " ";
        $context["component_variable_527948fa_60e0_4cdc_86ab_984994b2217d"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8a19acce_cbc7_4430_b34b_6c56a1df8ebf"] =  -1;
        echo " ";
        $context["component_variable_1e2b8a6f_3a1a_4ea2_9097_4d52fbd00077"] =  -1;
        echo " ";
        $context["component_variable_3091b76e_d751_4be4_ad35_9f681ecf4875"] = 6;
        echo " ";
        $context["component_variable_fdfd1965_a0ac_4e3d_a1af_217bb3f32713"] = 2;
        echo " ";
        $context["component_variable_e1cfa7f9_d265_43c2_af8d_826c2e33ca28"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_511e6c4b_73ef_4bda_8fb2_60ce83614797"] =  -1;
        echo " ";
        $context["component_variable_c53399de_2c7d_489e_8142_2ea0ea33e532"] =  -1;
        echo " ";
        $context["component_variable_6cd93b8f_6a89_4008_83c8_fb68b1742526"] = 6;
        echo " ";
        $context["component_variable_7ab1bf68_4815_4d22_a79e_6b2773cd4b15"] = 3;
        echo " ";
        $context["component_variable_e370c646_c188_4c03_bfd3_a175e442ba6f"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10fd2766_20c4_4075_ad5d_91379fefed5a"] =  -1;
        echo " ";
        $context["component_variable_c1668204_5223_4b1d_9b03_cec8b0b097b4"] =  -1;
        echo " ";
        $context["component_variable_6e1f484b_fe2b_4722_95e4_757c41eab3e6"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a58f3693_933a_4c57_b68c_e2b5794a15a1"] = 12;
        echo " ";
        $context["component_variable_22bfafa6_4125_4d39_b149_8a5237b690fb"] = 0;
        echo " ";
        $context["component_variable_9f3915da_cc7a_4986_811e_b6943efac87f"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3306a50f_985b_4d58_b035_2f35984ca751"] = 12;
        echo " ";
        $context["component_variable_17bad372_9c34_446e_98d2_9f90014e400a"] = 1;
        echo " ";
        $context["component_variable_b93c4a6e_5161_4f0a_9caf_f3e52b036c19"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4355f0c0_28f9_4963_9ea0_94c02007be58"] = 12;
        echo " ";
        $context["component_variable_6a475b8d_f762_44da_8ad5_aeab81c71322"] = 2;
        echo " ";
        $context["component_variable_eac28d03_8243_43dc_ba51_80de2ea4ace0"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90aff730_74b8_44da_960b_e7c663d90845"] = 12;
        echo " ";
        $context["component_variable_eeae3392_2272_4da2_b1de_391f024c4e2a"] = 3;
        echo " ";
        $context["component_variable_960c0768_8b1c_48d9_b92b_48e8fb45d90d"] = ('' === $tmp = "flex-start") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_38cf2f9d_72c4_4107_879d_68e05cfb2291"] = false;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1269039160', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !array_key_exists("dropZones", $context)) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["edd169b1-216f-4fe4-acc5-bc49aee26aea" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1833572258', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !array_key_exists("dropZones", $context)) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["848b18e6-7791-4e8a-a94d-7be1f15ed5ad" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1693841613', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !array_key_exists("dropZones", $context)) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["ab2e107c-f229-4776-829e-02a8854af3c6" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block797572479', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !array_key_exists("dropZones", $context)) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["1fd065a6-bb9a-4589-8058-04cd0ae40fc5" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_4_column_layout", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 2, $this->source), ["c8e8ad0b-bf8c-4e35-a411-a7a0bc930666" => "component_variable_c8e8ad0b_bf8c_4e35_a411_a7a0bc930666", "91837ed6-c3a6-4dbd-a638-16bc3565dd9c" => "component_variable_91837ed6_c3a6_4dbd_a638_16bc3565dd9c", "87497e8f-9e82-4a35-910a-de7aa0bbd9fe" => "component_variable_87497e8f_9e82_4a35_910a_de7aa0bbd9fe", "804390ef-6522-4ca5-9391-3d49799a92e0" => "component_variable_804390ef_6522_4ca5_9391_3d49799a92e0", "3948be28-30af-4936-8373-7d02d7c5eea6" => "component_variable_3948be28_30af_4936_8373_7d02d7c5eea6", "aa8d634d-187b-480c-83e3-3651ba58949c" => "component_variable_aa8d634d_187b_480c_83e3_3651ba58949c", "5544549e-c784-4f2e-b390-b5cb420417bc" => "component_variable_5544549e_c784_4f2e_b390_b5cb420417bc", "b745167a-cf1e-4e1c-aedd-c5bd83c81267" => "component_variable_b745167a_cf1e_4e1c_aedd_c5bd83c81267", "9833feea-05df-45b2-97c0-c5059c0fa7e2" => "component_variable_9833feea_05df_45b2_97c0_c5059c0fa7e2", "e4a1fc19-0a73-4238-ab76-64266377b4c5" => "component_variable_e4a1fc19_0a73_4238_ab76_64266377b4c5", "b5fb5a18-4e0d-4e40-81e0-5fa0377422bb" => "component_variable_b5fb5a18_4e0d_4e40_81e0_5fa0377422bb", "74d9a7c5-ce24-4b96-b0eb-4cb380d48406" => "component_variable_74d9a7c5_ce24_4b96_b0eb_4cb380d48406", "6f22f34c-d030-4f52-a878-d55621fb3028" => "component_variable_6f22f34c_d030_4f52_a878_d55621fb3028", "1183fbc4-fe8e-4543-9561-73d5bee1044e" => "component_variable_1183fbc4_fe8e_4543_9561_73d5bee1044e", "8e8d4b0f-d55d-4372-89ca-79153ac074d1" => "component_variable_8e8d4b0f_d55d_4372_89ca_79153ac074d1", "70a89823-cca6-4032-9265-f8f68c7c64bd" => "component_variable_70a89823_cca6_4032_9265_f8f68c7c64bd", "20a655db-626f-44c7-9039-46f2fe4c944b" => "component_variable_20a655db_626f_44c7_9039_46f2fe4c944b", "a2cd05e8-95f6-4a78-b171-e1b42b163b3a" => "component_variable_a2cd05e8_95f6_4a78_b171_e1b42b163b3a", "4b3d0ecb-fa6c-4746-a4b1-448b54935cf3" => "component_variable_4b3d0ecb_fa6c_4746_a4b1_448b54935cf3", "90143a1f-3176-4024-b2d3-ccbce74eeed0" => "component_variable_90143a1f_3176_4024_b2d3_ccbce74eeed0", "6e05b8e1-e1a7-4591-88dd-2d660aad3692" => "component_variable_6e05b8e1_e1a7_4591_88dd_2d660aad3692", "d5125bc6-d059-4e76-b310-eec235df4995" => "component_variable_d5125bc6_d059_4e76_b310_eec235df4995", "6b6ea996-d0b0-4fdc-b40a-5f908d7b6943" => "component_variable_6b6ea996_d0b0_4fdc_b40a_5f908d7b6943", "10a6a41c-b710-4705-8aed-2e5e442f74d8" => "component_variable_10a6a41c_b710_4705_8aed_2e5e442f74d8", "1c017e8d-b1e2-4df7-876c-1c85c4a3aad2" => "component_variable_1c017e8d_b1e2_4df7_876c_1c85c4a3aad2", "25907a32-2fc3-47c7-8b36-3841e93e418b" => "component_variable_25907a32_2fc3_47c7_8b36_3841e93e418b", "a66d660b-1db4-476f-a101-f8e066fb5706" => "component_variable_a66d660b_1db4_476f_a101_f8e066fb5706", "5d13ac9d-9e51-4f85-835a-d27c896ade8a" => "component_variable_5d13ac9d_9e51_4f85_835a_d27c896ade8a", "19de54be-4a19-4023-960d-3002a83b3db7" => "component_variable_19de54be_4a19_4023_960d_3002a83b3db7", "7a6c8310-cab8-4437-a1be-162b53814d7c" => "component_variable_7a6c8310_cab8_4437_a1be_162b53814d7c", "b59809ab-67ed-4fe3-afb4-b9967d0cf9b8" => "component_variable_b59809ab_67ed_4fe3_afb4_b9967d0cf9b8", "876e5c8c-f65e-42dc-ace0-a18a857772bf" => "component_variable_876e5c8c_f65e_42dc_ace0_a18a857772bf", "c9fba716-0998-44c4-a6f0-9b7d0f2b3041" => "component_variable_c9fba716_0998_44c4_a6f0_9b7d0f2b3041", "527948fa-60e0-4cdc-86ab-984994b2217d" => "component_variable_527948fa_60e0_4cdc_86ab_984994b2217d", "8a19acce-cbc7-4430-b34b-6c56a1df8ebf" => "component_variable_8a19acce_cbc7_4430_b34b_6c56a1df8ebf", "1e2b8a6f-3a1a-4ea2-9097-4d52fbd00077" => "component_variable_1e2b8a6f_3a1a_4ea2_9097_4d52fbd00077", "3091b76e-d751-4be4-ad35-9f681ecf4875" => "component_variable_3091b76e_d751_4be4_ad35_9f681ecf4875", "fdfd1965-a0ac-4e3d-a1af-217bb3f32713" => "component_variable_fdfd1965_a0ac_4e3d_a1af_217bb3f32713", "e1cfa7f9-d265-43c2-af8d-826c2e33ca28" => "component_variable_e1cfa7f9_d265_43c2_af8d_826c2e33ca28", "511e6c4b-73ef-4bda-8fb2-60ce83614797" => "component_variable_511e6c4b_73ef_4bda_8fb2_60ce83614797", "c53399de-2c7d-489e-8142-2ea0ea33e532" => "component_variable_c53399de_2c7d_489e_8142_2ea0ea33e532", "6cd93b8f-6a89-4008-83c8-fb68b1742526" => "component_variable_6cd93b8f_6a89_4008_83c8_fb68b1742526", "7ab1bf68-4815-4d22-a79e-6b2773cd4b15" => "component_variable_7ab1bf68_4815_4d22_a79e_6b2773cd4b15", "e370c646-c188-4c03-bfd3-a175e442ba6f" => "component_variable_e370c646_c188_4c03_bfd3_a175e442ba6f", "10fd2766-20c4-4075-ad5d-91379fefed5a" => "component_variable_10fd2766_20c4_4075_ad5d_91379fefed5a", "c1668204-5223-4b1d-9b03-cec8b0b097b4" => "component_variable_c1668204_5223_4b1d_9b03_cec8b0b097b4", "6e1f484b-fe2b-4722-95e4-757c41eab3e6" => "component_variable_6e1f484b_fe2b_4722_95e4_757c41eab3e6", "a58f3693-933a-4c57-b68c-e2b5794a15a1" => "component_variable_a58f3693_933a_4c57_b68c_e2b5794a15a1", "22bfafa6-4125-4d39-b149-8a5237b690fb" => "component_variable_22bfafa6_4125_4d39_b149_8a5237b690fb", "9f3915da-cc7a-4986-811e-b6943efac87f" => "component_variable_9f3915da_cc7a_4986_811e_b6943efac87f", "3306a50f-985b-4d58-b035-2f35984ca751" => "component_variable_3306a50f_985b_4d58_b035_2f35984ca751", "17bad372-9c34-446e-98d2-9f90014e400a" => "component_variable_17bad372_9c34_446e_98d2_9f90014e400a", "b93c4a6e-5161-4f0a-9caf-f3e52b036c19" => "component_variable_b93c4a6e_5161_4f0a_9caf_f3e52b036c19", "4355f0c0-28f9-4963-9ea0-94c02007be58" => "component_variable_4355f0c0_28f9_4963_9ea0_94c02007be58", "6a475b8d-f762-44da-8ad5-aeab81c71322" => "component_variable_6a475b8d_f762_44da_8ad5_aeab81c71322", "eac28d03-8243-43dc-ba51-80de2ea4ace0" => "component_variable_eac28d03_8243_43dc_ba51_80de2ea4ace0", "90aff730-74b8-44da-960b-e7c663d90845" => "component_variable_90aff730_74b8_44da_960b_e7c663d90845", "eeae3392-2272-4da2-b1de-391f024c4e2a" => "component_variable_eeae3392_2272_4da2_b1de_391f024c4e2a", "960c0768-8b1c-48d9-b92b-48e8fb45d90d" => "component_variable_960c0768_8b1c_48d9_b92b_48e8fb45d90d", "38cf2f9d-72c4-4107-879d-68e05cfb2291" => "component_variable_38cf2f9d_72c4_4107_879d_68e05cfb2291"]), "a32a417a-bd8b-4257-9eb8-6e2bcc82584b", ""), "html", null, true);
        echo " 
";
        // line 3
        if (array_key_exists("content", $context)) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 3, $this->source));
        }
    }

    // line 2
    public function block_block1656450052($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "aa9d2303-38af-4a29-bd4d-fc52465c30c4", "start"), "html", null, true);
        echo " ";
        $context["component_variable_408a3712_f751_45c4_9e23_a8f66babb11b_entity_entityUUID"] = ('' === $tmp = "7922d3d5-8e61-4344-b842-3bc5daa97823") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_408a3712_f751_45c4_9e23_a8f66babb11b_entity_entityId"] = 91;
        echo " ";
        $context["component_variable_408a3712_f751_45c4_9e23_a8f66babb11b_entity_entityType"] = ('' === $tmp = "media") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3737bce5_fe1c_4fec_a46d_7e505446081e"] = ('' === $tmp = "media.large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_435844da_58e5_4af0_ae71_76cee28e79b8"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_14a92358_62f1_4a02_b339_d021cdc2f6d7"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_image_media", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), ["408a3712-f751-45c4-9e23-a8f66babb11b" => ["entity" => ["entityUUID" => "component_variable_408a3712_f751_45c4_9e23_a8f66babb11b_entity_entityUUID", "entityId" => "component_variable_408a3712_f751_45c4_9e23_a8f66babb11b_entity_entityId", "entityType" => "component_variable_408a3712_f751_45c4_9e23_a8f66babb11b_entity_entityType"]], "3737bce5-fe1c-4fec-a46d-7e505446081e" => "component_variable_3737bce5_fe1c_4fec_a46d_7e505446081e", "435844da-58e5-4af0-ae71-76cee28e79b8" => "component_variable_435844da_58e5_4af0_ae71_76cee28e79b8", "14a92358-62f1-4a02-b339-d021cdc2f6d7" => "component_variable_14a92358_62f1_4a02_b339_d021cdc2f6d7"], "29314379-aead-48d7-b802-8042049ee29b", ""), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "aa9d2303-38af-4a29-bd4d-fc52465c30c4", "end"), "html", null, true);
    }

    public function block_block1071527019($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "1b463185-ec50-4a4d-abba-5c2b536c1586", "start"), "html", null, true);
        echo " ";
        $context["component_variable_ad025039_96c5_4cce_a27b_48778043471c"] = false;
        echo " ";
        $context["component_variable_50bae73f_99e4_446b_a738_9939a3dade60"] = ('' === $tmp = "What's included?") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e8f77e4e_3de9_47cc_b229_7040a4f78719"] = ('' === $tmp = "span") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_77d003da_6145_481e_95c8_2f6017361e26"] = ('' === $tmp = "coh-style-pre-heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_42c2324a_e7ee_45b6_ab1e_f5dfba48bfb2"] = ('' === $tmp = "align-text-center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fa5d575b_1d6e_44f0_a99e_1a2f7688bc27"] = ('' === $tmp = "color-heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_fb51822d_28f0_4f47_8776_f7d715c910f5"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_heading", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), ["ad025039-96c5-4cce-a27b-48778043471c" => "component_variable_ad025039_96c5_4cce_a27b_48778043471c", "50bae73f-99e4-446b-a738-9939a3dade60" => "component_variable_50bae73f_99e4_446b_a738_9939a3dade60", "e8f77e4e-3de9-47cc-b229-7040a4f78719" => "component_variable_e8f77e4e_3de9_47cc_b229_7040a4f78719", "77d003da-6145-481e-95c8-2f6017361e26" => "component_variable_77d003da_6145_481e_95c8_2f6017361e26", "42c2324a-e7ee-45b6-ab1e-f5dfba48bfb2" => "component_variable_42c2324a_e7ee_45b6_ab1e_f5dfba48bfb2", "fa5d575b-1d6e-44f0-a99e-1a2f7688bc27" => "component_variable_fa5d575b_1d6e_44f0_a99e_1a2f7688bc27", "fb51822d-28f0-4f47-8776-f7d715c910f5" => "component_variable_fb51822d_28f0_4f47_8776_f7d715c910f5"], "47191c65-30c7-4cec-844d-3b85e3ae691c", ""), "html", null, true);
        echo " ";
        $context["component_variable_ad025039_96c5_4cce_a27b_48778043471c"] = false;
        echo " ";
        $context["component_variable_50bae73f_99e4_446b_a738_9939a3dade60"] = ('' === $tmp = "Content types included with ACMS.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e8f77e4e_3de9_47cc_b229_7040a4f78719"] = ('' === $tmp = "h2") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_77d003da_6145_481e_95c8_2f6017361e26"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_42c2324a_e7ee_45b6_ab1e_f5dfba48bfb2"] = ('' === $tmp = "align-text-center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fa5d575b_1d6e_44f0_a99e_1a2f7688bc27"] = ('' === $tmp = "dark-heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fb51822d_28f0_4f47_8776_f7d715c910f5"] = ('' === $tmp = "coh-style-padding-bottom-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_heading", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), ["ad025039-96c5-4cce-a27b-48778043471c" => "component_variable_ad025039_96c5_4cce_a27b_48778043471c", "50bae73f-99e4-446b-a738-9939a3dade60" => "component_variable_50bae73f_99e4_446b_a738_9939a3dade60", "e8f77e4e-3de9-47cc-b229-7040a4f78719" => "component_variable_e8f77e4e_3de9_47cc_b229_7040a4f78719", "77d003da-6145-481e-95c8-2f6017361e26" => "component_variable_77d003da_6145_481e_95c8_2f6017361e26", "42c2324a-e7ee-45b6-ab1e-f5dfba48bfb2" => "component_variable_42c2324a_e7ee_45b6_ab1e_f5dfba48bfb2", "fa5d575b-1d6e-44f0-a99e-1a2f7688bc27" => "component_variable_fa5d575b_1d6e_44f0_a99e_1a2f7688bc27", "fb51822d-28f0-4f47-8776-f7d715c910f5" => "component_variable_fb51822d_28f0_4f47_8776_f7d715c910f5"], "decdd5fa-f391-4354-aa7b-d3418fdcb72e", ""), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "1b463185-ec50-4a4d-abba-5c2b536c1586", "end"), "html", null, true);
    }

    public function block_block1269039160($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "990cf3c9-e52c-48fd-b22b-148c242ebe9e", "start"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:0afe34a6-58f6-4790-90bc-a40de84c6605]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 2, $this->source), false), "html", null, true);
        $context["component_variable_ba4b212e_191c_4df3_b712_25124d00e538"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b9198246_859e_4944_bc2f_b639b1cfa7c0"] = ('' === $tmp = "h3") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d17ab758_d5e4_45f3_b278_2da8182ef2ec"] = ('' === $tmp = "Articles") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_95ac49b2_bc08_4865_a28a_35c7a8ebcb9e"] = ('' === $tmp = "A content type for creating articles and a list view for browsing them.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9ddccdc5_4d42_4472_af2a_29144a0513ff"] = ('' === $tmp = "View example articles") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e0d15462_9766_4214_953d_5ba57fe12247"] = ('' === $tmp = "view::articles::page") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_731fe3d3_5a42_40d4_9530_b8b0c4ab8c39"] = ('' === $tmp = "left-align-image-above") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_66db3f85_2d91_4b1d_8de6_09c431b022f4"] = ('' === $tmp = "rgba(242, 242, 242, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_de982cc8_28c7_4d33_a15e_6f0bab378767"] = ('' === $tmp = "coh-style-card-text-light-background") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1008c963_dbbe_4adf_bbaa_435253b9c415"] = ('' === $tmp = "coh-style-padding-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_be5e78dc_ed57_4d0b_9fc0_52a5f7e0c8d4"] = 1;
        echo " ";
        $context["component_variable_9dc78164_46af_4048_a2af_1fd90aa2acab"] = ('' === $tmp = "coh-style-margin-bottom-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dabdbb24_5c73_4b93_af7a_8dd6b4702337"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_84004344_e839_477f_a840_387f41958606"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_linked_feature_card", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), ["ba4b212e-191c-4df3-b712-25124d00e538" => "component_variable_ba4b212e_191c_4df3_b712_25124d00e538", "b9198246-859e-4944-bc2f-b639b1cfa7c0" => "component_variable_b9198246_859e_4944_bc2f_b639b1cfa7c0", "d17ab758-d5e4-45f3-b278-2da8182ef2ec" => "component_variable_d17ab758_d5e4_45f3_b278_2da8182ef2ec", "95ac49b2-bc08-4865-a28a-35c7a8ebcb9e" => "component_variable_95ac49b2_bc08_4865_a28a_35c7a8ebcb9e", "9ddccdc5-4d42-4472-af2a-29144a0513ff" => "component_variable_9ddccdc5_4d42_4472_af2a_29144a0513ff", "e0d15462-9766-4214-953d-5ba57fe12247" => "component_variable_e0d15462_9766_4214_953d_5ba57fe12247", "731fe3d3-5a42-40d4-9530-b8b0c4ab8c39" => "component_variable_731fe3d3_5a42_40d4_9530_b8b0c4ab8c39", "66db3f85-2d91-4b1d-8de6-09c431b022f4" => "component_variable_66db3f85_2d91_4b1d_8de6_09c431b022f4", "de982cc8-28c7-4d33-a15e-6f0bab378767" => "component_variable_de982cc8_28c7_4d33_a15e_6f0bab378767", "1008c963-dbbe-4adf-bbaa-435253b9c415" => "component_variable_1008c963_dbbe_4adf_bbaa_435253b9c415", "be5e78dc-ed57-4d0b-9fc0-52a5f7e0c8d4" => "component_variable_be5e78dc_ed57_4d0b_9fc0_52a5f7e0c8d4", "9dc78164-46af-4048-a2af-1fd90aa2acab" => "component_variable_9dc78164_46af_4048_a2af_1fd90aa2acab", "dabdbb24-5c73-4b93-af7a-8dd6b4702337" => "component_variable_dabdbb24_5c73_4b93_af7a_8dd6b4702337", "84004344-e839-477f-a840-387f41958606" => "component_variable_84004344_e839_477f_a840_387f41958606"], "fa23fcd2-386b-4ccd-8029-9f8f2437ce17", ""), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "990cf3c9-e52c-48fd-b22b-148c242ebe9e", "end"), "html", null, true);
    }

    public function block_block1833572258($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "de3e6752-f300-4b50-a751-11e073e7f5f3", "start"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:0afe34a6-58f6-4790-90bc-a40de84c6605]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 2, $this->source), false), "html", null, true);
        $context["component_variable_ba4b212e_191c_4df3_b712_25124d00e538"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b9198246_859e_4944_bc2f_b639b1cfa7c0"] = ('' === $tmp = "h3") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d17ab758_d5e4_45f3_b278_2da8182ef2ec"] = ('' === $tmp = "Events") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_95ac49b2_bc08_4865_a28a_35c7a8ebcb9e"] = ('' === $tmp = "A content type for creating events and a list view for browsing them.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9ddccdc5_4d42_4472_af2a_29144a0513ff"] = ('' === $tmp = "View example events") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e0d15462_9766_4214_953d_5ba57fe12247"] = ('' === $tmp = "view::events::page") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_731fe3d3_5a42_40d4_9530_b8b0c4ab8c39"] = ('' === $tmp = "left-align-image-above") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_66db3f85_2d91_4b1d_8de6_09c431b022f4"] = ('' === $tmp = "rgba(242, 242, 242, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_de982cc8_28c7_4d33_a15e_6f0bab378767"] = ('' === $tmp = "coh-style-card-text-light-background") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1008c963_dbbe_4adf_bbaa_435253b9c415"] = ('' === $tmp = "coh-style-padding-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_be5e78dc_ed57_4d0b_9fc0_52a5f7e0c8d4"] = 1;
        echo " ";
        $context["component_variable_9dc78164_46af_4048_a2af_1fd90aa2acab"] = ('' === $tmp = "coh-style-margin-bottom-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dabdbb24_5c73_4b93_af7a_8dd6b4702337"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_84004344_e839_477f_a840_387f41958606"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_linked_feature_card", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), ["ba4b212e-191c-4df3-b712-25124d00e538" => "component_variable_ba4b212e_191c_4df3_b712_25124d00e538", "b9198246-859e-4944-bc2f-b639b1cfa7c0" => "component_variable_b9198246_859e_4944_bc2f_b639b1cfa7c0", "d17ab758-d5e4-45f3-b278-2da8182ef2ec" => "component_variable_d17ab758_d5e4_45f3_b278_2da8182ef2ec", "95ac49b2-bc08-4865-a28a-35c7a8ebcb9e" => "component_variable_95ac49b2_bc08_4865_a28a_35c7a8ebcb9e", "9ddccdc5-4d42-4472-af2a-29144a0513ff" => "component_variable_9ddccdc5_4d42_4472_af2a_29144a0513ff", "e0d15462-9766-4214-953d-5ba57fe12247" => "component_variable_e0d15462_9766_4214_953d_5ba57fe12247", "731fe3d3-5a42-40d4-9530-b8b0c4ab8c39" => "component_variable_731fe3d3_5a42_40d4_9530_b8b0c4ab8c39", "66db3f85-2d91-4b1d-8de6-09c431b022f4" => "component_variable_66db3f85_2d91_4b1d_8de6_09c431b022f4", "de982cc8-28c7-4d33-a15e-6f0bab378767" => "component_variable_de982cc8_28c7_4d33_a15e_6f0bab378767", "1008c963-dbbe-4adf-bbaa-435253b9c415" => "component_variable_1008c963_dbbe_4adf_bbaa_435253b9c415", "be5e78dc-ed57-4d0b-9fc0-52a5f7e0c8d4" => "component_variable_be5e78dc_ed57_4d0b_9fc0_52a5f7e0c8d4", "9dc78164-46af-4048-a2af-1fd90aa2acab" => "component_variable_9dc78164_46af_4048_a2af_1fd90aa2acab", "dabdbb24-5c73-4b93-af7a-8dd6b4702337" => "component_variable_dabdbb24_5c73_4b93_af7a_8dd6b4702337", "84004344-e839-477f-a840-387f41958606" => "component_variable_84004344_e839_477f_a840_387f41958606"], "f6a55e04-4596-4724-902e-e1aa7a80fec5", ""), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "de3e6752-f300-4b50-a751-11e073e7f5f3", "end"), "html", null, true);
    }

    public function block_block1693841613($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "d6e597b1-b2ff-4f86-84ee-fb510c7c3b1c", "start"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:0afe34a6-58f6-4790-90bc-a40de84c6605]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 2, $this->source), false), "html", null, true);
        $context["component_variable_ba4b212e_191c_4df3_b712_25124d00e538"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b9198246_859e_4944_bc2f_b639b1cfa7c0"] = ('' === $tmp = "h3") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d17ab758_d5e4_45f3_b278_2da8182ef2ec"] = ('' === $tmp = "People") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_95ac49b2_bc08_4865_a28a_35c7a8ebcb9e"] = ('' === $tmp = "A content type for creating people profiles and a list view for browsing them.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9ddccdc5_4d42_4472_af2a_29144a0513ff"] = ('' === $tmp = "View example profiles") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e0d15462_9766_4214_953d_5ba57fe12247"] = ('' === $tmp = "view::people::page") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_731fe3d3_5a42_40d4_9530_b8b0c4ab8c39"] = ('' === $tmp = "left-align-image-above") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_66db3f85_2d91_4b1d_8de6_09c431b022f4"] = ('' === $tmp = "rgba(242, 242, 242, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_de982cc8_28c7_4d33_a15e_6f0bab378767"] = ('' === $tmp = "coh-style-card-text-light-background") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1008c963_dbbe_4adf_bbaa_435253b9c415"] = ('' === $tmp = "coh-style-padding-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_be5e78dc_ed57_4d0b_9fc0_52a5f7e0c8d4"] = 1;
        echo " ";
        $context["component_variable_9dc78164_46af_4048_a2af_1fd90aa2acab"] = ('' === $tmp = "coh-style-margin-bottom-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dabdbb24_5c73_4b93_af7a_8dd6b4702337"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_84004344_e839_477f_a840_387f41958606"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_linked_feature_card", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), ["ba4b212e-191c-4df3-b712-25124d00e538" => "component_variable_ba4b212e_191c_4df3_b712_25124d00e538", "b9198246-859e-4944-bc2f-b639b1cfa7c0" => "component_variable_b9198246_859e_4944_bc2f_b639b1cfa7c0", "d17ab758-d5e4-45f3-b278-2da8182ef2ec" => "component_variable_d17ab758_d5e4_45f3_b278_2da8182ef2ec", "95ac49b2-bc08-4865-a28a-35c7a8ebcb9e" => "component_variable_95ac49b2_bc08_4865_a28a_35c7a8ebcb9e", "9ddccdc5-4d42-4472-af2a-29144a0513ff" => "component_variable_9ddccdc5_4d42_4472_af2a_29144a0513ff", "e0d15462-9766-4214-953d-5ba57fe12247" => "component_variable_e0d15462_9766_4214_953d_5ba57fe12247", "731fe3d3-5a42-40d4-9530-b8b0c4ab8c39" => "component_variable_731fe3d3_5a42_40d4_9530_b8b0c4ab8c39", "66db3f85-2d91-4b1d-8de6-09c431b022f4" => "component_variable_66db3f85_2d91_4b1d_8de6_09c431b022f4", "de982cc8-28c7-4d33-a15e-6f0bab378767" => "component_variable_de982cc8_28c7_4d33_a15e_6f0bab378767", "1008c963-dbbe-4adf-bbaa-435253b9c415" => "component_variable_1008c963_dbbe_4adf_bbaa_435253b9c415", "be5e78dc-ed57-4d0b-9fc0-52a5f7e0c8d4" => "component_variable_be5e78dc_ed57_4d0b_9fc0_52a5f7e0c8d4", "9dc78164-46af-4048-a2af-1fd90aa2acab" => "component_variable_9dc78164_46af_4048_a2af_1fd90aa2acab", "dabdbb24-5c73-4b93-af7a-8dd6b4702337" => "component_variable_dabdbb24_5c73_4b93_af7a_8dd6b4702337", "84004344-e839-477f-a840-387f41958606" => "component_variable_84004344_e839_477f_a840_387f41958606"], "f93cb02a-89e2-4f40-9801-b7a2d38aae8d", ""), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "d6e597b1-b2ff-4f86-84ee-fb510c7c3b1c", "end"), "html", null, true);
    }

    public function block_block797572479($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "5b671e5d-fe9b-4834-903c-fb93c985010e", "start"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:0afe34a6-58f6-4790-90bc-a40de84c6605]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 2, $this->source), false), "html", null, true);
        $context["component_variable_ba4b212e_191c_4df3_b712_25124d00e538"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b9198246_859e_4944_bc2f_b639b1cfa7c0"] = ('' === $tmp = "h3") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d17ab758_d5e4_45f3_b278_2da8182ef2ec"] = ('' === $tmp = "Places") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_95ac49b2_bc08_4865_a28a_35c7a8ebcb9e"] = ('' === $tmp = "A content type for creating places and a list view for browsing them.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9ddccdc5_4d42_4472_af2a_29144a0513ff"] = ('' === $tmp = "View example places") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e0d15462_9766_4214_953d_5ba57fe12247"] = ('' === $tmp = "view::places::page") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_731fe3d3_5a42_40d4_9530_b8b0c4ab8c39"] = ('' === $tmp = "left-align-image-above") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_66db3f85_2d91_4b1d_8de6_09c431b022f4"] = ('' === $tmp = "rgba(242, 242, 242, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_de982cc8_28c7_4d33_a15e_6f0bab378767"] = ('' === $tmp = "coh-style-card-text-light-background") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1008c963_dbbe_4adf_bbaa_435253b9c415"] = ('' === $tmp = "coh-style-padding-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_be5e78dc_ed57_4d0b_9fc0_52a5f7e0c8d4"] = 1;
        echo " ";
        $context["component_variable_9dc78164_46af_4048_a2af_1fd90aa2acab"] = ('' === $tmp = "coh-style-margin-bottom-small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dabdbb24_5c73_4b93_af7a_8dd6b4702337"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_84004344_e839_477f_a840_387f41958606"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_linked_feature_card", false, $this->sandbox->ensureToStringAllowed($context, 2, $this->source), ["ba4b212e-191c-4df3-b712-25124d00e538" => "component_variable_ba4b212e_191c_4df3_b712_25124d00e538", "b9198246-859e-4944-bc2f-b639b1cfa7c0" => "component_variable_b9198246_859e_4944_bc2f_b639b1cfa7c0", "d17ab758-d5e4-45f3-b278-2da8182ef2ec" => "component_variable_d17ab758_d5e4_45f3_b278_2da8182ef2ec", "95ac49b2-bc08-4865-a28a-35c7a8ebcb9e" => "component_variable_95ac49b2_bc08_4865_a28a_35c7a8ebcb9e", "9ddccdc5-4d42-4472-af2a-29144a0513ff" => "component_variable_9ddccdc5_4d42_4472_af2a_29144a0513ff", "e0d15462-9766-4214-953d-5ba57fe12247" => "component_variable_e0d15462_9766_4214_953d_5ba57fe12247", "731fe3d3-5a42-40d4-9530-b8b0c4ab8c39" => "component_variable_731fe3d3_5a42_40d4_9530_b8b0c4ab8c39", "66db3f85-2d91-4b1d-8de6-09c431b022f4" => "component_variable_66db3f85_2d91_4b1d_8de6_09c431b022f4", "de982cc8-28c7-4d33-a15e-6f0bab378767" => "component_variable_de982cc8_28c7_4d33_a15e_6f0bab378767", "1008c963-dbbe-4adf-bbaa-435253b9c415" => "component_variable_1008c963_dbbe_4adf_bbaa_435253b9c415", "be5e78dc-ed57-4d0b-9fc0-52a5f7e0c8d4" => "component_variable_be5e78dc_ed57_4d0b_9fc0_52a5f7e0c8d4", "9dc78164-46af-4048-a2af-1fd90aa2acab" => "component_variable_9dc78164_46af_4048_a2af_1fd90aa2acab", "dabdbb24-5c73-4b93-af7a-8dd6b4702337" => "component_variable_dabdbb24_5c73_4b93_af7a_8dd6b4702337", "84004344-e839-477f-a840-387f41958606" => "component_variable_84004344_e839_477f_a840_387f41958606"], "a768c001-d5f9-4d19-8a12-e82499dd1fea", ""), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->frontendBuilderDropzone($context, "5b671e5d-fe9b-4834-903c-fb93c985010e", "end"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "__string_template__e991e7e2c592e9aee9c510af433c51d827c282a307bae8a36c8d83e2b9537f08";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  336 => 2,  330 => 3,  64 => 2,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__e991e7e2c592e9aee9c510af433c51d827c282a307bae8a36c8d83e2b9537f08", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "block" => 2, "if" => 2);
        static $filters = array("escape" => 1, "trim" => 2, "raw" => 2, "merge" => 2, "render" => 3);
        static $functions = array("attach_library" => 1, "processtoken" => 2, "renderInlineStyle" => 2, "renderComponent" => 2, "frontendBuilderDropzone" => 2);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'trim', 'raw', 'merge', 'render'],
                ['attach_library', 'processtoken', 'renderInlineStyle', 'renderComponent', 'frontendBuilderDropzone']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
