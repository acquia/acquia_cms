<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__7139173a525167c40888e5a59c73b0281916d5db0fb6175b1d9fd5992e6a07fe */
class __TwigTemplate_ea9f348d65cf2ee7a39ccbc5ca30f43456647d3e96cfed1caf0ffa82b3069d01 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if ((twig_get_attribute($this->env, $this->source, ($context["raw_arguments"] ?? null), "uid", [], "any", false, false, true, 1) == twig_get_attribute($this->env, $this->source, ($context["raw_arguments"] ?? null), "null", [], "any", false, false, true, 1))) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Your drafts"));
        } else {
            echo " ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("User's drafts"));
        }
    }

    public function getTemplateName()
    {
        return "__string_template__7139173a525167c40888e5a59c73b0281916d5db0fb6175b1d9fd5992e6a07fe";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__7139173a525167c40888e5a59c73b0281916d5db0fb6175b1d9fd5992e6a07fe", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 1);
        static $filters = array("t" => 1);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['t'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
