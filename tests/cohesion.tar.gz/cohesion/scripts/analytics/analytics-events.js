(function ($, Drupal) {
  "use strict";

  Drupal.behaviors.AnalyticsEvents = {
    attach: function (context, settings) {

      // Check to see if ga() function is available.
      if (typeof ga === typeof Function) {

        // GA is enabled, so carry on and create the events got all matching elements.
        $('[data-analytics]').once('coh-js-analytics-init').each(function () {

          // Save the element reference.
          var element = $(this);

          // Decode the analytics JSON from the data attribute.
          var events = JSON.parse($(this).attr('data-analytics'));

          // Loop through this attribute object, creating an event for each entry.
          events.forEach(function (event) {

            event.hitType = 'event';    // Populate the GA data object.
            element.bind(event.trigger, function (e, inView) {

              // inview trigger fired, but element left the viewport.
              if (e.type === 'inview' && !inView) {
                return;
              }

              // Fire the GA event according to: https://developers.google.com/analytics/devguides/collection/analyticsjs/sending-hits
              var trackerName

              try {
                var trackers = ga.getAll();
                var firstTracker = trackers[0];

                var activeKey
                if (typeof firstTracker.a !== 'undefined') {
                  activeKey = 'a';
                }
                if (typeof firstTracker.b !== 'undefined') {
                  activeKey = 'b';
                }

                trackerName = firstTracker[activeKey].data.values[":name"];

                if (typeof event.trigger !== 'undefined') {
                  delete event.trigger
                }
              }
              catch (e) {
                trackerName = ''
              }

              ga(trackerName + '.send', 'event', event);
            });

          });

        });
      }
      // GA not available, so warn.
      else {
        console.warn('Google Analytics is not available, but GA events have been defined.');
      }
    }
  };

})(jQuery, Drupal);
