<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__c5295e0c94d4146001fd321274e8473d7a0febe4386991ec2c8bbae088d4cc92 */
class __TwigTemplate_8db5dad07e5ab89c45c583d095048f4f9efc0cae310ebca750683d6cf9669800 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block2421638950' => [$this, 'block_block2421638950'],
            'block4048964352' => [$this, 'block_block4048964352'],
            'block2965507017' => [$this, 'block_block2965507017'],
            'block2308084950' => [$this, 'block_block2308084950'],
            'block3807083676' => [$this, 'block_block3807083676'],
            'block3887563767' => [$this, 'block_block3887563767'],
            'block4274138218' => [$this, 'block_block4274138218'],
            'block3607110820' => [$this, 'block_block3607110820'],
            'block1815636028' => [$this, 'block_block1815636028'],
            'block3483516315' => [$this, 'block_block3483516315'],
            'block2891967948' => [$this, 'block_block2891967948'],
            'block1762197233' => [$this, 'block_block1762197233'],
            'block2291274587' => [$this, 'block_block2291274587'],
            'block3778232373' => [$this, 'block_block3778232373'],
            'block4240590275' => [$this, 'block_block4240590275'],
            'block2954443451' => [$this, 'block_block2954443451'],
            'block2273383033' => [$this, 'block_block2273383033'],
            'block1024898573' => [$this, 'block_block1024898573'],
            'block3075420042' => [$this, 'block_block3075420042'],
            'block277381321' => [$this, 'block_block277381321'],
            'block3045188696' => [$this, 'block_block3045188696'],
            'block3541424218' => [$this, 'block_block3541424218'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:332e04ed-5f60-45d8-b689-7dfa82a5f143]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 3, $this->source), false), "html", null, true);
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "100vh") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2421638950', $context, $blocks);
        // line 8
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 8, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 8, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 8, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"]), "b7230544-6eaa-484a-aa08-399e34bea3e5", ""), "html", null, true);
        echo " ";
        $context["component_variable_dda5f83b_0f82_4fce_978f_b90ae5366f9f"] = ('' === $tmp = "coh-accordion-tabs-horizontal-left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_ab648f64_72cd_423f_88fc_ba538c9726d4"] = ('' === $tmp = "coh-style-dark-tab") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_96f8faac_b22e_4b5d_8a9f_71c3fd429862"] = ('' === $tmp = "coh-style-dark-tab-active") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block4048964352', $context, $blocks);
        // line 11
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["28366279-d56a-4b1d-b7ab-7d3d540f5dd7" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("80ee26fb", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["dda5f83b-0f82-4fce-978f-b90ae5366f9f" => "component_variable_dda5f83b_0f82_4fce_978f_b90ae5366f9f", "ab648f64-72cd-423f-88fc-ba538c9726d4" => "component_variable_ab648f64_72cd_423f_88fc_ba538c9726d4", "96f8faac-b22e-4b5d-8a9f-71c3fd429862" => "component_variable_96f8faac_b22e_4b5d_8a9f_71c3fd429862"]), "e3b579e5-44fb-4904-9667-e5ae08615b13", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h4 class=\"coh-style-pre-heading\">programs</h4>

<h2>Find ways to get involved in your community</h2>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.</p>

<p>If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages. It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 18
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "eb8d970a-6e0c-40cf-88ed-6650ea6707ba", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:69d62494-c672-48fa-be98-dbf65de5b93d]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 18, $this->source), false), "html", null, true);
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_8cd16587_61fa_47a7_a977_9a051af471c1"] = ('' === $tmp = "rgba(252, 247, 247, 0.751)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1815636028', $context, $blocks);
        // line 23
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 23, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 23, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 23, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "8cd16587-61fa-47a7-a977-9a051af471c1" => "component_variable_8cd16587_61fa_47a7_a977_9a051af471c1"]), "c9ead56d-364f-4d94-b301-3df88213bcf7", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h2>FAQs</h2>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 24
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 24, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "3d7eaef1-debd-4afc-985f-b5149d735597", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = ('' === $tmp = "20px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2891967948', $context, $blocks);
        // line 33
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 33, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 33, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 33, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"]), "6f8a101f-68af-445b-89b9-6e377166fd8a", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "None") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_8cd16587_61fa_47a7_a977_9a051af471c1"] = ('' === $tmp = "rgba(0, 104, 125, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3541424218', $context, $blocks);
        // line 36
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 36, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 36, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 36, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "8cd16587-61fa-47a7-a977-9a051af471c1" => "component_variable_8cd16587_61fa_47a7_a977_9a051af471c1"]), "3ee71cc4-40f0-4928-a7f8-9f4939c67446", ""), "html", null, true);
        echo " 
";
        // line 37
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 37, $this->source));
        }
    }

    // line 3
    public function block_block2421638950($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_text"] = ('' === $tmp = "<h4>PRE HEADING</h4>

<h1>Resources</h1>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 8
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a581345e_9290_4d1d_ac78_20b3ba547743"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_86d5677f_86b4_4f30_845a_25636792b9a3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741"] = ('' === $tmp = "coh-style-height--large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7"] = 3;
        echo " ";
        $context["component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f"] = 12;
        echo " ";
        $context["component_variable_9ee3460e_b550_45b2_842f_b7ee235048ab"] = 12;
        echo " ";
        $context["component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8"] = ('' === $tmp = "Left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd1d1cc_031f_438a_82fc_43edca962513"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b7b4763e_bcb8_48ae_b571_68830beeb52f"] = ('' === $tmp = "rgba(12, 8, 8, 0.711)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84"] = 1;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_90226570_4c01_4971_8985_6564b065a63d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dc3d74f2_e281_4c18_8689_1f266560111b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d"] = ('' === $tmp = "flex-start;") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fee69872_6425_4df2_a336_61768fe7c265"] = ('' === $tmp = "coh-style-link-button") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_hero", false, $this->sandbox->ensureToStringAllowed($context, 8, $this->source), ["ec518aee-3987-4edc-8630-c679120136af" => ["text" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_text", "textFormat" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"], "1ca08220-ccc9-4171-a2d3-993ea04fe1d0" => "component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0", "a581345e-9290-4d1d-ac78-20b3ba547743" => "component_variable_a581345e_9290_4d1d_ac78_20b3ba547743", "86d5677f-86b4-4f30-845a-25636792b9a3" => "component_variable_86d5677f_86b4_4f30_845a_25636792b9a3", "fe487eb0-8848-4d8d-9901-bb5cb64c4741" => "component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741", "5311228f-f968-4346-bbe1-747dfde7b1f7" => "component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7", "35d8f0ae-b2db-4f9d-941f-ce47958aae5f" => "component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f", "9ee3460e-b550-45b2-842f-b7ee235048ab" => "component_variable_9ee3460e_b550_45b2_842f_b7ee235048ab", "29ff2bde-d589-4eb3-a0a8-ddcc23fa5aa8" => "component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8", "f30e5ad5-c3c7-44a3-bf47-882cb74da487" => "component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487", "6bd1d1cc-031f-438a-82fc-43edca962513" => "component_variable_6bd1d1cc_031f_438a_82fc_43edca962513", "15bb3c39-f87e-4ace-a924-ae9ae1867c94" => "component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94", "b7b4763e-bcb8-48ae-b571-68830beeb52f" => "component_variable_b7b4763e_bcb8_48ae_b571_68830beeb52f", "5502b4d7-a6bd-467a-993d-625ef4002d84" => "component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84", "90226570-4c01-4971-8985-6564b065a63d" => "component_variable_90226570_4c01_4971_8985_6564b065a63d", "dc3d74f2-e281-4c18-8689-1f266560111b" => "component_variable_dc3d74f2_e281_4c18_8689_1f266560111b", "e330c7cb-1cb4-41a0-b3b0-ec95a9764b7d" => "component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d", "fee69872-6425-4df2-a336-61768fe7c265" => "component_variable_fee69872_6425_4df2_a336_61768fe7c265"], "d93b2870-7c2f-43ad-b4e3-660a328ba2d7", ""), "html", null, true);
        echo " ";
    }

    public function block_block4048964352($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_2d4ee479_1451_446b_a0e8_9577d45444dd"] = ('' === $tmp = "RESIDENTS") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b52ca9c8_0c9d_4683_9f9f_d12a1326621e"] = ('' === $tmp = "coh-style-padding-top---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e181d85c_6603_416f_89de_e5849b4f93c5"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2965507017', $context, $blocks);
        // line 9
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 9, $this->source), ["72d90d85-a475-45c9-ac59-d61edcd812e4" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("ae486950", false, $this->sandbox->ensureToStringAllowed($context, 9, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 9, $this->source), ["2d4ee479-1451-446b-a0e8-9577d45444dd" => "component_variable_2d4ee479_1451_446b_a0e8_9577d45444dd", "b52ca9c8-0c9d-4683-9f9f-d12a1326621e" => "component_variable_b52ca9c8_0c9d_4683_9f9f_d12a1326621e", "e181d85c-6603-416f-89de-e5849b4f93c5" => "component_variable_e181d85c_6603_416f_89de_e5849b4f93c5"]), "c2902ced-4c61-45b3-834d-dfab178e3dab", ""), "html", null, true);
        echo " ";
        $context["component_variable_2d4ee479_1451_446b_a0e8_9577d45444dd"] = ('' === $tmp = "BUSINESSES") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b52ca9c8_0c9d_4683_9f9f_d12a1326621e"] = ('' === $tmp = "coh-style-padding-top---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e181d85c_6603_416f_89de_e5849b4f93c5"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3807083676', $context, $blocks);
        // line 10
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 10, $this->source), ["72d90d85-a475-45c9-ac59-d61edcd812e4" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("ae486950", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 10, $this->source), ["2d4ee479-1451-446b-a0e8-9577d45444dd" => "component_variable_2d4ee479_1451_446b_a0e8_9577d45444dd", "b52ca9c8-0c9d-4683-9f9f-d12a1326621e" => "component_variable_b52ca9c8_0c9d_4683_9f9f_d12a1326621e", "e181d85c-6603-416f-89de-e5849b4f93c5" => "component_variable_e181d85c_6603_416f_89de_e5849b4f93c5"]), "0b7a26a3-f9ea-41e7-8561-831285295910", ""), "html", null, true);
        echo " ";
        $context["component_variable_2d4ee479_1451_446b_a0e8_9577d45444dd"] = ('' === $tmp = "VISITORS") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b52ca9c8_0c9d_4683_9f9f_d12a1326621e"] = ('' === $tmp = "coh-style-padding-top---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e181d85c_6603_416f_89de_e5849b4f93c5"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block4274138218', $context, $blocks);
        // line 11
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["72d90d85-a475-45c9-ac59-d61edcd812e4" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("ae486950", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["2d4ee479-1451-446b-a0e8-9577d45444dd" => "component_variable_2d4ee479_1451_446b_a0e8_9577d45444dd", "b52ca9c8-0c9d-4683-9f9f-d12a1326621e" => "component_variable_b52ca9c8_0c9d_4683_9f9f_d12a1326621e", "e181d85c-6603-416f-89de-e5849b4f93c5" => "component_variable_e181d85c_6603_416f_89de_e5849b4f93c5"]), "ef041993-a920-4c08-b488-7f1db592f062", ""), "html", null, true);
        echo " ";
    }

    // line 8
    public function block_block2965507017($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h2 class=\"text-align-center\"><span class=\"coh-color-white\">City Services</span></h2>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 9
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 9, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "86d6c84a-b472-4903-bd51-6709f4fb6832", ""), "html", null, true);
        echo " ";
        $context["component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d29242f9_57b0_4002_841d_505458c3b21d"] = ('' === $tmp = "coh-style-padding-bottom---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2308084950', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 9, $this->source), ["694ba725-ae4c-4711-a676-e6351ea4e2bc" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_container", false, $this->sandbox->ensureToStringAllowed($context, 9, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 9, $this->source), ["2b28beb7-e16d-4e4d-bfaf-dddb4224de35" => "component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35", "c81d21c0-2a3c-4caa-9d91-342a9c5a94da" => "component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da", "d29242f9-57b0-4002-841d-505458c3b21d" => "component_variable_d29242f9_57b0_4002_841d_505458c3b21d"]), "09608a5b-66ad-43ea-adb1-5acc3dd4e236", ""), "html", null, true);
        echo " ";
    }

    public function block_block2308084950($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:c83541e9-7305-471b-a72d-f678958bf9e7]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 9, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 9, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "3d5f328c-10ed-44ea-98ae-e42198537080", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:417bd16c-d9cf-4c80-8f50-00ff3e41ccdf]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 9, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 9, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "846f2af8-04a5-4120-b3d6-e93bdf8f37e9", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:f711d0e2-4b0f-4de1-9bc8-af8abcd8656e]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 9, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 9, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "ff4c8cb1-4139-4b8c-b544-79140c8ca3f8", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:9ff3913a-1fbc-42e0-8fc4-32dddd812032]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 9, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 9, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "e186019a-095f-498e-b23d-15e66af88a3b", ""), "html", null, true);
        echo " ";
    }

    public function block_block3807083676($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h2 class=\"text-align-center\"><span class=\"coh-color-white\">Business Services</span></h2>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 10
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "00bf3133-6fad-44c0-9614-dec6532cef45", ""), "html", null, true);
        echo " ";
        $context["component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d29242f9_57b0_4002_841d_505458c3b21d"] = ('' === $tmp = "coh-style-padding-bottom---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3887563767', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 10, $this->source), ["694ba725-ae4c-4711-a676-e6351ea4e2bc" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_container", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 10, $this->source), ["2b28beb7-e16d-4e4d-bfaf-dddb4224de35" => "component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35", "c81d21c0-2a3c-4caa-9d91-342a9c5a94da" => "component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da", "d29242f9-57b0-4002-841d-505458c3b21d" => "component_variable_d29242f9_57b0_4002_841d_505458c3b21d"]), "af50afbd-ff5d-4205-a312-e53794f802f4", ""), "html", null, true);
        echo " ";
    }

    public function block_block3887563767($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:88a2d0fd-2bc0-4e03-bf26-4c13b2748068]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 10, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "d3a155f2-a576-4f3e-83e6-be5febc0454d", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:5361e4a1-3fea-499d-9917-4086cfcd0ee8]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 10, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "20e04c74-6433-4e09-82ec-f949a83c680d", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:29077ed3-999e-4530-811c-dd7315d37038]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 10, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "f61c64e6-4ea5-4be9-88b8-0c2f0c5954c2", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:80e1c5e3-2397-4563-8159-3f8657c43341]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 10, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "18be83d1-302a-43f1-af19-d8d01f0c736f", ""), "html", null, true);
        echo " ";
    }

    public function block_block4274138218($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h2 class=\"text-align-center\"><span class=\"coh-color-white\">Visitor Services</span></h2>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 11
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "98523eb8-ed20-4bf4-adc6-4a727457b174", ""), "html", null, true);
        echo " ";
        $context["component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d29242f9_57b0_4002_841d_505458c3b21d"] = ('' === $tmp = "coh-style-padding-bottom---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3607110820', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["694ba725-ae4c-4711-a676-e6351ea4e2bc" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_container", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["2b28beb7-e16d-4e4d-bfaf-dddb4224de35" => "component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35", "c81d21c0-2a3c-4caa-9d91-342a9c5a94da" => "component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da", "d29242f9-57b0-4002-841d-505458c3b21d" => "component_variable_d29242f9_57b0_4002_841d_505458c3b21d"]), "9e5beb15-6313-4e64-85bb-fed03a4496cc", ""), "html", null, true);
        echo " ";
    }

    public function block_block3607110820($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:88a2d0fd-2bc0-4e03-bf26-4c13b2748068]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 11, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "a7d46d1c-7f0d-4bd9-9b6d-4bc7eb3346fb", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:5361e4a1-3fea-499d-9917-4086cfcd0ee8]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 11, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "35a361b4-e827-47b2-8d71-31b0dd0aa56b", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:29077ed3-999e-4530-811c-dd7315d37038]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 11, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "449419b2-cfc0-4e96-9c1b-bfad43f307d4", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:80e1c5e3-2397-4563-8159-3f8657c43341]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 11, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet…") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "eea91749-b1be-4a58-8ffa-295b972798ef", ""), "html", null, true);
        echo " ";
    }

    // line 18
    public function block_block1815636028($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h2 class=\"text-align-center\">Programs</h2>

<p>&nbsp;</p>

<h3 class=\"text-align-center\">Get to know your city better with our exciting ongoing programs.</h3>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 23
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 23, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "ef9817bf-5c10-4688-9ff8-d31068ed5a88", ""), "html", null, true);
        echo " ";
        $context["component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d29242f9_57b0_4002_841d_505458c3b21d"] = ('' === $tmp = "coh-style-padding-bottom---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3483516315', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 23, $this->source), ["694ba725-ae4c-4711-a676-e6351ea4e2bc" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_container", false, $this->sandbox->ensureToStringAllowed($context, 23, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 23, $this->source), ["2b28beb7-e16d-4e4d-bfaf-dddb4224de35" => "component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35", "c81d21c0-2a3c-4caa-9d91-342a9c5a94da" => "component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da", "d29242f9-57b0-4002-841d-505458c3b21d" => "component_variable_d29242f9_57b0_4002_841d_505458c3b21d"]), "f7955296-3821-4063-9366-35278290306f", ""), "html", null, true);
        echo " ";
    }

    public function block_block3483516315($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:e1613710-06ac-41c1-966e-59a8d1b3d387]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 23, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Register to Vote") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 3;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2"] = ('' === $tmp = "Register to Vote") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 23, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "e35ae154-1e7b-41cb-babb-9209c78c1ea2" => "component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "9aac0359-8377-46f6-8b7b-0e0e710cfea2", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:f0ab9b0b-e7f3-4a60-9e38-3c77ec308a1e]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 23, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Community Park Cleanup") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 3;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2"] = ('' === $tmp = "Community Park Cleanup") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 23, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "e35ae154-1e7b-41cb-babb-9209c78c1ea2" => "component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "544c6a0b-f946-4ab9-bf4a-1fbb846b367b", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:763155d0-455e-41a4-b0a9-7ec2b197e448]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 23, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Rent Freeze Program") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 3;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2"] = ('' === $tmp = "Rent Freeze Program") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 23, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "e35ae154-1e7b-41cb-babb-9209c78c1ea2" => "component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "b7f4e5a6-f69d-4815-853b-410859b08a85", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:dbb91051-bb85-4cdc-8eae-6c13ed107ca2]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 23, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "City Bike Shares") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 3;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2"] = ('' === $tmp = "City Bike Shares") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 23, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "e35ae154-1e7b-41cb-babb-9209c78c1ea2" => "component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "d9c447a1-b594-441a-9fed-7b98c10f758b", ""), "html", null, true);
        echo " ";
    }

    // line 24
    public function block_block2891967948($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_c026250d_0d07_4aa3_9352_9c0af14a1e62"] = ('' === $tmp = "coh-style-max-width-accordion---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a7017222_1d85_4f66_bc7b_85d305a9af74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_540282c7_4d62_4d55_9a22_59225d12cc19"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_7d0cc777_5bb2_406b_b98f_2754f6266fe8"] = false;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1762197233', $context, $blocks);
        // line 33
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 33, $this->source), ["0cb86f6b-4b0f-4ea6-ab5d-50e01560afac" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_container", false, $this->sandbox->ensureToStringAllowed($context, 33, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 33, $this->source), ["c026250d-0d07-4aa3-9352-9c0af14a1e62" => "component_variable_c026250d_0d07_4aa3_9352_9c0af14a1e62", "a7017222-1d85-4f66-bc7b-85d305a9af74" => "component_variable_a7017222_1d85_4f66_bc7b_85d305a9af74", "540282c7-4d62-4d55-9a22-59225d12cc19" => "component_variable_540282c7_4d62_4d55_9a22_59225d12cc19", "7d0cc777-5bb2-406b-b98f-2754f6266fe8" => "component_variable_7d0cc777_5bb2_406b_b98f_2754f6266fe8"]), "2117cd07-35c0-4893-b408-c98578214465", ""), "html", null, true);
        echo " ";
    }

    // line 24
    public function block_block1762197233($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2291274587', $context, $blocks);
        // line 25
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 25, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 25, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 25, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "477245b3-a4b2-44c3-8b13-c235f0c1ff9b", ""), "html", null, true);
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3778232373', $context, $blocks);
        // line 26
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 26, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 26, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 26, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "ce4239f5-bfb6-4b9a-9aa2-a4ee5076f079", ""), "html", null, true);
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block4240590275', $context, $blocks);
        // line 27
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 27, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 27, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 27, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "172a26c7-dbb2-4425-9a37-4cafe04ea9cd", ""), "html", null, true);
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2954443451', $context, $blocks);
        // line 28
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 28, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 28, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 28, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "4cf61c39-d33e-4f59-9ef7-86a3210fdfa7", ""), "html", null, true);
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2273383033', $context, $blocks);
        // line 29
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 29, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 29, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 29, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "e0eed668-f1df-4061-8bf8-4a0bb0f2caea", ""), "html", null, true);
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1024898573', $context, $blocks);
        // line 30
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 30, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "5c1cba2f-bbb2-4ddb-9a4c-db6b58654a38", ""), "html", null, true);
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3075420042', $context, $blocks);
        // line 31
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 31, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 31, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 31, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "3376b43d-e791-4a4e-91d6-f0e870c3ed62", ""), "html", null, true);
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block277381321', $context, $blocks);
        // line 32
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 32, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 32, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 32, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "0da4875e-72ab-4e62-a7f6-06d39f1c7826", ""), "html", null, true);
        echo " ";
        $context["component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda"] = ('' === $tmp = "Accordion heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"] = ('' === $tmp = "coh-style-container-theme---white") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3045188696', $context, $blocks);
        // line 33
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 33, $this->source), ["43708807-7e99-4ed9-ae0f-d4808449e365" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_accordion_item", false, $this->sandbox->ensureToStringAllowed($context, 33, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 33, $this->source), ["7135fdbd-ddf7-40bc-81f2-04d9984d8eda" => "component_variable_7135fdbd_ddf7_40bc_81f2_04d9984d8eda", "1cca6bfd-26c3-4e9e-9dbd-7941e52d5bce" => "component_variable_1cca6bfd_26c3_4e9e_9dbd_7941e52d5bce", "93d28e49-b532-4fd5-adcf-a5ea1811b906" => "component_variable_93d28e49_b532_4fd5_adcf_a5ea1811b906", "5203627d-ff55-4964-9f9b-43a5daf23d06" => "component_variable_5203627d_ff55_4964_9f9b_43a5daf23d06"]), "de1c20bb-3780-4170-a796-cdf0161587ef", ""), "html", null, true);
        echo " ";
    }

    // line 24
    public function block_block2291274587($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 25
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 25, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "08522df5-86f8-4117-a3f7-fb50f0458b49", ""), "html", null, true);
        echo " ";
    }

    public function block_block3778232373($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 26
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 26, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "38d91eb8-6477-4fad-b622-2a62a0a526b6", ""), "html", null, true);
        echo " ";
    }

    public function block_block4240590275($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 27
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 27, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "2dcaacef-444e-43b5-a48c-684c71f01509", ""), "html", null, true);
        echo " ";
    }

    public function block_block2954443451($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 28
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 28, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "885a87aa-2230-4fc5-909c-daae367ff209", ""), "html", null, true);
        echo " ";
    }

    public function block_block2273383033($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 29
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 29, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "2353d3ef-f0cf-4bf0-b0d3-0d4c31a1d917", ""), "html", null, true);
        echo " ";
    }

    public function block_block1024898573($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 30
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 30, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "8eea387d-7341-46b1-936b-7f44e7af572d", ""), "html", null, true);
        echo " ";
    }

    public function block_block3075420042($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 31
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 31, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "1bdbf892-3f2f-4114-a4af-53269253ae17", ""), "html", null, true);
        echo " ";
    }

    public function block_block277381321($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 32
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 32, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "63f78803-feaa-422e-8a6d-2a40a3143da3", ""), "html", null, true);
        echo " ";
    }

    public function block_block3045188696($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p>We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 33
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 33, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "6d22933d-6076-4c19-bdb4-a00428ff2a19", ""), "html", null, true);
        echo " ";
    }

    public function block_block3541424218($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<div class=\"coh-style-contact-info-block\">
<p><span class=\"coh-color-white\">Can’t find what you’re looking for?&nbsp;<a href=\"/contact-us\">Contact Us</a>&nbsp;for more information!</span></p>
</div>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 36
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 36, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "1dd6b02d-7365-408b-a407-e855be1fda8c", ""), "html", null, true);
        echo " ";
    }

    public function getTemplateName()
    {
        return "__string_template__c5295e0c94d4146001fd321274e8473d7a0febe4386991ec2c8bbae088d4cc92";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1806 => 36,  1776 => 33,  1748 => 32,  1720 => 31,  1692 => 30,  1664 => 29,  1636 => 28,  1608 => 27,  1580 => 26,  1552 => 25,  1545 => 24,  1531 => 33,  1507 => 32,  1483 => 31,  1459 => 30,  1435 => 29,  1411 => 28,  1387 => 27,  1363 => 26,  1339 => 25,  1322 => 24,  1308 => 33,  1290 => 24,  1109 => 23,  1098 => 18,  893 => 11,  682 => 10,  471 => 9,  464 => 8,  450 => 11,  429 => 10,  408 => 9,  348 => 8,  337 => 3,  331 => 37,  318 => 36,  272 => 33,  219 => 24,  205 => 23,  151 => 18,  131 => 11,  110 => 8,  64 => 3,  61 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__c5295e0c94d4146001fd321274e8473d7a0febe4386991ec2c8bbae088d4cc92", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 3, "if" => 8);
        static $filters = array("escape" => 3, "merge" => 8, "render" => 37);
        static $functions = array("attach_library" => 3, "processtoken" => 3, "renderComponent" => 8);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'merge', 'render'],
                ['attach_library', 'processtoken', 'renderComponent']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
