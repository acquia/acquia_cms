<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__615d257a35c961aadea1ee06fb2282c5cdd01196e5d912993f1b3e6c2010d31e */
class __TwigTemplate_5f59c4768891e13eaa9a368cc7f8f305cb29e1cd5c0fb7b20f52dccde1b5157d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block2719738714' => [$this, 'block_block2719738714'],
            'block3327266483' => [$this, 'block_block3327266483'],
            'block4223341371' => [$this, 'block_block4223341371'],
            'block1540341420' => [$this, 'block_block1540341420'],
            'block1722412918' => [$this, 'block_block1722412918'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:99e8aa1f-add0-4629-862e-cb7b235bcc99]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 3, $this->source), false), "html", null, true);
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = ('' === $tmp = "20px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = false;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_028cf87b_ada9_4c88_880d_7dd19de841bd"] = 0;
        echo " ";
        $context["component_variable_301ad76b_785d_4615_af93_ce27b0968b26"] = 1;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2719738714', $context, $blocks);
        // line 8
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 8, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 8, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 8, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44", "028cf87b-ada9-4c88-880d-7dd19de841bd" => "component_variable_028cf87b_ada9_4c88_880d_7dd19de841bd", "301ad76b-785d-4615-af93-ce27b0968b26" => "component_variable_301ad76b_785d_4615_af93_ce27b0968b26"]), "afe352bc-03cf-45d3-8561-e73f5cb32740", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p class=\"coh-style-pre-heading\">resources</p>

<h2>City Services</h2>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 11
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "984ac60b-6fe3-4621-9e7b-1b9bdd5f47ce", ""), "html", null, true);
        echo " ";
        $context["component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_d29242f9_57b0_4002_841d_505458c3b21d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3327266483', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["694ba725-ae4c-4711-a676-e6351ea4e2bc" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_container", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["2b28beb7-e16d-4e4d-bfaf-dddb4224de35" => "component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35", "c81d21c0-2a3c-4caa-9d91-342a9c5a94da" => "component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da", "d29242f9-57b0-4002-841d-505458c3b21d" => "component_variable_d29242f9_57b0_4002_841d_505458c3b21d"]), "3a69f3ab-513d-4f85-9ad8-20a93c6efc43", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p class=\"coh-style-paragraph-large text-align-center\"><strong><a href=\"/resources\">See all services on our Resources page</a></strong></p>

<p class=\"text-align-center\">&nbsp;</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 14
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 14, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "0e6736b7-ca30-41f6-beb6-b2255386de27", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:31c38358-0d0f-4285-817c-5e3d945b3b7d]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 14, $this->source), false), "html", null, true);
        $context["component_variable_fc654977_5646_45bd_a79c_073557e0c635"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e5440168_e710_4c61_a372_9486271539eb"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201"] = ('' === $tmp = "Covid - Mask, Distancing, Sanitizing and more...") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4"] = ('' === $tmp = "Read about how you can keep yourself safe during these tough times.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4"] = ('' === $tmp = "Read more!") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_004d1470_56bb_4840_8887_b5aa0b776a8a"] = 8;
        echo " ";
        $context["component_variable_c9379808_05b5_40eb_9669_186474d82483"] =  -2;
        echo " ";
        $context["component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db"] =  -2;
        echo " ";
        $context["component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20"] =  -2;
        echo " ";
        $context["component_variable_4b467c3b_b26d_49c6_9116_311a669a049c"] = true;
        echo " ";
        $context["component_variable_558e8243_29d2_4a3d_8d5c_509101e76414"] = true;
        echo " ";
        $context["component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1"] = false;
        echo " ";
        $context["component_variable_a968d804_8518_4fb9_969e_06a5504d3284"] = true;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7f725cba_761f_49ee_88b0_34bcae901ef4"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0708696f_52ca_4e8c_bbac_b6c2ab5603d4"] = ('' === $tmp = "rgba(240, 240, 240, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9711edf2_044b_4042_9bb6_ed3b94e8b791"] = 6;
        echo " ";
        $context["component_variable_8e3d1096_ee5d_4ff3_8d31_2f17de4b43d3"] = 12;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_horizontal_16_9", false, $this->sandbox->ensureToStringAllowed($context, 14, $this->source), ["fc654977-5646-45bd-a79c-073557e0c635" => "component_variable_fc654977_5646_45bd_a79c_073557e0c635", "e5440168-e710-4c61-a372-9486271539eb" => "component_variable_e5440168_e710_4c61_a372_9486271539eb", "0150e186-1886-491c-8eeb-3eff0d1ea201" => "component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201", "c25990a1-9edb-47ed-ae4d-673395f9457b" => "component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b", "5d1fad68-87b6-4a97-995f-a2b99334c0d4" => "component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4", "39207af3-9cab-4489-ac19-4ea160ab81b4" => "component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4", "004d1470-56bb-4840-8887-b5aa0b776a8a" => "component_variable_004d1470_56bb_4840_8887_b5aa0b776a8a", "c9379808-05b5-40eb-9669-186474d82483" => "component_variable_c9379808_05b5_40eb_9669_186474d82483", "e620b539-d2f4-4cad-b11e-ed1aceb063db" => "component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db", "46a89c29-8d1c-431c-b508-6716f7e3ab20" => "component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20", "4b467c3b-b26d-49c6-9116-311a669a049c" => "component_variable_4b467c3b_b26d_49c6_9116_311a669a049c", "558e8243-29d2-4a3d-8d5c-509101e76414" => "component_variable_558e8243_29d2_4a3d_8d5c_509101e76414", "a384f576-0ed0-427c-b9b5-3a4df20fbff1" => "component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1", "a968d804-8518-4fb9-969e-06a5504d3284" => "component_variable_a968d804_8518_4fb9_969e_06a5504d3284", "7f725cba-761f-49ee-88b0-34bcae901ef4" => "component_variable_7f725cba_761f_49ee_88b0_34bcae901ef4", "0708696f-52ca-4e8c-bbac-b6c2ab5603d4" => "component_variable_0708696f_52ca_4e8c_bbac_b6c2ab5603d4", "9711edf2-044b-4042-9bb6-ed3b94e8b791" => "component_variable_9711edf2_044b_4042_9bb6_ed3b94e8b791", "8e3d1096-ee5d-4ff3-8d31-2f17de4b43d3" => "component_variable_8e3d1096_ee5d_4ff3_8d31_2f17de4b43d3"], "9efa93bf-90a1-418d-b8ec-56b7f3cf3338", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "None") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_8cd16587_61fa_47a7_a977_9a051af471c1"] = ('' === $tmp = "rgba(0, 104, 125, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = true;
        echo " ";
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block4223341371', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 14, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 14, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 14, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "8cd16587-61fa-47a7-a977-9a051af471c1" => "component_variable_8cd16587_61fa_47a7_a977_9a051af471c1", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"]), "bb8ae23a-3752-4ec0-ab51-24823a31bbeb", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "None") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = true;
        echo " ";
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1540341420', $context, $blocks);
        // line 15
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 15, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 15, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"]), "9235d6b1-4233-490f-af50-6086ae1f1eb3", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "None") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_8cd16587_61fa_47a7_a977_9a051af471c1"] = ('' === $tmp = "rgba(0, 104, 125, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = true;
        echo " ";
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1722412918', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 15, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 15, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "8cd16587-61fa-47a7-a977-9a051af471c1" => "component_variable_8cd16587_61fa_47a7_a977_9a051af471c1", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"]), "a67485cf-14ae-4d4d-bee4-9ae7e42efe49", ""), "html", null, true);
        echo " 
";
        // line 16
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 16, $this->source));
        }
    }

    // line 3
    public function block_block2719738714($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_text"] = ('' === $tmp = "<p><span class=\"coh-style-heading-4-size\">The Acquia CMS city</span></p>

<h1><span class=\"coh-style-heading-1-size\">Welcome to Acquiaville</span></h1>

<p><span style=\"font-size:11pt; font-variant:normal; white-space:pre-wrap\"><span style=\"font-family:Arial\"><span style=\"font-weight:400\"><span style=\"font-style:normal\"><span style=\"text-decoration:none\">This is a demo site shipped with ACMS. You can browse through various pages and content to see how things are built using ACMS without writing much code (other than your CSS part). This will allow you to explore the capabilities for ACMS as an opinionated CMS.</span></span></span></span></span></p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 8
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a581345e_9290_4d1d_ac78_20b3ba547743"] = ('' === $tmp = "Site Studio Components") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741"] = ('' === $tmp = "coh-style-height--large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7"] = 5;
        echo " ";
        $context["component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f"] = 10;
        echo " ";
        $context["component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8"] = ('' === $tmp = "Left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd1d1cc_031f_438a_82fc_43edca962513"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84"] = 1;
        echo " ";
        $context["component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d"] = ('' === $tmp = "flex-start;") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fee69872_6425_4df2_a336_61768fe7c265"] = ('' === $tmp = "coh-style-link-button") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_86d5677f_86b4_4f30_845a_25636792b9a3"] = ('' === $tmp = "/site-studio-components") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_90226570_4c01_4971_8985_6564b065a63d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dc3d74f2_e281_4c18_8689_1f266560111b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_hero", false, $this->sandbox->ensureToStringAllowed($context, 8, $this->source), ["ec518aee-3987-4edc-8630-c679120136af" => ["text" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_text", "textFormat" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"], "1ca08220-ccc9-4171-a2d3-993ea04fe1d0" => "component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0", "a581345e-9290-4d1d-ac78-20b3ba547743" => "component_variable_a581345e_9290_4d1d_ac78_20b3ba547743", "fe487eb0-8848-4d8d-9901-bb5cb64c4741" => "component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741", "5311228f-f968-4346-bbe1-747dfde7b1f7" => "component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7", "35d8f0ae-b2db-4f9d-941f-ce47958aae5f" => "component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f", "29ff2bde-d589-4eb3-a0a8-ddcc23fa5aa8" => "component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8", "6bd1d1cc-031f-438a-82fc-43edca962513" => "component_variable_6bd1d1cc_031f_438a_82fc_43edca962513", "15bb3c39-f87e-4ace-a924-ae9ae1867c94" => "component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94", "5502b4d7-a6bd-467a-993d-625ef4002d84" => "component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84", "e330c7cb-1cb4-41a0-b3b0-ec95a9764b7d" => "component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d", "fee69872-6425-4df2-a336-61768fe7c265" => "component_variable_fee69872_6425_4df2_a336_61768fe7c265", "86d5677f-86b4-4f30-845a-25636792b9a3" => "component_variable_86d5677f_86b4_4f30_845a_25636792b9a3", "90226570-4c01-4971-8985-6564b065a63d" => "component_variable_90226570_4c01_4971_8985_6564b065a63d", "dc3d74f2-e281-4c18-8689-1f266560111b" => "component_variable_dc3d74f2_e281_4c18_8689_1f266560111b", "f30e5ad5-c3c7-44a3-bf47-882cb74da487" => "component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487"], "21aad4eb-83e1-45bf-a642-b1e171f3b425", ""), "html", null, true);
        echo " ";
    }

    // line 11
    public function block_block3327266483($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:c83541e9-7305-471b-a72d-f678958bf9e7]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 11, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "Utilities") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "Read information of various utility services like Water, Electricity, Garbage and other utlities.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "4433b211-e8ab-4fe4-8cd4-840efb49ad2c", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:5361e4a1-3fea-499d-9917-4086cfcd0ee8]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 11, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "Emergency services") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "Read more about emergency services") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "16d9b6c8-2545-4545-bd8f-e34ffb9f9e5a", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:29077ed3-999e-4530-811c-dd7315d37038]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 11, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "Public Library") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "Public library services are open 24/7 at Acquiaville. Click to read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "41e81b70-3971-4a16-9494-0d22dd0b2fd7", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:9ff3913a-1fbc-42e0-8fc4-32dddd812032]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 11, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "CITY Service Title PLaceholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "Tourism") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = "Read more about tourism@Acquiaville.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Read more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 3;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 6;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = "coh-style-rounded-card-image-wrapper") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"], "fde541f3-a858-41b0-ab1e-e2b75c6876ad", ""), "html", null, true);
        echo " ";
    }

    // line 14
    public function block_block4223341371($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_64db82f2_0a75_4f39_a71b_6ff274ec626b"] = ('' === $tmp = "views_block__article_cards_recent_articles_block") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e6ad0eef_62ad_44b4_8297_14da699375d7"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_drupal_blocks", false, $this->sandbox->ensureToStringAllowed($context, 14, $this->source), ["64db82f2-0a75-4f39-a71b-6ff274ec626b" => "component_variable_64db82f2_0a75_4f39_a71b_6ff274ec626b", "e6ad0eef-62ad-44b4-8297-14da699375d7" => "component_variable_e6ad0eef_62ad_44b4_8297_14da699375d7"], "588afa74-2bd9-47bb-b5c1-2e6c54cdccbe", ""), "html", null, true);
        echo " ";
        $context["component_variable_a37283c7_c5cc_454e_bb28_72bf2bf6d0f1"] = ('' === $tmp = "SEE ALL") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d8dadd76_62bf_4889_a8b7_77fe00ce5e63"] = ('' === $tmp = "/articles/type/news") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_64b274ab_cfe6_43ac_91ef_ec40b3adbef0"] = ('' === $tmp = "coh-style-button-cta") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_button", false, $this->sandbox->ensureToStringAllowed($context, 14, $this->source), ["a37283c7-c5cc-454e-bb28-72bf2bf6d0f1" => "component_variable_a37283c7_c5cc_454e_bb28_72bf2bf6d0f1", "d8dadd76-62bf-4889-a8b7-77fe00ce5e63" => "component_variable_d8dadd76_62bf_4889_a8b7_77fe00ce5e63", "64b274ab-cfe6-43ac-91ef-ec40b3adbef0" => "component_variable_64b274ab_cfe6_43ac_91ef_ec40b3adbef0"], "c635d6dd-2d5e-4e67-bfb4-05cc330d324f", ""), "html", null, true);
        echo " ";
    }

    public function block_block1540341420($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h4 class=\"coh-style-heading-2-size\">Common Resources</h4>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 15
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "e72888e9-8a47-41d3-91d5-6f8bb88adf37", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:8ee00874-f85d-4adb-9a13-fc390ed534df]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 15, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Rent Freeze Program") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "City Bike Shares") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 3;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2"] = ('' === $tmp = "City Bike Shares") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "e35ae154-1e7b-41cb-babb-9209c78c1ea2" => "component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "3dc716b0-b4a2-48ba-ab70-4a8f38279e2f", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:41b1363a-3eb4-4071-aac1-fe78e8062768]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 15, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Register to Vote") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 3;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "e35ae154-1e7b-41cb-babb-9209c78c1ea2" => "component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "2cb01b58-014e-47a1-9357-cf73e76053a4", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:09d80f32-bc8d-4d2f-bcfb-034ce39f62f9]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 15, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Rent Freeze Program") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 3;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2"] = ('' === $tmp = "Rent Freeze Program") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "e35ae154-1e7b-41cb-babb-9209c78c1ea2" => "component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "a974b9ff-681b-4a32-a7e1-1f63e62f7f48", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:9852fc2d-4ec5-4b0a-bebf-d5c05fdc419b]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 15, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Community Park Cleanup") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 3;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 6;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2"] = ('' === $tmp = "Community Park Cleanup") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "e35ae154-1e7b-41cb-babb-9209c78c1ea2" => "component_variable_e35ae154_1e7b_41cb_babb_9209c78c1ea2", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "569f8d7f-6496-4aa2-bf75-da7c37a8b9e3", ""), "html", null, true);
        echo " ";
        $context["component_variable_a37283c7_c5cc_454e_bb28_72bf2bf6d0f1"] = ('' === $tmp = "SEE ALL RESOURCES") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d8dadd76_62bf_4889_a8b7_77fe00ce5e63"] = ('' === $tmp = "#") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_64b274ab_cfe6_43ac_91ef_ec40b3adbef0"] = ('' === $tmp = "coh-style-button-cta") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_6f644ee8_b188_4a56_9865_3b27343d05a2"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_af15dd04_5110_41be_bb30_db5692994d83"] = ('' === $tmp = "rgba(13, 126, 162, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d642af16_30f3_4949_8595_5fd5c06a64c6"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_button", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["a37283c7-c5cc-454e-bb28-72bf2bf6d0f1" => "component_variable_a37283c7_c5cc_454e_bb28_72bf2bf6d0f1", "d8dadd76-62bf-4889-a8b7-77fe00ce5e63" => "component_variable_d8dadd76_62bf_4889_a8b7_77fe00ce5e63", "64b274ab-cfe6-43ac-91ef-ec40b3adbef0" => "component_variable_64b274ab_cfe6_43ac_91ef_ec40b3adbef0", "6f644ee8-b188-4a56-9865-3b27343d05a2" => "component_variable_6f644ee8_b188_4a56_9865_3b27343d05a2", "af15dd04-5110-41be-bb30-db5692994d83" => "component_variable_af15dd04_5110_41be_bb30_db5692994d83", "d642af16-30f3-4949-8595-5fd5c06a64c6" => "component_variable_d642af16_30f3_4949_8595_5fd5c06a64c6"], "639bdfc8-ddcd-475e-8d0b-b8aa74050734", ""), "html", null, true);
        echo " ";
    }

    public function block_block1722412918($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_64db82f2_0a75_4f39_a71b_6ff274ec626b"] = ('' === $tmp = "views_block__event_cards_upcoming_events_block") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e6ad0eef_62ad_44b4_8297_14da699375d7"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_drupal_blocks", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["64db82f2-0a75-4f39-a71b-6ff274ec626b" => "component_variable_64db82f2_0a75_4f39_a71b_6ff274ec626b", "e6ad0eef-62ad-44b4-8297-14da699375d7" => "component_variable_e6ad0eef_62ad_44b4_8297_14da699375d7"], "fcb2380d-cf51-410b-afd7-a5e36f5a7bfe", ""), "html", null, true);
        echo " ";
        $context["component_variable_a37283c7_c5cc_454e_bb28_72bf2bf6d0f1"] = ('' === $tmp = "SEE MORE EVENTS") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d8dadd76_62bf_4889_a8b7_77fe00ce5e63"] = ('' === $tmp = "/events") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_64b274ab_cfe6_43ac_91ef_ec40b3adbef0"] = ('' === $tmp = "coh-style-button-cta") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_button", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["a37283c7-c5cc-454e-bb28-72bf2bf6d0f1" => "component_variable_a37283c7_c5cc_454e_bb28_72bf2bf6d0f1", "d8dadd76-62bf-4889-a8b7-77fe00ce5e63" => "component_variable_d8dadd76_62bf_4889_a8b7_77fe00ce5e63", "64b274ab-cfe6-43ac-91ef-ec40b3adbef0" => "component_variable_64b274ab_cfe6_43ac_91ef_ec40b3adbef0"], "24712682-1406-49e1-b209-0b923907ea70", ""), "html", null, true);
        echo " ";
    }

    public function getTemplateName()
    {
        return "__string_template__615d257a35c961aadea1ee06fb2282c5cdd01196e5d912993f1b3e6c2010d31e";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  619 => 15,  592 => 14,  433 => 11,  392 => 8,  381 => 3,  375 => 16,  313 => 15,  164 => 14,  118 => 11,  102 => 8,  47 => 3,  44 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__615d257a35c961aadea1ee06fb2282c5cdd01196e5d912993f1b3e6c2010d31e", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 3, "if" => 8);
        static $filters = array("escape" => 3, "merge" => 8, "render" => 16);
        static $functions = array("attach_library" => 3, "processtoken" => 3, "renderComponent" => 8);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'merge', 'render'],
                ['attach_library', 'processtoken', 'renderComponent']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
