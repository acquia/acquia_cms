<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__ab797f8182bbd29390bda23db981225a7406762ffa665b281cdf0635912579f4 */
class __TwigTemplate_64ff0c4409ad6d3a4e9aea471ec0ddc979bad1c21a78f862ef6a775b81466c2e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block1908827058' => [$this, 'block_block1908827058'],
            'block3901577689' => [$this, 'block_block3901577689'],
            'block2112490912' => [$this, 'block_block2112490912'],
            'block1901649179' => [$this, 'block_block1901649179'],
            'block2220068317' => [$this, 'block_block2220068317'],
            'block3368480114' => [$this, 'block_block3368480114'],
            'block309827762' => [$this, 'block_block309827762'],
            'block2773094859' => [$this, 'block_block2773094859'],
            'block3146409927' => [$this, 'block_block3146409927'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:c142c54d-e8d8-4ea9-b2ec-39223ba00393]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 3, $this->source), false), "html", null, true);
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "80vh") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = false;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1908827058', $context, $blocks);
        // line 8
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 8, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 8, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 8, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"]), "8c6b452f-ba30-4d8e-92f6-af8990239c3a", ""), "html", null, true);
        echo " ";
        $context["component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d29242f9_57b0_4002_841d_505458c3b21d"] = ('' === $tmp = "coh-style-padding-top---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3901577689', $context, $blocks);
        // line 10
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 10, $this->source), ["694ba725-ae4c-4711-a676-e6351ea4e2bc" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_container", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 10, $this->source), ["2b28beb7-e16d-4e4d-bfaf-dddb4224de35" => "component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35", "c81d21c0-2a3c-4caa-9d91-342a9c5a94da" => "component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da", "d29242f9-57b0-4002-841d-505458c3b21d" => "component_variable_d29242f9_57b0_4002_841d_505458c3b21d"]), "bfe8eb09-3164-4890-a549-6811a9ae3f45", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = false;
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "None") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8cd16587_61fa_47a7_a977_9a051af471c1"] = ('' === $tmp = "rgba(0, 104, 125, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2112490912', $context, $blocks);
        // line 12
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 12, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 12, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 12, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44", "8cd16587-61fa-47a7-a977-9a051af471c1" => "component_variable_8cd16587_61fa_47a7_a977_9a051af471c1"]), "82968181-adc0-4378-8ebd-8e45a54cea2b", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h2 class=\"coh-style-heading-1-size-medium text-align-center\">Agencies &amp; Departments</h2>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 13
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "e2009044-16d3-40ef-8f93-176d81d06af8", ""), "html", null, true);
        echo " ";
        $context["component_variable_effdbd65_c5f8_4040_bda9_83449e60856b"] = 3;
        echo " ";
        $context["component_variable_f5d96f8a_8fa1_4019_ad89_2138b5ec4ffc"] = 2;
        echo " ";
        $context["component_variable_ac8248d6_90fa_4542_800c_b50f6c2a3e56"] = 1;
        echo " ";
        $context["component_variable_7ca2cfb9_d739_4e64_83ce_fb086b3a4c07"] = ('' === $tmp = "bleed") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_2673b9ac_b236_468c_8aff_64d9be9e9d97"] = ('' === $tmp = "move-pagination-up") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_92c7c135_813f_4b56_a2c0_3c388f206da5"] = ('' === $tmp = "coh-style-padding-top-bottom---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5fec5f46_bbac_4089_aac1_fd0b2a0738d0"] = ('' === $tmp = "coh-style-padding-left-right---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2220068317', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["342bec96-01e9-43e0-b28b-4cfd21ea3ead" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_container", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["effdbd65-c5f8-4040-bda9-83449e60856b" => "component_variable_effdbd65_c5f8_4040_bda9_83449e60856b", "f5d96f8a-8fa1-4019-ad89-2138b5ec4ffc" => "component_variable_f5d96f8a_8fa1_4019_ad89_2138b5ec4ffc", "ac8248d6-90fa-4542-800c-b50f6c2a3e56" => "component_variable_ac8248d6_90fa_4542_800c_b50f6c2a3e56", "7ca2cfb9-d739-4e64-83ce-fb086b3a4c07" => "component_variable_7ca2cfb9_d739_4e64_83ce_fb086b3a4c07", "2673b9ac-b236-468c-8aff-64d9be9e9d97" => "component_variable_2673b9ac_b236_468c_8aff_64d9be9e9d97", "92c7c135-813f-4b56-a2c0-3c388f206da5" => "component_variable_92c7c135_813f_4b56_a2c0_3c388f206da5", "5fec5f46-bbac-4089-aac1-fd0b2a0738d0" => "component_variable_5fec5f46_bbac_4089_aac1_fd0b2a0738d0"]), "eafd5418-78bf-4167-b184-a154b1950a34", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:5b9c7691-36f3-467d-a6ce-0f3ffb7fe707]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 13, $this->source), false), "html", null, true);
        $context["component_variable_fc654977_5646_45bd_a79c_073557e0c635"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e5440168_e710_4c61_a372_9486271539eb"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201"] = ('' === $tmp = "Get Involved") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet mornings
of spring which I enjoy with my whole heart.") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 14
        echo " ";
        $context["component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4"] = ('' === $tmp = "See programs") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7f725cba_761f_49ee_88b0_34bcae901ef4"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_ac968219_2db3_4d41_ae79_e3f79b436671"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c9379808_05b5_40eb_9669_186474d82483"] = 12;
        echo " ";
        $context["component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db"] =  -2;
        echo " ";
        $context["component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20"] =  -2;
        echo " ";
        $context["component_variable_4b467c3b_b26d_49c6_9116_311a669a049c"] = true;
        echo " ";
        $context["component_variable_558e8243_29d2_4a3d_8d5c_509101e76414"] = true;
        echo " ";
        $context["component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1"] = false;
        echo " ";
        $context["component_variable_a968d804_8518_4fb9_969e_06a5504d3284"] = true;
        echo " ";
        $context["component_variable_004d1470_56bb_4840_8887_b5aa0b776a8a"] = 6;
        echo " ";
        $context["component_variable_0708696f_52ca_4e8c_bbac_b6c2ab5603d4"] = ('' === $tmp = "rgba(0, 104, 125, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6e6f0bf8_f04f_4eca_8c9d_cf9917513754"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_22a9f380_a4a8_4459_b7e3_60bed10a7028"] = ('' === $tmp = "rgba(255, 227, 150, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_62b99a69_8965_479b_98bc_d7287097ffa5"] = ('' === $tmp = "Get Involved") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9711edf2_044b_4042_9bb6_ed3b94e8b791"] = 6;
        echo " ";
        $context["component_variable_8e3d1096_ee5d_4ff3_8d31_2f17de4b43d3"] = 12;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_horizontal_16_9", false, $this->sandbox->ensureToStringAllowed($context, 14, $this->source), ["fc654977-5646-45bd-a79c-073557e0c635" => "component_variable_fc654977_5646_45bd_a79c_073557e0c635", "e5440168-e710-4c61-a372-9486271539eb" => "component_variable_e5440168_e710_4c61_a372_9486271539eb", "0150e186-1886-491c-8eeb-3eff0d1ea201" => "component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201", "c25990a1-9edb-47ed-ae4d-673395f9457b" => "component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b", "5d1fad68-87b6-4a97-995f-a2b99334c0d4" => "component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4", "39207af3-9cab-4489-ac19-4ea160ab81b4" => "component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4", "7f725cba-761f-49ee-88b0-34bcae901ef4" => "component_variable_7f725cba_761f_49ee_88b0_34bcae901ef4", "ac968219-2db3-4d41-ae79-e3f79b436671" => "component_variable_ac968219_2db3_4d41_ae79_e3f79b436671", "c9379808-05b5-40eb-9669-186474d82483" => "component_variable_c9379808_05b5_40eb_9669_186474d82483", "e620b539-d2f4-4cad-b11e-ed1aceb063db" => "component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db", "46a89c29-8d1c-431c-b508-6716f7e3ab20" => "component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20", "4b467c3b-b26d-49c6-9116-311a669a049c" => "component_variable_4b467c3b_b26d_49c6_9116_311a669a049c", "558e8243-29d2-4a3d-8d5c-509101e76414" => "component_variable_558e8243_29d2_4a3d_8d5c_509101e76414", "a384f576-0ed0-427c-b9b5-3a4df20fbff1" => "component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1", "a968d804-8518-4fb9-969e-06a5504d3284" => "component_variable_a968d804_8518_4fb9_969e_06a5504d3284", "004d1470-56bb-4840-8887-b5aa0b776a8a" => "component_variable_004d1470_56bb_4840_8887_b5aa0b776a8a", "0708696f-52ca-4e8c-bbac-b6c2ab5603d4" => "component_variable_0708696f_52ca_4e8c_bbac_b6c2ab5603d4", "6e6f0bf8-f04f-4eca-8c9d-cf9917513754" => "component_variable_6e6f0bf8_f04f_4eca_8c9d_cf9917513754", "22a9f380-a4a8-4459-b7e3-60bed10a7028" => "component_variable_22a9f380_a4a8_4459_b7e3_60bed10a7028", "62b99a69-8965-479b-98bc-d7287097ffa5" => "component_variable_62b99a69_8965_479b_98bc_d7287097ffa5", "9711edf2-044b-4042-9bb6-ed3b94e8b791" => "component_variable_9711edf2_044b_4042_9bb6_ed3b94e8b791", "8e3d1096-ee5d-4ff3-8d31-2f17de4b43d3" => "component_variable_8e3d1096_ee5d_4ff3_8d31_2f17de4b43d3"], "1a747a10-c645-495e-9c73-ac2113fe62ad", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p><span class=\"coh-style-pre-heading\">Pre header</span></p>

<h2 class=\"coh-style-heading-1-size-medium\">Find ways to help your community</h2>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.</p>

<p>If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages. It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family. Their separate existence is a myth.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 21
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 21, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "67ef990d-ca15-4d6e-8d3f-97507b266815", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:66d04df6-75f0-407b-9f42-4562187e2562]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 21, $this->source), false), "html", null, true);
        $context["component_variable_fc654977_5646_45bd_a79c_073557e0c635"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e5440168_e710_4c61_a372_9486271539eb"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201"] = ('' === $tmp = "Check Out Community Events") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4"] = ('' === $tmp = "A wonderful serenity has taken possession of my entire soul, like these sweet 
mornings of spring which I enjoy with my whole heart.") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 22
        echo " ";
        $context["component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4"] = ('' === $tmp = "See events") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_7f725cba_761f_49ee_88b0_34bcae901ef4"] = ('' === $tmp = "/events") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_004d1470_56bb_4840_8887_b5aa0b776a8a"] = 6;
        echo " ";
        $context["component_variable_c9379808_05b5_40eb_9669_186474d82483"] =  -2;
        echo " ";
        $context["component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db"] =  -2;
        echo " ";
        $context["component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20"] =  -2;
        echo " ";
        $context["component_variable_4b467c3b_b26d_49c6_9116_311a669a049c"] = true;
        echo " ";
        $context["component_variable_558e8243_29d2_4a3d_8d5c_509101e76414"] = true;
        echo " ";
        $context["component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1"] = false;
        echo " ";
        $context["component_variable_a968d804_8518_4fb9_969e_06a5504d3284"] = false;
        echo " ";
        $context["component_variable_0708696f_52ca_4e8c_bbac_b6c2ab5603d4"] = ('' === $tmp = "rgba(0, 104, 125, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6e6f0bf8_f04f_4eca_8c9d_cf9917513754"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_22a9f380_a4a8_4459_b7e3_60bed10a7028"] = ('' === $tmp = "rgba(255, 227, 150, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_62b99a69_8965_479b_98bc_d7287097ffa5"] = ('' === $tmp = "Check Out Community Events") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9711edf2_044b_4042_9bb6_ed3b94e8b791"] = 6;
        echo " ";
        $context["component_variable_8e3d1096_ee5d_4ff3_8d31_2f17de4b43d3"] = 12;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_horizontal_16_9", false, $this->sandbox->ensureToStringAllowed($context, 22, $this->source), ["fc654977-5646-45bd-a79c-073557e0c635" => "component_variable_fc654977_5646_45bd_a79c_073557e0c635", "e5440168-e710-4c61-a372-9486271539eb" => "component_variable_e5440168_e710_4c61_a372_9486271539eb", "0150e186-1886-491c-8eeb-3eff0d1ea201" => "component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201", "c25990a1-9edb-47ed-ae4d-673395f9457b" => "component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b", "5d1fad68-87b6-4a97-995f-a2b99334c0d4" => "component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4", "39207af3-9cab-4489-ac19-4ea160ab81b4" => "component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4", "7f725cba-761f-49ee-88b0-34bcae901ef4" => "component_variable_7f725cba_761f_49ee_88b0_34bcae901ef4", "004d1470-56bb-4840-8887-b5aa0b776a8a" => "component_variable_004d1470_56bb_4840_8887_b5aa0b776a8a", "c9379808-05b5-40eb-9669-186474d82483" => "component_variable_c9379808_05b5_40eb_9669_186474d82483", "e620b539-d2f4-4cad-b11e-ed1aceb063db" => "component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db", "46a89c29-8d1c-431c-b508-6716f7e3ab20" => "component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20", "4b467c3b-b26d-49c6-9116-311a669a049c" => "component_variable_4b467c3b_b26d_49c6_9116_311a669a049c", "558e8243-29d2-4a3d-8d5c-509101e76414" => "component_variable_558e8243_29d2_4a3d_8d5c_509101e76414", "a384f576-0ed0-427c-b9b5-3a4df20fbff1" => "component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1", "a968d804-8518-4fb9-969e-06a5504d3284" => "component_variable_a968d804_8518_4fb9_969e_06a5504d3284", "0708696f-52ca-4e8c-bbac-b6c2ab5603d4" => "component_variable_0708696f_52ca_4e8c_bbac_b6c2ab5603d4", "6e6f0bf8-f04f-4eca-8c9d-cf9917513754" => "component_variable_6e6f0bf8_f04f_4eca_8c9d_cf9917513754", "22a9f380-a4a8-4459-b7e3-60bed10a7028" => "component_variable_22a9f380_a4a8_4459_b7e3_60bed10a7028", "62b99a69-8965-479b-98bc-d7287097ffa5" => "component_variable_62b99a69_8965_479b_98bc_d7287097ffa5", "9711edf2-044b-4042-9bb6-ed3b94e8b791" => "component_variable_9711edf2_044b_4042_9bb6_ed3b94e8b791", "8e3d1096-ee5d-4ff3-8d31-2f17de4b43d3" => "component_variable_8e3d1096_ee5d_4ff3_8d31_2f17de4b43d3"], "31ca3ae4-23c0-4f3f-ac18-7583065647fa", ""), "html", null, true);
        echo " 
";
        // line 23
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 23, $this->source));
        }
    }

    // line 3
    public function block_block1908827058($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_text"] = ('' === $tmp = "<p class=\"coh-style-pre-heading\">GOVERNMENT</p>

<h1>Our Local Government</h1>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 8
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a581345e_9290_4d1d_ac78_20b3ba547743"] = ('' === $tmp = "MEET THE MAYOR") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_86d5677f_86b4_4f30_845a_25636792b9a3"] = ('' === $tmp = "node::500") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741"] = ('' === $tmp = "coh-style-height--large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7"] = 8;
        echo " ";
        $context["component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f"] = 12;
        echo " ";
        $context["component_variable_9ee3460e_b550_45b2_842f_b7ee235048ab"] = 12;
        echo " ";
        $context["component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8"] = ('' === $tmp = "Center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd1d1cc_031f_438a_82fc_43edca962513"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b7b4763e_bcb8_48ae_b571_68830beeb52f"] = ('' === $tmp = "rgba(46, 46, 46, 0.79)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84"] = 1;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_90226570_4c01_4971_8985_6564b065a63d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dc3d74f2_e281_4c18_8689_1f266560111b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fee69872_6425_4df2_a336_61768fe7c265"] = ('' === $tmp = "coh-style-link-button") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_2edd0301_f1dd_4e36_91f0_87b631b2633f"] = ('' === $tmp = "none") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_fa0479ad_04e2_4876_81cd_7558ca9f8d83"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f2f7a954_c857_496e_b341_a7622ba00b09"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_000fa43a_7962_4399_8666_694381f50612"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_05f9145b_9bab_4355_bfa8_30f0e1dcb48a"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_hero", false, $this->sandbox->ensureToStringAllowed($context, 8, $this->source), ["ec518aee-3987-4edc-8630-c679120136af" => ["text" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_text", "textFormat" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"], "1ca08220-ccc9-4171-a2d3-993ea04fe1d0" => "component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0", "a581345e-9290-4d1d-ac78-20b3ba547743" => "component_variable_a581345e_9290_4d1d_ac78_20b3ba547743", "86d5677f-86b4-4f30-845a-25636792b9a3" => "component_variable_86d5677f_86b4_4f30_845a_25636792b9a3", "fe487eb0-8848-4d8d-9901-bb5cb64c4741" => "component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741", "5311228f-f968-4346-bbe1-747dfde7b1f7" => "component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7", "35d8f0ae-b2db-4f9d-941f-ce47958aae5f" => "component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f", "9ee3460e-b550-45b2-842f-b7ee235048ab" => "component_variable_9ee3460e_b550_45b2_842f_b7ee235048ab", "29ff2bde-d589-4eb3-a0a8-ddcc23fa5aa8" => "component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8", "f30e5ad5-c3c7-44a3-bf47-882cb74da487" => "component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487", "6bd1d1cc-031f-438a-82fc-43edca962513" => "component_variable_6bd1d1cc_031f_438a_82fc_43edca962513", "15bb3c39-f87e-4ace-a924-ae9ae1867c94" => "component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94", "b7b4763e-bcb8-48ae-b571-68830beeb52f" => "component_variable_b7b4763e_bcb8_48ae_b571_68830beeb52f", "5502b4d7-a6bd-467a-993d-625ef4002d84" => "component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84", "90226570-4c01-4971-8985-6564b065a63d" => "component_variable_90226570_4c01_4971_8985_6564b065a63d", "dc3d74f2-e281-4c18-8689-1f266560111b" => "component_variable_dc3d74f2_e281_4c18_8689_1f266560111b", "e330c7cb-1cb4-41a0-b3b0-ec95a9764b7d" => "component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d", "fee69872-6425-4df2-a336-61768fe7c265" => "component_variable_fee69872_6425_4df2_a336_61768fe7c265", "2edd0301-f1dd-4e36-91f0-87b631b2633f" => "component_variable_2edd0301_f1dd_4e36_91f0_87b631b2633f", "fa0479ad-04e2-4876-81cd-7558ca9f8d83" => "component_variable_fa0479ad_04e2_4876_81cd_7558ca9f8d83", "f2f7a954-c857-496e-b341-a7622ba00b09" => "component_variable_f2f7a954_c857_496e_b341_a7622ba00b09", "000fa43a-7962-4399-8666-694381f50612" => "component_variable_000fa43a_7962_4399_8666_694381f50612", "05f9145b-9bab-4355-bfa8-30f0e1dcb48a" => "component_variable_05f9145b_9bab_4355_bfa8_30f0e1dcb48a"], "998b0259-1036-4255-b640-8fadc2b97060", ""), "html", null, true);
        echo " ";
    }

    public function block_block3901577689($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:cb72b5f0-2025-4043-96e0-4f5e1d749605]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 8, $this->source), false), "html", null, true);
        $context["component_variable_fc654977_5646_45bd_a79c_073557e0c635"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_62b99a69_8965_479b_98bc_d7287097ffa5"] = ('' === $tmp = "Meet the Mayor") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e5440168_e710_4c61_a372_9486271539eb"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201"] = ('' === $tmp = "Meet the Mayor") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4"] = ('' === $tmp = "The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words. 

If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages. It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family. Their separate existence is a myth.") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 10
        echo " ";
        $context["component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4"] = ('' === $tmp = "Read More") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_7f725cba_761f_49ee_88b0_34bcae901ef4"] = ('' === $tmp = "node::500") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_004d1470_56bb_4840_8887_b5aa0b776a8a"] = 8;
        echo " ";
        $context["component_variable_c9379808_05b5_40eb_9669_186474d82483"] =  -2;
        echo " ";
        $context["component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db"] =  -2;
        echo " ";
        $context["component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20"] =  -2;
        echo " ";
        $context["component_variable_4b467c3b_b26d_49c6_9116_311a669a049c"] = false;
        echo " ";
        $context["component_variable_558e8243_29d2_4a3d_8d5c_509101e76414"] = false;
        echo " ";
        $context["component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1"] = false;
        echo " ";
        $context["component_variable_a968d804_8518_4fb9_969e_06a5504d3284"] = true;
        echo " ";
        $context["component_variable_9711edf2_044b_4042_9bb6_ed3b94e8b791"] = 6;
        echo " ";
        $context["component_variable_8e3d1096_ee5d_4ff3_8d31_2f17de4b43d3"] = 12;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_horizontal_16_9", false, $this->sandbox->ensureToStringAllowed($context, 10, $this->source), ["fc654977-5646-45bd-a79c-073557e0c635" => "component_variable_fc654977_5646_45bd_a79c_073557e0c635", "62b99a69-8965-479b-98bc-d7287097ffa5" => "component_variable_62b99a69_8965_479b_98bc_d7287097ffa5", "e5440168-e710-4c61-a372-9486271539eb" => "component_variable_e5440168_e710_4c61_a372_9486271539eb", "0150e186-1886-491c-8eeb-3eff0d1ea201" => "component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201", "c25990a1-9edb-47ed-ae4d-673395f9457b" => "component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b", "5d1fad68-87b6-4a97-995f-a2b99334c0d4" => "component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4", "39207af3-9cab-4489-ac19-4ea160ab81b4" => "component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4", "7f725cba-761f-49ee-88b0-34bcae901ef4" => "component_variable_7f725cba_761f_49ee_88b0_34bcae901ef4", "004d1470-56bb-4840-8887-b5aa0b776a8a" => "component_variable_004d1470_56bb_4840_8887_b5aa0b776a8a", "c9379808-05b5-40eb-9669-186474d82483" => "component_variable_c9379808_05b5_40eb_9669_186474d82483", "e620b539-d2f4-4cad-b11e-ed1aceb063db" => "component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db", "46a89c29-8d1c-431c-b508-6716f7e3ab20" => "component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20", "4b467c3b-b26d-49c6-9116-311a669a049c" => "component_variable_4b467c3b_b26d_49c6_9116_311a669a049c", "558e8243-29d2-4a3d-8d5c-509101e76414" => "component_variable_558e8243_29d2_4a3d_8d5c_509101e76414", "a384f576-0ed0-427c-b9b5-3a4df20fbff1" => "component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1", "a968d804-8518-4fb9-969e-06a5504d3284" => "component_variable_a968d804_8518_4fb9_969e_06a5504d3284", "9711edf2-044b-4042-9bb6-ed3b94e8b791" => "component_variable_9711edf2_044b_4042_9bb6_ed3b94e8b791", "8e3d1096-ee5d-4ff3-8d31-2f17de4b43d3" => "component_variable_8e3d1096_ee5d_4ff3_8d31_2f17de4b43d3"], "b1b2450b-be92-4c1f-b33c-585ec57cfe7d", ""), "html", null, true);
        echo " ";
    }

    public function block_block2112490912($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h2 class=\"text-align-center\"><span class=\"coh-color-white\">City Council Representatives</span></h2>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 11
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "fa003ea9-24d1-4424-92ae-5007e457617f", ""), "html", null, true);
        echo " ";
        $context["component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_d29242f9_57b0_4002_841d_505458c3b21d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1901649179', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["694ba725-ae4c-4711-a676-e6351ea4e2bc" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_container", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 11, $this->source), ["2b28beb7-e16d-4e4d-bfaf-dddb4224de35" => "component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35", "c81d21c0-2a3c-4caa-9d91-342a9c5a94da" => "component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da", "d29242f9-57b0-4002-841d-505458c3b21d" => "component_variable_d29242f9_57b0_4002_841d_505458c3b21d"]), "ba538cfc-31ef-4371-a2cb-07e763643eef", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p class=\"text-align-center\"><a class=\"coh-style-button-cta\" href=\"/people\">VIEW ALL</a></p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 12
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 12, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "a751dc30-6ce3-483c-b39e-6594e717ea02", ""), "html", null, true);
        echo " ";
    }

    // line 11
    public function block_block1901649179($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 503;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "d4e4605c-8b9b-4d62-8253-c2e1b23839ca", ""), "html", null, true);
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 501;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "5ed1d7f3-685a-45c1-930c-4ccc78a3ed22", ""), "html", null, true);
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 502;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 11, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "94acee67-84ab-48ee-b072-466d6311c904", ""), "html", null, true);
        echo " ";
    }

    // line 13
    public function block_block2220068317($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_ee7f84cb_ba0e_4c81_9232_7db285ed79ee"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dcfc1804_f405_4632_b2b9_e57cdb828b4e"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3368480114', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["4f556060-3291-4068-92b5-7ef0b24444d8" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_item", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["ee7f84cb-ba0e-4c81-9232-7db285ed79ee" => "component_variable_ee7f84cb_ba0e_4c81_9232_7db285ed79ee", "dcfc1804-f405-4632-b2b9-e57cdb828b4e" => "component_variable_dcfc1804_f405_4632_b2b9_e57cdb828b4e"]), "a65c364b-6781-4947-80c2-4e3d7d20fcb8", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_ee7f84cb_ba0e_4c81_9232_7db285ed79ee"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_dcfc1804_f405_4632_b2b9_e57cdb828b4e"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block309827762', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["4f556060-3291-4068-92b5-7ef0b24444d8" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_item", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["ee7f84cb-ba0e-4c81-9232-7db285ed79ee" => "component_variable_ee7f84cb_ba0e_4c81_9232_7db285ed79ee", "dcfc1804-f405-4632-b2b9-e57cdb828b4e" => "component_variable_dcfc1804_f405_4632_b2b9_e57cdb828b4e"]), "61bdaba6-627e-47f1-b1f2-a5e6b55b3b21", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_ee7f84cb_ba0e_4c81_9232_7db285ed79ee"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_dcfc1804_f405_4632_b2b9_e57cdb828b4e"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2773094859', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["4f556060-3291-4068-92b5-7ef0b24444d8" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_item", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["ee7f84cb-ba0e-4c81-9232-7db285ed79ee" => "component_variable_ee7f84cb_ba0e_4c81_9232_7db285ed79ee", "dcfc1804-f405-4632-b2b9-e57cdb828b4e" => "component_variable_dcfc1804_f405_4632_b2b9_e57cdb828b4e"]), "eb6a8885-f690-4c5f-bc61-24d3e9dcb6fe", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_ee7f84cb_ba0e_4c81_9232_7db285ed79ee"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_dcfc1804_f405_4632_b2b9_e57cdb828b4e"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3146409927', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["4f556060-3291-4068-92b5-7ef0b24444d8" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_item", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 13, $this->source), ["ee7f84cb-ba0e-4c81-9232-7db285ed79ee" => "component_variable_ee7f84cb_ba0e_4c81_9232_7db285ed79ee", "dcfc1804-f405-4632-b2b9-e57cdb828b4e" => "component_variable_dcfc1804_f405_4632_b2b9_e57cdb828b4e"]), "2d6869e5-ae7a-437c-9f01-8e2dc29984ea", ""), "html", null, true);
        echo " ";
    }

    public function block_block3368480114($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:07a4f536-4f2c-4d08-aa72-bed55a37b16c]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 13, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "Department of Transportation") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Find out more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 12;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 12;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "Department of Transportation") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034"], "f1700485-8655-4a29-9c1a-0c0c70a29328", ""), "html", null, true);
        echo " ";
    }

    public function block_block309827762($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:4da4efb8-21fb-4bf6-b3dc-bf8900ce6057]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 13, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "Department of Cultural Affairs") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Find out more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 12;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 12;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "Department of Cultural Affairs") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034"], "e233a596-9d68-4fad-ab3a-7eff0dbc1136", ""), "html", null, true);
        echo " ";
    }

    public function block_block2773094859($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:d86917fb-5186-4630-b815-72b7beaf4d31]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 13, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "Department of Children’s Services") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Find out more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 12;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 12;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "Department of Children’s Services") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034"], "50f31be4-7579-43d4-9475-537ab2585730", ""), "html", null, true);
        echo " ";
    }

    public function block_block3146409927($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:e1613710-06ac-41c1-966e-59a8d1b3d387]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 13, $this->source), false), "html", null, true);
        $context["component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_1bf8a830_596a_4583_99be_9087b54e73c9"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de"] = ('' === $tmp = "Placeholder for Content Title Here") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241"] = ('' === $tmp = "Find out more") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_75180256_25ce_4c17_b9eb_0082235d796e"] = 12;
        echo " ";
        $context["component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805"] = 12;
        echo " ";
        $context["component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da"] = 12;
        echo " ";
        $context["component_variable_50276531_6d3c_4ac5_8690_364db32335cb"] = true;
        echo " ";
        $context["component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928"] = true;
        echo " ";
        $context["component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f"] = false;
        echo " ";
        $context["component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92"] = ('' === $tmp = "coh-style-container-theme---gray-5") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42"] = ('' === $tmp = "left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_196c6b01_f710_4f54_9068_e23fc467b034"] = ('' === $tmp = "Department of Cultural Affairs") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_vertical", false, $this->sandbox->ensureToStringAllowed($context, 13, $this->source), ["81ff84c6-ed80-4983-9906-7cacaf1cf656" => "component_variable_81ff84c6_ed80_4983_9906_7cacaf1cf656", "1bf8a830-596a-4583-99be-9087b54e73c9" => "component_variable_1bf8a830_596a_4583_99be_9087b54e73c9", "980ceff8-44a6-4c5c-b37c-57461d2e13de" => "component_variable_980ceff8_44a6_4c5c_b37c_57461d2e13de", "f79e53e2-41fb-4d21-9830-8b8bf6269f6f" => "component_variable_f79e53e2_41fb_4d21_9830_8b8bf6269f6f", "5a86ef1c-f88d-41c0-b6fa-bd91c6cc5241" => "component_variable_5a86ef1c_f88d_41c0_b6fa_bd91c6cc5241", "a2264ba5-dfeb-4c5a-85e0-5e79f22f6b42" => "component_variable_a2264ba5_dfeb_4c5a_85e0_5e79f22f6b42", "75180256-25ce-4c17-b9eb-0082235d796e" => "component_variable_75180256_25ce_4c17_b9eb_0082235d796e", "992eb1f7-40fb-46ae-ab0d-91d841f9b805" => "component_variable_992eb1f7_40fb_46ae_ab0d_91d841f9b805", "a5f9260d-01bb-4251-8951-6364ece0e2da" => "component_variable_a5f9260d_01bb_4251_8951_6364ece0e2da", "50276531-6d3c-4ac5-8690-364db32335cb" => "component_variable_50276531_6d3c_4ac5_8690_364db32335cb", "f92d3edf-85b8-4f0a-b6f2-6ba048b37928" => "component_variable_f92d3edf_85b8_4f0a_b6f2_6ba048b37928", "dc5df1bd-d5b9-4f57-bd43-ff0fc8ebca6f" => "component_variable_dc5df1bd_d5b9_4f57_bd43_ff0fc8ebca6f", "45e6bc50-34bd-4e2e-9fe1-5f50bfa0ec92" => "component_variable_45e6bc50_34bd_4e2e_9fe1_5f50bfa0ec92", "3ba91185-7c3e-49ed-8091-db342ef8c056" => "component_variable_3ba91185_7c3e_49ed_8091_db342ef8c056", "d1d6507b-d054-47ee-bdee-69df3586cad5" => "component_variable_d1d6507b_d054_47ee_bdee_69df3586cad5", "8faa6f5a-7382-40d3-b90b-e72cac362c42" => "component_variable_8faa6f5a_7382_40d3_b90b_e72cac362c42", "196c6b01-f710-4f54-9068-e23fc467b034" => "component_variable_196c6b01_f710_4f54_9068_e23fc467b034"], "39e78960-8fa5-4956-915a-7f093bdf4a23", ""), "html", null, true);
        echo " ";
    }

    public function getTemplateName()
    {
        return "__string_template__ab797f8182bbd29390bda23db981225a7406762ffa665b281cdf0635912579f4";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  635 => 13,  568 => 11,  544 => 12,  500 => 11,  464 => 10,  385 => 8,  374 => 3,  368 => 23,  331 => 22,  297 => 21,  249 => 14,  187 => 13,  173 => 12,  123 => 10,  102 => 8,  51 => 3,  48 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__ab797f8182bbd29390bda23db981225a7406762ffa665b281cdf0635912579f4", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 3, "if" => 8);
        static $filters = array("escape" => 3, "merge" => 8, "render" => 23);
        static $functions = array("attach_library" => 3, "processtoken" => 3, "renderComponent" => 8);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'merge', 'render'],
                ['attach_library', 'processtoken', 'renderComponent']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
