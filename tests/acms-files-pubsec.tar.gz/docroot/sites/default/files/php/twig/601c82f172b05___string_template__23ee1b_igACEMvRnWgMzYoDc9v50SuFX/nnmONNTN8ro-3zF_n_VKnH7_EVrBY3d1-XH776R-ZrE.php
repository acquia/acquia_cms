<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__23ee1bf03b90e29bffb0691dcb34f908ce1b165a732e0b62f2aab1b8dd1543ae */
class __TwigTemplate_057e5fa73d3374b2a9d8a92c3462047c6e652e81809894a7825765f276a0e5bb extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block20888249' => [$this, 'block_block20888249'],
            'block359355848' => [$this, 'block_block359355848'],
            'block4001529139' => [$this, 'block_block4001529139'],
            'block4186465014' => [$this, 'block_block4186465014'],
            'block110703507' => [$this, 'block_block110703507'],
            'block3881875989' => [$this, 'block_block3881875989'],
            'block1709444024' => [$this, 'block_block1709444024'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = ('' === $tmp = "20px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = "coh-style-padding-bottom---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = true;
        echo " ";
        $context["component_variable_028cf87b_ada9_4c88_880d_7dd19de841bd"] = 0;
        echo " ";
        $context["component_variable_301ad76b_785d_4615_af93_ce27b0968b26"] = 1;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block20888249', $context, $blocks);
        // line 30
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 30, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "028cf87b-ada9-4c88-880d-7dd19de841bd" => "component_variable_028cf87b_ada9_4c88_880d_7dd19de841bd", "301ad76b-785d-4615-af93-ce27b0968b26" => "component_variable_301ad76b_785d_4615_af93_ce27b0968b26"]), "c390eb93-9936-4847-9b92-c7b29b13da63", ""), "html", null, true);
        echo " 
";
        // line 31
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 31, $this->source));
        }
    }

    // line 3
    public function block_block20888249($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_593842fb_7f78_4e90_955d_bebe642a3808"] = false;
        echo " ";
        $context["component_variable_2d39f7ae_3f75_45bc_8c91_ed0907b6b499"] = ('' === $tmp = "h1") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f526db5b_c574_42b2_b463_72b391b1fbd0"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8c714c57_bc87_48a9_b5d7_528fb4a01464"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_724bd0ae_c245_48b0_b08e_dd80bce6f825"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_43204cc1_bf5c_4729_aebe_8be328824868"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_ff9f716c_ee36_4813_80f4_1f924010206b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8c0355b9_edb1_4ab5_8c81_8438e6c564cf"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_8f48ee6a_a11c_4981_a464_31ff2f8d3875"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_81375114_da17_4d48_bcd5_ddceecbe7ff7"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5cc53e52_bf48_4645_a52c_a18b4c30c503"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_55af0c22_0b6c_4718_952b_5ef535dd9de7"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1d587270_08d8_45ea_b6a7_4d69a2fd213b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a66ecc62_f679_48cd_9c08_89d3dcd20f7d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6674b76b_380b_4762_b054_3258e0f4c14c"] = ('' === $tmp = "Style Guide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_title", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), ["593842fb-7f78-4e90-955d-bebe642a3808" => "component_variable_593842fb_7f78_4e90_955d_bebe642a3808", "2d39f7ae-3f75-45bc-8c91-ed0907b6b499" => "component_variable_2d39f7ae_3f75_45bc_8c91_ed0907b6b499", "f526db5b-c574-42b2-b463-72b391b1fbd0" => "component_variable_f526db5b_c574_42b2_b463_72b391b1fbd0", "8c714c57-bc87-48a9-b5d7-528fb4a01464" => "component_variable_8c714c57_bc87_48a9_b5d7_528fb4a01464", "724bd0ae-c245-48b0-b08e-dd80bce6f825" => "component_variable_724bd0ae_c245_48b0_b08e_dd80bce6f825", "43204cc1-bf5c-4729-aebe-8be328824868" => "component_variable_43204cc1_bf5c_4729_aebe_8be328824868", "ff9f716c-ee36-4813-80f4-1f924010206b" => "component_variable_ff9f716c_ee36_4813_80f4_1f924010206b", "8c0355b9-edb1-4ab5-8c81-8438e6c564cf" => "component_variable_8c0355b9_edb1_4ab5_8c81_8438e6c564cf", "8f48ee6a-a11c-4981-a464-31ff2f8d3875" => "component_variable_8f48ee6a_a11c_4981_a464_31ff2f8d3875", "81375114-da17-4d48-bcd5-ddceecbe7ff7" => "component_variable_81375114_da17_4d48_bcd5_ddceecbe7ff7", "5cc53e52-bf48-4645-a52c-a18b4c30c503" => "component_variable_5cc53e52_bf48_4645_a52c_a18b4c30c503", "55af0c22-0b6c-4718-952b-5ef535dd9de7" => "component_variable_55af0c22_0b6c_4718_952b_5ef535dd9de7", "1d587270-08d8-45ea-b6a7-4d69a2fd213b" => "component_variable_1d587270_08d8_45ea_b6a7_4d69a2fd213b", "a66ecc62-f679-48cd-9c08-89d3dcd20f7d" => "component_variable_a66ecc62_f679_48cd_9c08_89d3dcd20f7d", "6674b76b-380b-4762-b054-3258e0f4c14c" => "component_variable_6674b76b_380b_4762_b054_3258e0f4c14c"], "56ddfa58-d245-4cf5-909d-2e1b98475921", ""), "html", null, true);
        echo " ";
        $context["component_variable_10cd46b8_1502_452a_b22f_e80bddd24ab8"] = 3;
        echo " ";
        $context["component_variable_041ca18b_df20_43ce_80ad_0263fe15e758"] = 9;
        echo " ";
        $context["component_variable_df38c02f_b799_425f_b11c_0958132250c4"] = 3;
        echo " ";
        $context["component_variable_a8f0de15_676c_438a_b44e_f36607505b27"] = 9;
        echo " ";
        $context["component_variable_48c7581b_1324_4e6d_92a5_dd79448655f4"] = 12;
        echo " ";
        $context["component_variable_1b0a4239_454f_40d4_91fa_a0331cf3d982"] = 12;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block359355848', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["4ad09ba3-58dc-463b-89fe-dc965c34a8d9" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block4001529139', $context, $blocks);
        // line 30
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["203f5b74-68fb-45f6-a740-4025c2edb231" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_two_column", false, $this->sandbox->ensureToStringAllowed($context, 30, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["10cd46b8-1502-452a-b22f-e80bddd24ab8" => "component_variable_10cd46b8_1502_452a_b22f_e80bddd24ab8", "041ca18b-df20-43ce-80ad-0263fe15e758" => "component_variable_041ca18b_df20_43ce_80ad_0263fe15e758", "df38c02f-b799-425f-b11c-0958132250c4" => "component_variable_df38c02f_b799_425f_b11c_0958132250c4", "a8f0de15-676c-438a-b44e-f36607505b27" => "component_variable_a8f0de15_676c_438a_b44e_f36607505b27", "48c7581b-1324-4e6d-92a5-dd79448655f4" => "component_variable_48c7581b_1324_4e6d_92a5_dd79448655f4", "1b0a4239-454f-40d4-91fa-a0331cf3d982" => "component_variable_1b0a4239_454f_40d4_91fa_a0331cf3d982"]), "d5dce366-313c-4773-a5c2-f2dd2cb7d9ee", ""), "html", null, true);
        echo " ";
    }

    // line 3
    public function block_block359355848($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_sidebar_nav", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), [], "f14a0dce-4346-4e94-a7ec-222a136f5456", ""), "html", null, true);
        echo " ";
    }

    public function block_block4001529139($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " <h2 class=\"coh-heading coh-ce-5f7ae699\"> Slider </h2> ";
        $context["component_variable_effdbd65_c5f8_4040_bda9_83449e60856b"] = 1;
        echo " ";
        $context["component_variable_f5d96f8a_8fa1_4019_ad89_2138b5ec4ffc"] = 1;
        echo " ";
        $context["component_variable_ac8248d6_90fa_4542_800c_b50f6c2a3e56"] = 1;
        echo " ";
        $context["component_variable_7ca2cfb9_d739_4e64_83ce_fb086b3a4c07"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_2673b9ac_b236_468c_8aff_64d9be9e9d97"] = ('' === $tmp = "move-pagination-up") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block4186465014', $context, $blocks);
        // line 30
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["342bec96-01e9-43e0-b28b-4cfd21ea3ead" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_container", false, $this->sandbox->ensureToStringAllowed($context, 30, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["effdbd65-c5f8-4040-bda9-83449e60856b" => "component_variable_effdbd65_c5f8_4040_bda9_83449e60856b", "f5d96f8a-8fa1-4019-ad89-2138b5ec4ffc" => "component_variable_f5d96f8a_8fa1_4019_ad89_2138b5ec4ffc", "ac8248d6-90fa-4542-800c-b50f6c2a3e56" => "component_variable_ac8248d6_90fa_4542_800c_b50f6c2a3e56", "7ca2cfb9-d739-4e64-83ce-fb086b3a4c07" => "component_variable_7ca2cfb9_d739_4e64_83ce_fb086b3a4c07", "2673b9ac-b236-468c-8aff-64d9be9e9d97" => "component_variable_2673b9ac_b236_468c_8aff_64d9be9e9d97"]), "1d0676fc-1145-4563-b7bb-639e61851f93", ""), "html", null, true);
        echo " ";
    }

    // line 3
    public function block_block4186465014($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block110703507', $context, $blocks);
        // line 12
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 12, $this->source), ["4f556060-3291-4068-92b5-7ef0b24444d8" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_item", false, $this->sandbox->ensureToStringAllowed($context, 12, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 12, $this->source), []), "a6f0fff9-099b-4d34-9f4c-b62d455fb24d", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3881875989', $context, $blocks);
        // line 21
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 21, $this->source), ["4f556060-3291-4068-92b5-7ef0b24444d8" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_item", false, $this->sandbox->ensureToStringAllowed($context, 21, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 21, $this->source), []), "86dc207e-8392-4f9e-9e3e-0321796336bd", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1709444024', $context, $blocks);
        // line 30
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), ["4f556060-3291-4068-92b5-7ef0b24444d8" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("slide_item", false, $this->sandbox->ensureToStringAllowed($context, 30, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 30, $this->source), []), "3a7fa83f-b696-47b5-87ea-6fbdb7cd9aad", ""), "html", null, true);
        echo " ";
    }

    // line 3
    public function block_block110703507($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h4 class=\"coh-style-pre-heading\">Pre header</h4>

<h2>Medium length display headline</h2>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.</p>

<p>If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages. It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family. Their separate existence is a myth.</p>

<p>For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words. If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 12
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 12, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "38b9606e-ef64-44e9-a1c5-03c022d7ade1", ""), "html", null, true);
        echo " ";
    }

    public function block_block3881875989($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h4 class=\"coh-style-pre-heading\">Pre header</h4>

<h2>Medium length display headline</h2>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.</p>

<p>If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages. It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family. Their separate existence is a myth.</p>

<p>For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words. If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 21
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 21, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "867fbfdc-f3ce-45b6-bc31-71c2c4a21b79", ""), "html", null, true);
        echo " ";
    }

    public function block_block1709444024($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h4 class=\"coh-style-pre-heading\">Pre header</h4>

<h2>Medium length display headline</h2>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.</p>

<p>If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages. It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family. Their separate existence is a myth.</p>

<p>For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words. If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 30
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---narrow") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 30, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "29bbc59b-158b-45c9-8cfd-4caa18e62333", ""), "html", null, true);
        echo " ";
    }

    public function getTemplateName()
    {
        return "__string_template__23ee1bf03b90e29bffb0691dcb34f908ce1b165a732e0b62f2aab1b8dd1543ae";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  390 => 30,  352 => 21,  314 => 12,  299 => 3,  285 => 30,  270 => 21,  255 => 12,  247 => 3,  233 => 30,  207 => 3,  193 => 30,  121 => 3,  115 => 31,  102 => 30,  49 => 3,  46 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__23ee1bf03b90e29bffb0691dcb34f908ce1b165a732e0b62f2aab1b8dd1543ae", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 3, "if" => 30);
        static $filters = array("escape" => 3, "merge" => 30, "render" => 31);
        static $functions = array("attach_library" => 3, "renderComponent" => 30);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'merge', 'render'],
                ['attach_library', 'renderComponent']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
