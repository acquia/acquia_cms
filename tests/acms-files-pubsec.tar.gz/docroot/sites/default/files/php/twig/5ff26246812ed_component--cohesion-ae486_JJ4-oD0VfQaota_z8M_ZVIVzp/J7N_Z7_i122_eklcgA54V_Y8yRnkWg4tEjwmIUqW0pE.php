<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* sites/default/files/cohesion/templates/component--cohesion-ae486950.html.twig */
class __TwigTemplate_a7703a2b54ab1a83fa25b7543e228b53f7a6545e96d88158841f1b6553c588b2 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        if ((($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->hasDrupalPermission([0 => "access contextual links", 1 => "access components"]) &&  !($context["isPreview"] ?? null)) &&  !(isset($context["hideContextualLinks"]) || array_key_exists("hideContextualLinks", $context)))) {
            echo " <div class=\"dx-contextual-region contextual-region\" data-dx-contextual=\"coh-component-instance-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source), "html", null, true);
            echo "\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 3, $this->source), "html", null, true);
            echo "</div> ";
        }
        echo " <div class=\"coh-accordion-title coh-style-accordion\" data-coh-tab-settings='{\"customStyle\":\"coh-style-tab\"}'><a href=\"#1849274314";
        if ((isset($context["componentUuid"]) || array_key_exists("componentUuid", $context))) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("-" . $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohCrc32($this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source))), "html", null, true);
        }
        if (twig_get_attribute($this->env, $this->source, ($context["loop"] ?? null), "index", [], "any", true, true, true, 3)) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("-" . $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["loop"] ?? null), "index", [], "any", false, false, true, 3), 3, $this->source)), "html", null, true);
        }
        echo "\" >";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "2d4ee479-1451-446b-a0e8-9577d45444dd"));
        echo "</a></div> <div id=\"1849274314";
        if ((isset($context["componentUuid"]) || array_key_exists("componentUuid", $context))) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("-" . $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohCrc32($this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source))), "html", null, true);
        }
        if (twig_get_attribute($this->env, $this->source, ($context["loop"] ?? null), "index", [], "any", true, true, true, 3)) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("-" . $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["loop"] ?? null), "index", [], "any", false, false, true, 3), 3, $this->source)), "html", null, true);
        }
        echo "\" class=\"coh-accordion-tabs-content coh-component coh-component-instance-";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source), "html", null, true);
        echo " contextual-component\"  > <div class=\"coh-container ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "b52ca9c8-0c9d-4683-9f9f-d12a1326621e"));
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "e181d85c-6603-416f-89de-e5849b4f93c5"));
        echo "\" > ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "72d90d85-a475-45c9-ac59-d61edcd812e4"), "html", null, true);
        echo " </div> </div> 
";
        // line 4
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 4, $this->source));
        }
    }

    public function getTemplateName()
    {
        return "sites/default/files/cohesion/templates/component--cohesion-ae486950.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 4,  42 => 3,  39 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "sites/default/files/cohesion/templates/component--cohesion-ae486950.html.twig", "/home/ide/project/docroot/sites/default/files/cohesion/templates/component--cohesion-ae486950.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 3, "set" => 4);
        static $filters = array("escape" => 3, "crc32" => 3, "raw" => 3, "render" => 4);
        static $functions = array("attach_library" => 3, "has_drupal_permission" => 3, "getComponentFieldValue" => 3);

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set'],
                ['escape', 'crc32', 'raw', 'render'],
                ['attach_library', 'has_drupal_permission', 'getComponentFieldValue']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
