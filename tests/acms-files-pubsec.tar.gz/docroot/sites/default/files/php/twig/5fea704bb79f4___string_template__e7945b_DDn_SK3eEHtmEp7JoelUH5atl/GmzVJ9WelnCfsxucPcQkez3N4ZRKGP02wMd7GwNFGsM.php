<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__e7945bbe31166bfd4b29cb5ad70247dad17cf8495f858a78ed5fa383f17d3a05 */
class __TwigTemplate_e4c80173008270b8f52f6b1f7339f04f59f5b33c58e2db2ce76c27ced243ad34 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block139114791' => [$this, 'block_block139114791'],
            'block3314285497' => [$this, 'block_block3314285497'],
            'block3399655064' => [$this, 'block_block3399655064'],
            'block1358639751' => [$this, 'block_block1358639751'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:25eeb4b5-d45f-474d-9f1d-d8bd1daec4e1]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 3, $this->source), false), "html", null, true);
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "80vh") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block139114791', $context, $blocks);
        // line 8
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 8, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 8, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 8, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"]), "ae8e27bf-8937-4d51-9424-c670351988f9", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p><span class=\"coh-style-pre-heading\">contact us</span></p>

<h1 class=\"coh-style-heading-1-size-medium\">Need some help? Get in touch!</h1>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.</p>

<p>If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages. It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family. Their separate existence is a myth.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 15
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"] = ('' === $tmp = "coh-style-position---left") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428", "c7348060-90b2-42e2-8cef-c0a53c6d64fc" => "component_variable_c7348060_90b2_42e2_8cef_c0a53c6d64fc"], "bbd4aee8-aa9b-4e22-b070-f1ccb60169a6", ""), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "None") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = 0;
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3314285497', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 15, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 15, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"]), "12134f27-cb0d-42d4-8477-820028a85687", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<h2 class=\"coh-style-heading-1-size-medium text-align-center\">Our Locations</h2>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words. Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 18
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "751dee7d-11eb-425e-b2eb-88e07dc36e26", ""), "html", null, true);
        echo " ";
        $context["component_variable_9885d7da_e396_4ca6_8914_6f73180676d4"] = ('' === $tmp = "bleed") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_738ff166_d764_446f_a77a_03071057af83"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_2ca18d8f_0b9e_44b8_8fef_99c38c204309"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1358639751', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if (twig_test_empty(twig_trim_filter(($context["dropZoneContent"] ?? null)))) {
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderInlineStyle("<style>Drop column type components here. { display: none; }</style>"));
        }
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 18, $this->source), ["0539f0ef-ec6e-47ec-8bcf-4cee995870d5" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("b95fd695", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 18, $this->source), ["9885d7da-e396-4ca6-8914-6f73180676d4" => "component_variable_9885d7da_e396_4ca6_8914_6f73180676d4", "738ff166-d764-446f-a77a-03071057af83" => "component_variable_738ff166_d764_446f_a77a_03071057af83", "2ca18d8f-0b9e-44b8-8fef-99c38c204309" => "component_variable_2ca18d8f_0b9e_44b8_8fef_99c38c204309"]), "2d14969d-7e49-4975-a593-21aad4753fd4", ""), "html", null, true);
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text"] = ('' === $tmp = "<p class=\"text-align-center\"><a href=\"/places\"><span class=\"coh-style-button-cta-cyan\">SEE ALL</span></a></p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 19
        echo " ";
        $context["component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c21160a7_b195_4602_b42b_51370d817df3"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("3fedc674", false, $this->sandbox->ensureToStringAllowed($context, 19, $this->source), ["6b671446-cb09-46cb-b84a-7366da00be36" => ["text" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_text", "textFormat" => "component_variable_6b671446_cb09_46cb_b84a_7366da00be36_textFormat"], "c21160a7-b195-4602-b42b-51370d817df3" => "component_variable_c21160a7_b195_4602_b42b_51370d817df3", "4c27d36c-a473-47ec-8d43-3b9696d45d74" => "component_variable_4c27d36c_a473_47ec_8d43_3b9696d45d74", "7607fd2d-3e4a-4a44-a9d9-999abc51ef08" => "component_variable_7607fd2d_3e4a_4a44_a9d9_999abc51ef08", "165f1de9-336c-42cc-bed2-28ef036ec7e3" => "component_variable_165f1de9_336c_42cc_bed2_28ef036ec7e3", "85f0b877-9764-4e8f-ac87-34948ad5f428" => "component_variable_85f0b877_9764_4e8f_ac87_34948ad5f428"], "94a8ae75-937a-44c4-b41f-4c2a15d1ec9c", ""), "html", null, true);
        echo " 
";
        // line 20
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 20, $this->source));
        }
    }

    // line 3
    public function block_block139114791($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_text"] = ('' === $tmp = "<h6 class=\"coh-style-sub-heading\">PRE HEADER</h6>

<h1>Contact Us</h1>

<p>The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.</p>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 8
        echo " ";
        $context["component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"] = ('' === $tmp = "cohesion") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a581345e_9290_4d1d_ac78_20b3ba547743"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741"] = ('' === $tmp = "coh-style-height--large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7"] = 8;
        echo " ";
        $context["component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f"] = 12;
        echo " ";
        $context["component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8"] = ('' === $tmp = "Center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd1d1cc_031f_438a_82fc_43edca962513"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84"] = 1;
        echo " ";
        $context["component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_fee69872_6425_4df2_a336_61768fe7c265"] = ('' === $tmp = "coh-style-link-button") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_86d5677f_86b4_4f30_845a_25636792b9a3"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_90226570_4c01_4971_8985_6564b065a63d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_dc3d74f2_e281_4c18_8689_1f266560111b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487"] = ('' === $tmp = "rgba(255, 255, 255, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_b7b4763e_bcb8_48ae_b571_68830beeb52f"] = ('' === $tmp = "rgba(0, 104, 125, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_hero", false, $this->sandbox->ensureToStringAllowed($context, 8, $this->source), ["ec518aee-3987-4edc-8630-c679120136af" => ["text" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_text", "textFormat" => "component_variable_ec518aee_3987_4edc_8630_c679120136af_textFormat"], "1ca08220-ccc9-4171-a2d3-993ea04fe1d0" => "component_variable_1ca08220_ccc9_4171_a2d3_993ea04fe1d0", "a581345e-9290-4d1d-ac78-20b3ba547743" => "component_variable_a581345e_9290_4d1d_ac78_20b3ba547743", "fe487eb0-8848-4d8d-9901-bb5cb64c4741" => "component_variable_fe487eb0_8848_4d8d_9901_bb5cb64c4741", "5311228f-f968-4346-bbe1-747dfde7b1f7" => "component_variable_5311228f_f968_4346_bbe1_747dfde7b1f7", "35d8f0ae-b2db-4f9d-941f-ce47958aae5f" => "component_variable_35d8f0ae_b2db_4f9d_941f_ce47958aae5f", "29ff2bde-d589-4eb3-a0a8-ddcc23fa5aa8" => "component_variable_29ff2bde_d589_4eb3_a0a8_ddcc23fa5aa8", "6bd1d1cc-031f-438a-82fc-43edca962513" => "component_variable_6bd1d1cc_031f_438a_82fc_43edca962513", "15bb3c39-f87e-4ace-a924-ae9ae1867c94" => "component_variable_15bb3c39_f87e_4ace_a924_ae9ae1867c94", "5502b4d7-a6bd-467a-993d-625ef4002d84" => "component_variable_5502b4d7_a6bd_467a_993d_625ef4002d84", "e330c7cb-1cb4-41a0-b3b0-ec95a9764b7d" => "component_variable_e330c7cb_1cb4_41a0_b3b0_ec95a9764b7d", "fee69872-6425-4df2-a336-61768fe7c265" => "component_variable_fee69872_6425_4df2_a336_61768fe7c265", "86d5677f-86b4-4f30-845a-25636792b9a3" => "component_variable_86d5677f_86b4_4f30_845a_25636792b9a3", "90226570-4c01-4971-8985-6564b065a63d" => "component_variable_90226570_4c01_4971_8985_6564b065a63d", "dc3d74f2-e281-4c18-8689-1f266560111b" => "component_variable_dc3d74f2_e281_4c18_8689_1f266560111b", "f30e5ad5-c3c7-44a3-bf47-882cb74da487" => "component_variable_f30e5ad5_c3c7_44a3_bf47_882cb74da487", "b7b4763e-bcb8-48ae-b571-68830beeb52f" => "component_variable_b7b4763e_bcb8_48ae_b571_68830beeb52f"], "ce1aa7f3-b399-43d1-a4ae-105c37d192f6", ""), "html", null, true);
        echo " ";
    }

    // line 15
    public function block_block3314285497($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35"] = ('' === $tmp = "retain") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da"] = ('' === $tmp = "coh-style-max-width---wide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_d29242f9_57b0_4002_841d_505458c3b21d"] = ('' === $tmp = "coh-style-padding-bottom---large") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3399655064', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 15, $this->source), ["694ba725-ae4c-4711-a676-e6351ea4e2bc" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_container", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 15, $this->source), ["2b28beb7-e16d-4e4d-bfaf-dddb4224de35" => "component_variable_2b28beb7_e16d_4e4d_bfaf_dddb4224de35", "c81d21c0-2a3c-4caa-9d91-342a9c5a94da" => "component_variable_c81d21c0_2a3c_4caa_9d91_342a9c5a94da", "d29242f9-57b0-4002-841d-505458c3b21d" => "component_variable_d29242f9_57b0_4002_841d_505458c3b21d"]), "df929755-3b61-4c62-9725-25db8e09dac9", ""), "html", null, true);
        echo " ";
    }

    public function block_block3399655064($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_webform_block", false, $this->sandbox->ensureToStringAllowed($context, 15, $this->source), [], "90a2fc62-65ae-48b3-a6f7-aee21f79b85e", ""), "html", null, true);
        echo " ";
    }

    // line 18
    public function block_block1358639751($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 505;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "23e56512-f2ec-49ba-8adb-b9781f9cd587", ""), "html", null, true);
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 505;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "3e408818-3618-4ce0-af5e-ca50c1476e10", ""), "html", null, true);
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 505;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "c945950b-1639-4707-bf71-58b28670b2dc", ""), "html", null, true);
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 505;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "d868fd7f-a340-4e07-ac05-fddd53cdb872", ""), "html", null, true);
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 505;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "5bff8d08-c632-47f2-838d-95c6534ee531", ""), "html", null, true);
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type"] = ('' === $tmp = "node") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode"] = ('' === $tmp = "card") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"] = 505;
        echo " ";
        $context["component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016"] = 4;
        echo " ";
        $context["component_variable_5235a75b_8ceb_4045_9015_843a7e08263a"] = 6;
        echo " ";
        $context["component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017"] = 12;
        echo " ";
        $context["component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14"] = ('' === $tmp = "coh-style-padding-top-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"] = ('' === $tmp = "coh-style-padding-left-right---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_entity_reference", false, $this->sandbox->ensureToStringAllowed($context, 18, $this->source), ["105267ab-7413-4358-a9d8-9ba7e27e6c6c" => ["entity_type" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity_type", "view_mode" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_view_mode", "entity" => "component_variable_105267ab_7413_4358_a9d8_9ba7e27e6c6c_entity"], "6fa2bc2a-132f-4be8-9106-ff508d2ff016" => "component_variable_6fa2bc2a_132f_4be8_9106_ff508d2ff016", "5235a75b-8ceb-4045-9015-843a7e08263a" => "component_variable_5235a75b_8ceb_4045_9015_843a7e08263a", "4a141bce-3f7f-46f9-a03c-8ef9b6e23017" => "component_variable_4a141bce_3f7f_46f9_a03c_8ef9b6e23017", "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14" => "component_variable_b3ce4d57_e1b5_4215_a6a1_2a2b6edd8c14", "9732c4d3-8460-4f67-827d-eca145d4ffff" => "component_variable_9732c4d3_8460_4f67_827d_eca145d4ffff"], "c8787c33-c06b-4980-97e4-c74d2256489b", ""), "html", null, true);
        echo " ";
    }

    public function getTemplateName()
    {
        return "__string_template__e7945bbe31166bfd4b29cb5ad70247dad17cf8495f858a78ed5fa383f17d3a05";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  344 => 18,  309 => 15,  264 => 8,  253 => 3,  247 => 20,  227 => 19,  180 => 18,  112 => 15,  92 => 8,  46 => 3,  43 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__e7945bbe31166bfd4b29cb5ad70247dad17cf8495f858a78ed5fa383f17d3a05", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 3, "if" => 8);
        static $filters = array("escape" => 3, "merge" => 8, "trim" => 18, "raw" => 18, "render" => 20);
        static $functions = array("attach_library" => 3, "processtoken" => 3, "renderComponent" => 8, "renderInlineStyle" => 18);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'merge', 'trim', 'raw', 'render'],
                ['attach_library', 'processtoken', 'renderComponent', 'renderInlineStyle']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
