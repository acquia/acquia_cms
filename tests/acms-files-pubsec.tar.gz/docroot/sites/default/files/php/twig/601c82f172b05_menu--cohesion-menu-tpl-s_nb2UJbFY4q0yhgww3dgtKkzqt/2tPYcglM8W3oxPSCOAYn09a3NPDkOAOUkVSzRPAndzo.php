<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* sites/default/files/cohesion/templates/menu--cohesion-menu-tpl-side-nav.html.twig */
class __TwigTemplate_6ac74902a2ec77a48d90701cf1950b641e036fe23d3cfc4eda64b6c3b355771d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " <nav class=\"coh-container coh-style-sidebar-nav coh-ce-d47157a4\" > ";
        if (( !twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) || (twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) && (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)) > 0)))) {
            echo " <ul class=\"coh-menu-list-container coh-unordered-list menu-level-1-ul coh-ce-5464d549\">";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(1, twig_length_filter($this->env, ($context["items"] ?? null))));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                $context["inRange"] = true;
                if ((($context["i"] <= twig_length_filter($this->env, ($context["items"] ?? null))) && ($context["inRange"] ?? null))) {
                    $context["item"] = (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = ($context["items"] ?? null)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4[(($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = twig_get_array_keys_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 3, $this->source))) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144[($context["i"] - 1)] ?? null) : null)] ?? null) : null);
                    $context["menuItemAttributes"] = $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getMenuItemAttributes($this->sandbox->ensureToStringAllowed((($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = ($context["item"] ?? null)) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b["original_link"] ?? null) : null), 3, $this->source));
                    echo "<li class=\"coh-menu-list-item coh-ce-61cbe9b2 js-coh-menu-item";
                    if ((((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "external", [], "any", false, false, true, 3) == false)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routed", [], "any", false, false, true, 3) == true)) && ($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("<current>") == $this->extensions['Drupal\Core\Template\TwigExtension']->getPath(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3), twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeParameters", [], "any", false, false, true, 3), twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "options", [], "any", false, false, true, 3))))) {
                        echo " is-active";
                    }
                    if ((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) && (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)) > 0))) {
                        echo " has-children";
                    }
                    if ((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "in_active_trail", [], "any", true, true, true, 3) && twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "in_active_trail", [], "any", false, false, true, 3))) {
                        echo " in-active-trail";
                    }
                    echo "\" data-coh-settings='{\"xl\":\"visible\"}' ";
                    if ((((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "external", [], "any", false, false, true, 3) == false)) && twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routed", [], "any", false, false, true, 3)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3) == "<front>"))) {
                        echo "data-drupal-link-system-path=\"";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                        echo "\"";
                    }
                    echo ">";
                    if (twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3)) {
                        $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = ["items" => twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)];
                        if (!twig_test_iterable($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002)) {
                            throw new RuntimeError('Variables passed to the "with" tag must be a hash.', 3, $this->getSourceContext());
                        }
                        $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = twig_to_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002);
                        $context['_parent'] = $context;
                        $context = $this->env->mergeGlobals(array_merge($context, $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002));
                        echo "<a href=\"";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                        echo "\"        ";
                        if (twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "target", [], "any", true, true, true, 3)) {
                            echo " target=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "target", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                            echo "\"";
                        }
                        echo " data-coh-settings='{ \"xl\":{\"link_interaction\":\"click-through-to-link\"},\"sm\":{\"link_interaction\":\"click-through-to-link\"} }' class=\"coh-link coh-ce-39a1ac35 js-coh-menu-item-link";
                        if (twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "class", [], "any", true, true, true, 3)) {
                            echo " ";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "class", [], "any", false, false, true, 3), 3, $this->source), " "), "html", null, true);
                        }
                        echo "\" ";
                        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, true, true, 3), "pluginDefinition", [], "any", false, true, true, 3), "description", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, false, true, 3), "pluginDefinition", [], "any", false, false, true, 3), "description", [], "any", false, false, true, 3) != ""))) {
                            echo " title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, false, true, 3), "pluginDefinition", [], "any", false, false, true, 3), "description", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                            echo "\"";
                        }
                        echo ">";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "title", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                        echo "</a> ";
                        if (( !twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) || (twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) && (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)) > 0)))) {
                            echo " <ul class=\"coh-menu-list-container coh-unordered-list menu-level-2-ul coh-ce-5161516a\">";
                            $context['_parent'] = $context;
                            $context['_seq'] = twig_ensure_traversable(range(1, twig_length_filter($this->env, ($context["items"] ?? null))));
                            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                                $context["inRange"] = true;
                                if ((($context["i"] <= twig_length_filter($this->env, ($context["items"] ?? null))) && ($context["inRange"] ?? null))) {
                                    $context["item"] = (($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = ($context["items"] ?? null)) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4[(($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 = twig_get_array_keys_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 3, $this->source))) && is_array($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666) || $__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 instanceof ArrayAccess ? ($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666[($context["i"] - 1)] ?? null) : null)] ?? null) : null);
                                    $context["menuItemAttributes"] = $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getMenuItemAttributes($this->sandbox->ensureToStringAllowed((($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e = ($context["item"] ?? null)) && is_array($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e) || $__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e instanceof ArrayAccess ? ($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e["original_link"] ?? null) : null), 3, $this->source));
                                    echo "<li class=\"coh-menu-list-item coh-ce-61cbe9b2 js-coh-menu-item";
                                    if ((((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "external", [], "any", false, false, true, 3) == false)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routed", [], "any", false, false, true, 3) == true)) && ($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("<current>") == $this->extensions['Drupal\Core\Template\TwigExtension']->getPath(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3), twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeParameters", [], "any", false, false, true, 3), twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "options", [], "any", false, false, true, 3))))) {
                                        echo " is-active";
                                    }
                                    if ((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) && (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)) > 0))) {
                                        echo " has-children";
                                    }
                                    if ((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "in_active_trail", [], "any", true, true, true, 3) && twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "in_active_trail", [], "any", false, false, true, 3))) {
                                        echo " in-active-trail";
                                    }
                                    echo "\" data-coh-settings='{\"xl\":\"visible\"}' ";
                                    if ((((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "external", [], "any", false, false, true, 3) == false)) && twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routed", [], "any", false, false, true, 3)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3) == "<front>"))) {
                                        echo "data-drupal-link-system-path=\"";
                                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                        echo "\"";
                                    }
                                    echo ">";
                                    if (twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3)) {
                                        $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = ["items" => twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)];
                                        if (!twig_test_iterable($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52)) {
                                            throw new RuntimeError('Variables passed to the "with" tag must be a hash.', 3, $this->getSourceContext());
                                        }
                                        $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = twig_to_array($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52);
                                        $context['_parent'] = $context;
                                        $context = $this->env->mergeGlobals(array_merge($context, $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52));
                                        echo "<a href=\"";
                                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                        echo "\"        ";
                                        if (twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "target", [], "any", true, true, true, 3)) {
                                            echo " target=\"";
                                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "target", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                            echo "\"";
                                        }
                                        echo " data-coh-settings='{ \"xl\":{\"link_interaction\":\"click-through-to-link\"},\"xs\":{\"link_interaction\":\"click-through-to-link\"} }' class=\"coh-link js-coh-menu-item-link";
                                        if (twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "class", [], "any", true, true, true, 3)) {
                                            echo " ";
                                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "class", [], "any", false, false, true, 3), 3, $this->source), " "), "html", null, true);
                                        }
                                        echo "\" ";
                                        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, true, true, 3), "pluginDefinition", [], "any", false, true, true, 3), "description", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, false, true, 3), "pluginDefinition", [], "any", false, false, true, 3), "description", [], "any", false, false, true, 3) != ""))) {
                                            echo " title=\"";
                                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, false, true, 3), "pluginDefinition", [], "any", false, false, true, 3), "description", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                            echo "\"";
                                        }
                                        echo ">";
                                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "title", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                        echo "</a> ";
                                        if (( !twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) || (twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) && (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)) > 0)))) {
                                            echo " <ul class=\"coh-menu-list-container coh-unordered-list menu-level-2-ul coh-ce-5161516a\">";
                                            $context['_parent'] = $context;
                                            $context['_seq'] = twig_ensure_traversable(range(1, twig_length_filter($this->env, ($context["items"] ?? null))));
                                            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                                                $context["inRange"] = true;
                                                if ((($context["i"] <= twig_length_filter($this->env, ($context["items"] ?? null))) && ($context["inRange"] ?? null))) {
                                                    $context["item"] = (($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 = ($context["items"] ?? null)) && is_array($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136) || $__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 instanceof ArrayAccess ? ($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136[(($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 = twig_get_array_keys_filter($this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 3, $this->source))) && is_array($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386) || $__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 instanceof ArrayAccess ? ($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386[($context["i"] - 1)] ?? null) : null)] ?? null) : null);
                                                    $context["menuItemAttributes"] = $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getMenuItemAttributes($this->sandbox->ensureToStringAllowed((($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 = ($context["item"] ?? null)) && is_array($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9) || $__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 instanceof ArrayAccess ? ($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9["original_link"] ?? null) : null), 3, $this->source));
                                                    echo "<li class=\"coh-menu-list-item coh-ce-61cbe9b2 js-coh-menu-item";
                                                    if ((((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "external", [], "any", false, false, true, 3) == false)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routed", [], "any", false, false, true, 3) == true)) && ($this->extensions['Drupal\Core\Template\TwigExtension']->getPath("<current>") == $this->extensions['Drupal\Core\Template\TwigExtension']->getPath(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3), twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeParameters", [], "any", false, false, true, 3), twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "options", [], "any", false, false, true, 3))))) {
                                                        echo " is-active";
                                                    }
                                                    if ((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3) && (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)) > 0))) {
                                                        echo " has-children";
                                                    }
                                                    if ((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "in_active_trail", [], "any", true, true, true, 3) && twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "in_active_trail", [], "any", false, false, true, 3))) {
                                                        echo " in-active-trail";
                                                    }
                                                    echo "\" data-coh-settings='{\"xl\":\"visible\"}' ";
                                                    if ((((twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "external", [], "any", false, false, true, 3) == false)) && twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routed", [], "any", false, false, true, 3)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3) == "<front>"))) {
                                                        echo "data-drupal-link-system-path=\"";
                                                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), "routeName", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                                        echo "\"";
                                                    }
                                                    echo ">";
                                                    if (twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", true, true, true, 3)) {
                                                        $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae = ["items" => twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 3)];
                                                        if (!twig_test_iterable($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae)) {
                                                            throw new RuntimeError('Variables passed to the "with" tag must be a hash.', 3, $this->getSourceContext());
                                                        }
                                                        $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae = twig_to_array($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae);
                                                        $context['_parent'] = $context;
                                                        $context = $this->env->mergeGlobals(array_merge($context, $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae));
                                                        echo "<a href=\"";
                                                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                                        echo "\"        ";
                                                        if (twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "target", [], "any", true, true, true, 3)) {
                                                            echo " target=\"";
                                                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "target", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                                            echo "\"";
                                                        }
                                                        echo " data-coh-settings='{ \"xl\":{\"link_interaction\":\"click-through-to-link\"},\"xs\":{\"link_interaction\":\"click-through-to-link\"} }' class=\"coh-link js-coh-menu-item-link";
                                                        if (twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "class", [], "any", true, true, true, 3)) {
                                                            echo " ";
                                                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["menuItemAttributes"] ?? null), "class", [], "any", false, false, true, 3), 3, $this->source), " "), "html", null, true);
                                                        }
                                                        echo "\" ";
                                                        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, true, true, 3), "pluginDefinition", [], "any", false, true, true, 3), "description", [], "any", true, true, true, 3) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, false, true, 3), "pluginDefinition", [], "any", false, false, true, 3), "description", [], "any", false, false, true, 3) != ""))) {
                                                            echo " title=\"";
                                                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "original_link", [], "any", false, false, true, 3), "pluginDefinition", [], "any", false, false, true, 3), "description", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                                            echo "\"";
                                                        }
                                                        echo ">";
                                                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["item"] ?? null), "title", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
                                                        echo "</a>";
                                                        $context = $context['_parent'];
                                                    }
                                                    echo "</li>";
                                                }
                                            }
                                            $_parent = $context['_parent'];
                                            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
                                            $context = array_intersect_key($context, $_parent) + $_parent;
                                            echo "</ul> ";
                                        }
                                        $context = $context['_parent'];
                                    }
                                    echo "</li>";
                                }
                            }
                            $_parent = $context['_parent'];
                            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
                            $context = array_intersect_key($context, $_parent) + $_parent;
                            echo "</ul> ";
                        }
                        $context = $context['_parent'];
                    }
                    echo "</li>";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</ul> ";
        }
        echo " </nav> 
";
        // line 4
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 4, $this->source));
        }
    }

    public function getTemplateName()
    {
        return "sites/default/files/cohesion/templates/menu--cohesion-menu-tpl-side-nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  255 => 4,  42 => 3,  39 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "sites/default/files/cohesion/templates/menu--cohesion-menu-tpl-side-nav.html.twig", "/Users/kdruckman/Sites/acquia_cms/docroot/sites/default/files/cohesion/templates/menu--cohesion-menu-tpl-side-nav.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 3, "for" => 3, "set" => 3, "with" => 3);
        static $filters = array("escape" => 3, "length" => 3, "keys" => 3, "join" => 3, "render" => 4);
        static $functions = array("attach_library" => 3, "range" => 3, "get_menu_item_attributes" => 3, "path" => 3);

        try {
            $this->sandbox->checkSecurity(
                ['if', 'for', 'set', 'with'],
                ['escape', 'length', 'keys', 'join', 'render'],
                ['attach_library', 'range', 'get_menu_item_attributes', 'path']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
