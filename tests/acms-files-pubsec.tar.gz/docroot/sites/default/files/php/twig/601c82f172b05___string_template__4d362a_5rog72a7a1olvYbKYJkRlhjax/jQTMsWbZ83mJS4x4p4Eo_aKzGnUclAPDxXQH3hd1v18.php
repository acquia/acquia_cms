<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__4d362aa40e2eb7bab9d8dd38c1390ff60b099d52798b41c9cbc37a2b3b2cf1cb */
class __TwigTemplate_41c0f51dca6838cc233b0471b40b0896f83d89700ca3a7513803162f8ad585ad extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block1486064192' => [$this, 'block_block1486064192'],
            'block3103140194' => [$this, 'block_block3103140194'],
            'block4254777289' => [$this, 'block_block4254777289'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = ('' === $tmp = "20px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = "coh-style-padding-bottom---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = true;
        echo " ";
        $context["component_variable_028cf87b_ada9_4c88_880d_7dd19de841bd"] = 0;
        echo " ";
        $context["component_variable_301ad76b_785d_4615_af93_ce27b0968b26"] = 1;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1486064192', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "028cf87b-ada9-4c88-880d-7dd19de841bd" => "component_variable_028cf87b_ada9_4c88_880d_7dd19de841bd", "301ad76b-785d-4615-af93-ce27b0968b26" => "component_variable_301ad76b_785d_4615_af93_ce27b0968b26"]), "ed9f5897-b751-490e-9273-51c1be78f243", ""), "html", null, true);
        echo " 
";
        // line 4
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 4, $this->source));
        }
    }

    // line 3
    public function block_block1486064192($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_593842fb_7f78_4e90_955d_bebe642a3808"] = false;
        echo " ";
        $context["component_variable_2d39f7ae_3f75_45bc_8c91_ed0907b6b499"] = ('' === $tmp = "h1") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f526db5b_c574_42b2_b463_72b391b1fbd0"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8c714c57_bc87_48a9_b5d7_528fb4a01464"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_724bd0ae_c245_48b0_b08e_dd80bce6f825"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_43204cc1_bf5c_4729_aebe_8be328824868"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_ff9f716c_ee36_4813_80f4_1f924010206b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8c0355b9_edb1_4ab5_8c81_8438e6c564cf"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_8f48ee6a_a11c_4981_a464_31ff2f8d3875"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_81375114_da17_4d48_bcd5_ddceecbe7ff7"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5cc53e52_bf48_4645_a52c_a18b4c30c503"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_55af0c22_0b6c_4718_952b_5ef535dd9de7"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1d587270_08d8_45ea_b6a7_4d69a2fd213b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a66ecc62_f679_48cd_9c08_89d3dcd20f7d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6674b76b_380b_4762_b054_3258e0f4c14c"] = ('' === $tmp = "Style Guide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_title", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), ["593842fb-7f78-4e90-955d-bebe642a3808" => "component_variable_593842fb_7f78_4e90_955d_bebe642a3808", "2d39f7ae-3f75-45bc-8c91-ed0907b6b499" => "component_variable_2d39f7ae_3f75_45bc_8c91_ed0907b6b499", "f526db5b-c574-42b2-b463-72b391b1fbd0" => "component_variable_f526db5b_c574_42b2_b463_72b391b1fbd0", "8c714c57-bc87-48a9-b5d7-528fb4a01464" => "component_variable_8c714c57_bc87_48a9_b5d7_528fb4a01464", "724bd0ae-c245-48b0-b08e-dd80bce6f825" => "component_variable_724bd0ae_c245_48b0_b08e_dd80bce6f825", "43204cc1-bf5c-4729-aebe-8be328824868" => "component_variable_43204cc1_bf5c_4729_aebe_8be328824868", "ff9f716c-ee36-4813-80f4-1f924010206b" => "component_variable_ff9f716c_ee36_4813_80f4_1f924010206b", "8c0355b9-edb1-4ab5-8c81-8438e6c564cf" => "component_variable_8c0355b9_edb1_4ab5_8c81_8438e6c564cf", "8f48ee6a-a11c-4981-a464-31ff2f8d3875" => "component_variable_8f48ee6a_a11c_4981_a464_31ff2f8d3875", "81375114-da17-4d48-bcd5-ddceecbe7ff7" => "component_variable_81375114_da17_4d48_bcd5_ddceecbe7ff7", "5cc53e52-bf48-4645-a52c-a18b4c30c503" => "component_variable_5cc53e52_bf48_4645_a52c_a18b4c30c503", "55af0c22-0b6c-4718-952b-5ef535dd9de7" => "component_variable_55af0c22_0b6c_4718_952b_5ef535dd9de7", "1d587270-08d8-45ea-b6a7-4d69a2fd213b" => "component_variable_1d587270_08d8_45ea_b6a7_4d69a2fd213b", "a66ecc62-f679-48cd-9c08-89d3dcd20f7d" => "component_variable_a66ecc62_f679_48cd_9c08_89d3dcd20f7d", "6674b76b-380b-4762-b054-3258e0f4c14c" => "component_variable_6674b76b_380b_4762_b054_3258e0f4c14c"], "76591da5-cd37-47ab-b886-4060377968c1", ""), "html", null, true);
        echo " ";
        $context["component_variable_10cd46b8_1502_452a_b22f_e80bddd24ab8"] = 3;
        echo " ";
        $context["component_variable_041ca18b_df20_43ce_80ad_0263fe15e758"] = 9;
        echo " ";
        $context["component_variable_df38c02f_b799_425f_b11c_0958132250c4"] = 3;
        echo " ";
        $context["component_variable_a8f0de15_676c_438a_b44e_f36607505b27"] = 9;
        echo " ";
        $context["component_variable_48c7581b_1324_4e6d_92a5_dd79448655f4"] = 12;
        echo " ";
        $context["component_variable_1b0a4239_454f_40d4_91fa_a0331cf3d982"] = 12;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3103140194', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["4ad09ba3-58dc-463b-89fe-dc965c34a8d9" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block4254777289', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["203f5b74-68fb-45f6-a740-4025c2edb231" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_two_column", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["10cd46b8-1502-452a-b22f-e80bddd24ab8" => "component_variable_10cd46b8_1502_452a_b22f_e80bddd24ab8", "041ca18b-df20-43ce-80ad-0263fe15e758" => "component_variable_041ca18b_df20_43ce_80ad_0263fe15e758", "df38c02f-b799-425f-b11c-0958132250c4" => "component_variable_df38c02f_b799_425f_b11c_0958132250c4", "a8f0de15-676c-438a-b44e-f36607505b27" => "component_variable_a8f0de15_676c_438a_b44e_f36607505b27", "48c7581b-1324-4e6d-92a5-dd79448655f4" => "component_variable_48c7581b_1324_4e6d_92a5_dd79448655f4", "1b0a4239-454f-40d4-91fa-a0331cf3d982" => "component_variable_1b0a4239_454f_40d4_91fa_a0331cf3d982"]), "8a3408da-e470-4736-a22a-0cae45b14406", ""), "html", null, true);
        echo " ";
    }

    public function block_block3103140194($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_sidebar_nav", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), [], "74622200-5538-4dcd-a5c9-49aa0945c89b", ""), "html", null, true);
        echo " ";
    }

    public function block_block4254777289($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " <h2 class=\"coh-heading coh-ce-5f7ae699\"> Project Card </h2> ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:media:b64ab3e9-01e2-4adc-b514-e54eb085e3c1]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 3, $this->source), false), "html", null, true);
        $context["component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f758f4c9_9588_4610_87f4_4f02423c0120"] = ('' === $tmp = "Pre heading") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_03322899_56e0_401a_8ab7_730c5b569f6f"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f"] = ('' === $tmp = "https://www.acquia.com") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249"] = 12;
        echo " ";
        $context["component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870"] = 12;
        echo " ";
        $context["component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114"] = 12;
        echo " ";
        $context["component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_73c42747_0483_45df_8254_6dab03362d07"] = ('' === $tmp = "rgba(0, 0, 0, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5"] = ('' === $tmp = "rgba(40, 169, 224, 1)") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662"] = 0;
        echo " ";
        $context["component_variable_341764d1_4b77_46a1_b86b_be128856b272"] = 1;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("project_card", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), ["5ecad84c-1903-402f-9d1b-a8c5b8d8a098" => "component_variable_5ecad84c_1903_402f_9d1b_a8c5b8d8a098", "58c369ea-4a48-4ee4-aca4-9072ce0af7c5" => "component_variable_58c369ea_4a48_4ee4_aca4_9072ce0af7c5", "f758f4c9-9588-4610-87f4-4f02423c0120" => "component_variable_f758f4c9_9588_4610_87f4_4f02423c0120", "03322899-56e0-401a-8ab7-730c5b569f6f" => "component_variable_03322899_56e0_401a_8ab7_730c5b569f6f", "78bb4f3d-45b5-4fc6-9167-3d9ed0fa029f" => "component_variable_78bb4f3d_45b5_4fc6_9167_3d9ed0fa029f", "e7947ab1-db62-4e57-b3ec-1eda5d7d7249" => "component_variable_e7947ab1_db62_4e57_b3ec_1eda5d7d7249", "d56a1803-c41f-4c6e-890f-9aadbbc69870" => "component_variable_d56a1803_c41f_4c6e_890f_9aadbbc69870", "ff1f20ef-f2b7-4c07-a491-55af03245114" => "component_variable_ff1f20ef_f2b7_4c07_a491_55af03245114", "daabd3ea-ef42-4be9-a492-9433da0df78e" => "component_variable_daabd3ea_ef42_4be9_a492_9433da0df78e", "73c42747-0483-45df-8254-6dab03362d07" => "component_variable_73c42747_0483_45df_8254_6dab03362d07", "74bef303-fa50-4e26-990d-23a8fd1ca8b5" => "component_variable_74bef303_fa50_4e26_990d_23a8fd1ca8b5", "28cc9630-243d-4f5d-9521-090cf6e4f662" => "component_variable_28cc9630_243d_4f5d_9521_090cf6e4f662", "341764d1-4b77-46a1-b86b-be128856b272" => "component_variable_341764d1_4b77_46a1_b86b_be128856b272"], "cef451f8-4552-412f-a51e-6c6192ec8904", ""), "html", null, true);
        echo " ";
    }

    public function getTemplateName()
    {
        return "__string_template__4d362aa40e2eb7bab9d8dd38c1390ff60b099d52798b41c9cbc37a2b3b2cf1cb";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 3,  110 => 4,  45 => 3,  42 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__4d362aa40e2eb7bab9d8dd38c1390ff60b099d52798b41c9cbc37a2b3b2cf1cb", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 3, "if" => 3);
        static $filters = array("escape" => 3, "merge" => 3, "render" => 4);
        static $functions = array("attach_library" => 3, "renderComponent" => 3, "processtoken" => 3);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'merge', 'render'],
                ['attach_library', 'renderComponent', 'processtoken']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
