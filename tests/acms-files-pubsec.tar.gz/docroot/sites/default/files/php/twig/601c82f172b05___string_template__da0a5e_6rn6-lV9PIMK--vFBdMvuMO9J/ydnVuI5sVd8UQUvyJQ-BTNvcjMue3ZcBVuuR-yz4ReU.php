<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__da0a5efb00e1d11a470eec46583bc563f1548e0b7f69ef81d8697ca6d4dce455 */
class __TwigTemplate_034d6a138c3e5b2abe082523d7b28688bb1fe9e512451319d57f021422df2759 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'block487463507' => [$this, 'block_block487463507'],
            'block3798831677' => [$this, 'block_block3798831677'],
            'block3753999621' => [$this, 'block_block3753999621'],
            'block2875510585' => [$this, 'block_block2875510585'],
            'block1431196562' => [$this, 'block_block1431196562'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0d534562_e619_4eaa_9490_cb024b552930"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b"] = ('' === $tmp = "auto") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_933b8d97_ab50_494e_baec_eb8d733ca385"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6880626d_57df_49eb_9212_fb43231ce51c"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_a501d536_f42f_474f_a866_7a4b01d9494a"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33"] = ('' === $tmp = "center") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d"] = ('' === $tmp = "coh-style-padding---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70"] = ('' === $tmp = "20px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_97212711_6b24_4f8c_918c_f61599c9b42b"] = 0;
        echo " ";
        $context["component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44"] = ('' === $tmp = "coh-style-padding-bottom---medium") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371"] = true;
        echo " ";
        $context["component_variable_028cf87b_ada9_4c88_880d_7dd19de841bd"] = 0;
        echo " ";
        $context["component_variable_301ad76b_785d_4615_af93_ce27b0968b26"] = 1;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block487463507', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["ae0e0859-e597-4acd-a0ad-7e63526b4624" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("316b920d", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["48678110-97bf-4d83-9e51-f6da6ca57d5d" => "component_variable_48678110_97bf_4d83_9e51_f6da6ca57d5d", "3df021b2-3541-47b9-afb4-140ba9ac93b4" => "component_variable_3df021b2_3541_47b9_afb4_140ba9ac93b4", "0d534562-e619-4eaa-9490-cb024b552930" => "component_variable_0d534562_e619_4eaa_9490_cb024b552930", "90d5bce3-05f1-459d-b38d-5c64b7fa8c1b" => "component_variable_90d5bce3_05f1_459d_b38d_5c64b7fa8c1b", "a4303ec9-6dd6-4704-ab90-93b31448da49" => "component_variable_a4303ec9_6dd6_4704_ab90_93b31448da49", "4c5b3681-938c-4edc-be29-00d9f0de0e35" => "component_variable_4c5b3681_938c_4edc_be29_00d9f0de0e35", "933b8d97-ab50-494e-baec-eb8d733ca385" => "component_variable_933b8d97_ab50_494e_baec_eb8d733ca385", "6880626d-57df-49eb-9212-fb43231ce51c" => "component_variable_6880626d_57df_49eb_9212_fb43231ce51c", "030c9f3a-e75f-4900-ae69-c4492eaadc08" => "component_variable_030c9f3a_e75f_4900_ae69_c4492eaadc08", "a501d536-f42f-474f-a866-7a4b01d9494a" => "component_variable_a501d536_f42f_474f_a866_7a4b01d9494a", "10c8566a-18cd-4d55-9dcb-71389a3f8e33" => "component_variable_10c8566a_18cd_4d55_9dcb_71389a3f8e33", "c5f15640-a350-4d59-94f9-f6b39408ad2d" => "component_variable_c5f15640_a350_4d59_94f9_f6b39408ad2d", "79f871d3-21ca-4bfd-83b9-0cf073c60e70" => "component_variable_79f871d3_21ca_4bfd_83b9_0cf073c60e70", "97212711-6b24-4f8c-918c-f61599c9b42b" => "component_variable_97212711_6b24_4f8c_918c_f61599c9b42b", "95b63b8f-f4af-42c2-97ae-c09517d6ca44" => "component_variable_95b63b8f_f4af_42c2_97ae_c09517d6ca44", "6bd34f95-d8e4-4b68-8708-35ec046a5371" => "component_variable_6bd34f95_d8e4_4b68_8708_35ec046a5371", "028cf87b-ada9-4c88-880d-7dd19de841bd" => "component_variable_028cf87b_ada9_4c88_880d_7dd19de841bd", "301ad76b-785d-4615-af93-ce27b0968b26" => "component_variable_301ad76b_785d_4615_af93_ce27b0968b26"]), "22e435c7-789e-4755-8b0d-ce06d09ed362", ""), "html", null, true);
        echo " 
";
        // line 4
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 4, $this->source));
        }
    }

    // line 3
    public function block_block487463507($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_593842fb_7f78_4e90_955d_bebe642a3808"] = false;
        echo " ";
        $context["component_variable_2d39f7ae_3f75_45bc_8c91_ed0907b6b499"] = ('' === $tmp = "h1") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_f526db5b_c574_42b2_b463_72b391b1fbd0"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8c714c57_bc87_48a9_b5d7_528fb4a01464"] = ('' === $tmp = "coh-style-margin-bottom---small") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_724bd0ae_c245_48b0_b08e_dd80bce6f825"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_43204cc1_bf5c_4729_aebe_8be328824868"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_ff9f716c_ee36_4813_80f4_1f924010206b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8c0355b9_edb1_4ab5_8c81_8438e6c564cf"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_8f48ee6a_a11c_4981_a464_31ff2f8d3875"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_81375114_da17_4d48_bcd5_ddceecbe7ff7"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5cc53e52_bf48_4645_a52c_a18b4c30c503"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_55af0c22_0b6c_4718_952b_5ef535dd9de7"] = ('' === $tmp = "24px") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_1d587270_08d8_45ea_b6a7_4d69a2fd213b"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        $context["component_variable_a66ecc62_f679_48cd_9c08_89d3dcd20f7d"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6674b76b_380b_4762_b054_3258e0f4c14c"] = ('' === $tmp = "Style Guide") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_title", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), ["593842fb-7f78-4e90-955d-bebe642a3808" => "component_variable_593842fb_7f78_4e90_955d_bebe642a3808", "2d39f7ae-3f75-45bc-8c91-ed0907b6b499" => "component_variable_2d39f7ae_3f75_45bc_8c91_ed0907b6b499", "f526db5b-c574-42b2-b463-72b391b1fbd0" => "component_variable_f526db5b_c574_42b2_b463_72b391b1fbd0", "8c714c57-bc87-48a9-b5d7-528fb4a01464" => "component_variable_8c714c57_bc87_48a9_b5d7_528fb4a01464", "724bd0ae-c245-48b0-b08e-dd80bce6f825" => "component_variable_724bd0ae_c245_48b0_b08e_dd80bce6f825", "43204cc1-bf5c-4729-aebe-8be328824868" => "component_variable_43204cc1_bf5c_4729_aebe_8be328824868", "ff9f716c-ee36-4813-80f4-1f924010206b" => "component_variable_ff9f716c_ee36_4813_80f4_1f924010206b", "8c0355b9-edb1-4ab5-8c81-8438e6c564cf" => "component_variable_8c0355b9_edb1_4ab5_8c81_8438e6c564cf", "8f48ee6a-a11c-4981-a464-31ff2f8d3875" => "component_variable_8f48ee6a_a11c_4981_a464_31ff2f8d3875", "81375114-da17-4d48-bcd5-ddceecbe7ff7" => "component_variable_81375114_da17_4d48_bcd5_ddceecbe7ff7", "5cc53e52-bf48-4645-a52c-a18b4c30c503" => "component_variable_5cc53e52_bf48_4645_a52c_a18b4c30c503", "55af0c22-0b6c-4718-952b-5ef535dd9de7" => "component_variable_55af0c22_0b6c_4718_952b_5ef535dd9de7", "1d587270-08d8-45ea-b6a7-4d69a2fd213b" => "component_variable_1d587270_08d8_45ea_b6a7_4d69a2fd213b", "a66ecc62-f679-48cd-9c08-89d3dcd20f7d" => "component_variable_a66ecc62_f679_48cd_9c08_89d3dcd20f7d", "6674b76b-380b-4762-b054-3258e0f4c14c" => "component_variable_6674b76b_380b_4762_b054_3258e0f4c14c"], "2d2cb40c-7913-45d5-949a-1f74740b6e57", ""), "html", null, true);
        echo " ";
        $context["component_variable_10cd46b8_1502_452a_b22f_e80bddd24ab8"] = 3;
        echo " ";
        $context["component_variable_041ca18b_df20_43ce_80ad_0263fe15e758"] = 9;
        echo " ";
        $context["component_variable_df38c02f_b799_425f_b11c_0958132250c4"] = 3;
        echo " ";
        $context["component_variable_a8f0de15_676c_438a_b44e_f36607505b27"] = 9;
        echo " ";
        $context["component_variable_48c7581b_1324_4e6d_92a5_dd79448655f4"] = 12;
        echo " ";
        $context["component_variable_1b0a4239_454f_40d4_91fa_a0331cf3d982"] = 12;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3798831677', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["4ad09ba3-58dc-463b-89fe-dc965c34a8d9" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block3753999621', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["203f5b74-68fb-45f6-a740-4025c2edb231" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_two_column", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["10cd46b8-1502-452a-b22f-e80bddd24ab8" => "component_variable_10cd46b8_1502_452a_b22f_e80bddd24ab8", "041ca18b-df20-43ce-80ad-0263fe15e758" => "component_variable_041ca18b_df20_43ce_80ad_0263fe15e758", "df38c02f-b799-425f-b11c-0958132250c4" => "component_variable_df38c02f_b799_425f_b11c_0958132250c4", "a8f0de15-676c-438a-b44e-f36607505b27" => "component_variable_a8f0de15_676c_438a_b44e_f36607505b27", "48c7581b-1324-4e6d-92a5-dd79448655f4" => "component_variable_48c7581b_1324_4e6d_92a5_dd79448655f4", "1b0a4239-454f-40d4-91fa-a0331cf3d982" => "component_variable_1b0a4239_454f_40d4_91fa_a0331cf3d982"]), "a5ef79c6-4761-49e5-8a69-30f6a9fdffce", ""), "html", null, true);
        echo " ";
    }

    public function block_block3798831677($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_sidebar_nav", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), [], "21670870-d651-455a-b0e0-4cf002cab490", ""), "html", null, true);
        echo " ";
    }

    public function block_block3753999621($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " ";
        $context["component_variable_10cd46b8_1502_452a_b22f_e80bddd24ab8"] = 6;
        echo " ";
        $context["component_variable_041ca18b_df20_43ce_80ad_0263fe15e758"] = 6;
        echo " ";
        $context["component_variable_df38c02f_b799_425f_b11c_0958132250c4"] = 6;
        echo " ";
        $context["component_variable_a8f0de15_676c_438a_b44e_f36607505b27"] = 6;
        echo " ";
        $context["component_variable_48c7581b_1324_4e6d_92a5_dd79448655f4"] = 12;
        echo " ";
        $context["component_variable_1b0a4239_454f_40d4_91fa_a0331cf3d982"] = 12;
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block2875510585', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["4ad09ba3-58dc-463b-89fe-dc965c34a8d9" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        ob_start(function () { return ''; });
        echo " ";
        $this->displayBlock('block1431196562', $context, $blocks);
        echo " ";
        $context["dropZoneContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        if ( !(isset($context["dropZones"]) || array_key_exists("dropZones", $context))) {
            $context["dropZones"] = [];
        }
        echo " ";
        $context["dropZones"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["203f5b74-68fb-45f6-a740-4025c2edb231" => ($context["dropZoneContent"] ?? null)]);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_two_column", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), twig_array_merge($this->sandbox->ensureToStringAllowed(($context["dropZones"] ?? null), 3, $this->source), ["10cd46b8-1502-452a-b22f-e80bddd24ab8" => "component_variable_10cd46b8_1502_452a_b22f_e80bddd24ab8", "041ca18b-df20-43ce-80ad-0263fe15e758" => "component_variable_041ca18b_df20_43ce_80ad_0263fe15e758", "df38c02f-b799-425f-b11c-0958132250c4" => "component_variable_df38c02f_b799_425f_b11c_0958132250c4", "a8f0de15-676c-438a-b44e-f36607505b27" => "component_variable_a8f0de15_676c_438a_b44e_f36607505b27", "48c7581b-1324-4e6d-92a5-dd79448655f4" => "component_variable_48c7581b_1324_4e6d_92a5_dd79448655f4", "1b0a4239-454f-40d4-91fa-a0331cf3d982" => "component_variable_1b0a4239_454f_40d4_91fa_a0331cf3d982"]), "fe2d7e30-ab1f-41ef-a38a-7ebbdded8bd2", ""), "html", null, true);
        echo " ";
    }

    public function block_block2875510585($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " <h2 class=\"coh-heading coh-ce-5f7ae699\"> Card - Horizontal (16:9) </h2> ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:58abfcde-c65e-4974-a445-65ceaa6def7b]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 3, $this->source), false), "html", null, true);
        $context["component_variable_fc654977_5646_45bd_a79c_073557e0c635"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_e5440168_e710_4c61_a372_9486271539eb"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4"] = ('' === $tmp = "The European languages are members of the same family.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4"] = ('' === $tmp = "Read More") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_c9379808_05b5_40eb_9669_186474d82483"] =  -2;
        echo " ";
        $context["component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db"] =  -2;
        echo " ";
        $context["component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20"] =  -2;
        echo " ";
        $context["component_variable_4b467c3b_b26d_49c6_9116_311a669a049c"] = true;
        echo " ";
        $context["component_variable_558e8243_29d2_4a3d_8d5c_509101e76414"] = true;
        echo " ";
        $context["component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1"] = false;
        echo " ";
        $context["component_variable_a968d804_8518_4fb9_969e_06a5504d3284"] = false;
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_horizontal_16_9", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), ["fc654977-5646-45bd-a79c-073557e0c635" => "component_variable_fc654977_5646_45bd_a79c_073557e0c635", "e5440168-e710-4c61-a372-9486271539eb" => "component_variable_e5440168_e710_4c61_a372_9486271539eb", "0150e186-1886-491c-8eeb-3eff0d1ea201" => "component_variable_0150e186_1886_491c_8eeb_3eff0d1ea201", "c25990a1-9edb-47ed-ae4d-673395f9457b" => "component_variable_c25990a1_9edb_47ed_ae4d_673395f9457b", "5d1fad68-87b6-4a97-995f-a2b99334c0d4" => "component_variable_5d1fad68_87b6_4a97_995f_a2b99334c0d4", "39207af3-9cab-4489-ac19-4ea160ab81b4" => "component_variable_39207af3_9cab_4489_ac19_4ea160ab81b4", "c9379808-05b5-40eb-9669-186474d82483" => "component_variable_c9379808_05b5_40eb_9669_186474d82483", "e620b539-d2f4-4cad-b11e-ed1aceb063db" => "component_variable_e620b539_d2f4_4cad_b11e_ed1aceb063db", "46a89c29-8d1c-431c-b508-6716f7e3ab20" => "component_variable_46a89c29_8d1c_431c_b508_6716f7e3ab20", "4b467c3b-b26d-49c6-9116-311a669a049c" => "component_variable_4b467c3b_b26d_49c6_9116_311a669a049c", "558e8243-29d2-4a3d-8d5c-509101e76414" => "component_variable_558e8243_29d2_4a3d_8d5c_509101e76414", "a384f576-0ed0-427c-b9b5-3a4df20fbff1" => "component_variable_a384f576_0ed0_427c_b9b5_3a4df20fbff1", "a968d804-8518-4fb9-969e-06a5504d3284" => "component_variable_a968d804_8518_4fb9_969e_06a5504d3284"], "5703501e-9ad3-457d-b77b-30dde1c7700a", ""), "html", null, true);
        echo " ";
    }

    public function block_block1431196562($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo " <h2 class=\"coh-heading coh-ce-5f7ae699\"> Card - Horizontal (Portrait) </h2> ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->tokenReplace("[media-reference:file:58abfcde-c65e-4974-a445-65ceaa6def7b]", ["media-reference" => ($context["media_reference"] ?? null)], $this->sandbox->ensureToStringAllowed($context, 3, $this->source), false), "html", null, true);
        $context["component_variable_6bd8d936_44b3_4db6_b72a_0dfc0775de4e"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_557e363d_340b_45a6_be7e_d2651550ceef"] = ('' === $tmp = "Placeholder") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_21a57b13_1cc9_4172_b19c_e85717865527"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_8e474351_2291_40d7_9ebd_4c7a7e76247e"] = ('' === $tmp = "Short headline") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_f060e5bd_3315_4ef8_ad33_1873855e2936"] = ('' === $tmp = "The European languages are members of the same family.") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6143fa18_4b90_4453_8849_0abd1da998ee"] = ('' === $tmp = "Read More") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        $context["component_variable_6a18dfe7_6b3b_4a81_b1b3_79c15cc4a280"] =  -2;
        echo " ";
        $context["component_variable_7c1a369f_34cd_4932_86bc_980de5b8e13f"] =  -2;
        echo " ";
        $context["component_variable_e5ce6718_ac91_489a_8c30_2d1d975f1872"] =  -2;
        echo " ";
        $context["component_variable_d7499742_0c78_4c75_86d6_3eef9e11258c"] = true;
        echo " ";
        $context["component_variable_e60ac45d_9fb8_4b42_b870_e74d553872a0"] = true;
        echo " ";
        $context["component_variable_ab8e8da6_fdd9_46d2_8f15_173c2834df80"] = false;
        echo " ";
        $context["component_variable_ce7d08f1_9e65_47da_88c9_e022205891b9"] = false;
        echo " ";
        $context["component_variable_66278b23_5ce3_4799_beb0_2f9d3bb19ce2"] = ('' === $tmp = "coh-style-container-theme---light-1") ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderComponent("cpt_card_horizontal_portrait", false, $this->sandbox->ensureToStringAllowed($context, 3, $this->source), ["6bd8d936-44b3-4db6-b72a-0dfc0775de4e" => "component_variable_6bd8d936_44b3_4db6_b72a_0dfc0775de4e", "557e363d-340b-45a6-be7e-d2651550ceef" => "component_variable_557e363d_340b_45a6_be7e_d2651550ceef", "21a57b13-1cc9-4172-b19c-e85717865527" => "component_variable_21a57b13_1cc9_4172_b19c_e85717865527", "8e474351-2291-40d7-9ebd-4c7a7e76247e" => "component_variable_8e474351_2291_40d7_9ebd_4c7a7e76247e", "f060e5bd-3315-4ef8-ad33-1873855e2936" => "component_variable_f060e5bd_3315_4ef8_ad33_1873855e2936", "6143fa18-4b90-4453-8849-0abd1da998ee" => "component_variable_6143fa18_4b90_4453_8849_0abd1da998ee", "6a18dfe7-6b3b-4a81-b1b3-79c15cc4a280" => "component_variable_6a18dfe7_6b3b_4a81_b1b3_79c15cc4a280", "7c1a369f-34cd-4932-86bc-980de5b8e13f" => "component_variable_7c1a369f_34cd_4932_86bc_980de5b8e13f", "e5ce6718-ac91-489a-8c30-2d1d975f1872" => "component_variable_e5ce6718_ac91_489a_8c30_2d1d975f1872", "d7499742-0c78-4c75-86d6-3eef9e11258c" => "component_variable_d7499742_0c78_4c75_86d6_3eef9e11258c", "e60ac45d-9fb8-4b42-b870-e74d553872a0" => "component_variable_e60ac45d_9fb8_4b42_b870_e74d553872a0", "ab8e8da6-fdd9-46d2-8f15-173c2834df80" => "component_variable_ab8e8da6_fdd9_46d2_8f15_173c2834df80", "ce7d08f1-9e65-47da-88c9-e022205891b9" => "component_variable_ce7d08f1_9e65_47da_88c9_e022205891b9", "66278b23-5ce3-4799-beb0-2f9d3bb19ce2" => "component_variable_66278b23_5ce3_4799_beb0_2f9d3bb19ce2"], "1801e353-19e3-4e46-8583-f76331a08b4d", ""), "html", null, true);
        echo " ";
    }

    public function getTemplateName()
    {
        return "__string_template__da0a5efb00e1d11a470eec46583bc563f1548e0b7f69ef81d8697ca6d4dce455";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 3,  112 => 4,  47 => 3,  44 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__da0a5efb00e1d11a470eec46583bc563f1548e0b7f69ef81d8697ca6d4dce455", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 3, "if" => 3);
        static $filters = array("escape" => 3, "merge" => 3, "render" => 4);
        static $functions = array("attach_library" => 3, "renderComponent" => 3, "processtoken" => 3);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'merge', 'render'],
                ['attach_library', 'renderComponent', 'processtoken']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
