<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* sites/default/files/cohesion/templates/component--cohesion-cpt-card-entity-reference.html.twig */
class __TwigTemplate_fe0d236359927bb6193c6f38f6ecb488ac1f94f46cd331b278ec71721ab99ef1 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->cohInstanceId(), "html", null, true);
        $context["coh_instance_class"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 2
        echo "
";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.responsiveJs"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.matchHeight"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.cohMatchHeights"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.windowscroll"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/element_templates.link"), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("cohesion/global_libraries.parallax_scrolling"), "html", null, true);
        echo " ";
        if ((($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->hasDrupalPermission([0 => "access contextual links", 1 => "access components"]) &&  !($context["isPreview"] ?? null)) &&  !(isset($context["hideContextualLinks"]) || array_key_exists("hideContextualLinks", $context)))) {
            echo " <div class=\"dx-contextual-region contextual-region\" data-dx-contextual=\"coh-component-instance-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source), "html", null, true);
            echo "\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 3, $this->source), "html", null, true);
            echo "</div> ";
        }
        echo " <div class=\"coh-column coh-component coh-component-instance-";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["componentUuid"] ?? null), 3, $this->source), "html", null, true);
        echo " contextual-component ";
        if (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "4a141bce-3f7f-46f9-a03c-8ef9b6e23017") ==  -1)) {
            echo "coh-hidden-xs";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "4a141bce-3f7f-46f9-a03c-8ef9b6e23017") ==  -2)) {
            echo "coh-col-xs";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "4a141bce-3f7f-46f9-a03c-8ef9b6e23017") ==  -3)) {
            echo "coh-col-xs-auto";
        } else {
            echo "coh-visible-xs coh-col-xs-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter(twig_split_filter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "4a141bce-3f7f-46f9-a03c-8ef9b6e23017"), "."), "-"), "html", null, true);
        }
        echo " ";
        if (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "5235a75b-8ceb-4045-9015-843a7e08263a") ==  -1)) {
            echo "coh-hidden-sm";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "5235a75b-8ceb-4045-9015-843a7e08263a") ==  -2)) {
            echo "coh-col-sm";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "5235a75b-8ceb-4045-9015-843a7e08263a") ==  -3)) {
            echo "coh-col-sm-auto";
        } else {
            echo "coh-visible-sm coh-col-sm-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter(twig_split_filter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "5235a75b-8ceb-4045-9015-843a7e08263a"), "."), "-"), "html", null, true);
        }
        echo " ";
        if (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "6fa2bc2a-132f-4be8-9106-ff508d2ff016") ==  -1)) {
            echo "coh-hidden-xl";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "6fa2bc2a-132f-4be8-9106-ff508d2ff016") ==  -2)) {
            echo "coh-col-xl";
        } elseif (($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "6fa2bc2a-132f-4be8-9106-ff508d2ff016") ==  -3)) {
            echo "coh-col-xl-auto";
        } else {
            echo "coh-visible-xl coh-col-xl-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter(twig_split_filter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "6fa2bc2a-132f-4be8-9106-ff508d2ff016"), "."), "-"), "html", null, true);
        }
        echo "\" > <div class=\"coh-container ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "b3ce4d57-e1b5-4215-a6a1-2a2b6edd8c14"));
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "9732c4d3-8460-4f67-827d-eca145d4ffff"));
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 3, $this->source), "html", null, true);
        echo " coh-ce-cpt_card_entity_reference-e9c3f582\" > ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "105267ab-7413-4358-a9d8-9ba7e27e6c6c", "#entity_type"), "html", null, true);
        $context["entity_type"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "105267ab-7413-4358-a9d8-9ba7e27e6c6c", "#view_mode"), "html", null, true);
        $context["view_mode"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        ob_start(function () { return ''; });
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "105267ab-7413-4358-a9d8-9ba7e27e6c6c", "#entity"), "html", null, true);
        $context["entity"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderContent($this->sandbox->ensureToStringAllowed(($context["entity_type"] ?? null), 3, $this->source), $this->sandbox->ensureToStringAllowed(($context["view_mode"] ?? null), 3, $this->source), $this->sandbox->ensureToStringAllowed(($context["entity"] ?? null), 3, $this->source)), "html", null, true);
        echo " </div> </div> 
";
        // line 4
        if ((isset($context["content"]) || array_key_exists("content", $context))) {
            $context["catch_cache"] = $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 4, $this->source));
        }
        ob_start(function () { return ''; });
        echo "<style>.";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["coh_instance_class"] ?? null), 4, $this->source), "html", null, true);
        echo ".coh-ce-cpt_card_entity_reference-e9c3f582 { ";
        if ( !twig_test_empty($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "b1ebb421-256b-4448-927d-44be4598c799"))) {
            echo " background-color: ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->getComponentFieldValue($context, "b1ebb421-256b-4448-927d-44be4598c799"));
            echo ";";
        }
        echo " }
</style>";
        $context["compiledCSS"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 5
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\cohesion_templates\TwigExtension\TwigExtension']->renderInlineStyle($this->sandbox->ensureToStringAllowed(($context["compiledCSS"] ?? null), 5, $this->source)));
    }

    public function getTemplateName()
    {
        return "sites/default/files/cohesion/templates/component--cohesion-cpt-card-entity-reference.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 5,  123 => 4,  46 => 3,  43 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "sites/default/files/cohesion/templates/component--cohesion-cpt-card-entity-reference.html.twig", "/home/ide/project/docroot/sites/default/files/cohesion/templates/component--cohesion-cpt-card-entity-reference.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 1, "if" => 3);
        static $filters = array("escape" => 1, "join" => 3, "split" => 3, "raw" => 3, "render" => 4);
        static $functions = array("coh_instanceid" => 1, "attach_library" => 3, "has_drupal_permission" => 3, "getComponentFieldValue" => 3, "renderContent" => 3, "renderInlineStyle" => 5);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['escape', 'join', 'split', 'raw', 'render'],
                ['coh_instanceid', 'attach_library', 'has_drupal_permission', 'getComponentFieldValue', 'renderContent', 'renderInlineStyle']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
