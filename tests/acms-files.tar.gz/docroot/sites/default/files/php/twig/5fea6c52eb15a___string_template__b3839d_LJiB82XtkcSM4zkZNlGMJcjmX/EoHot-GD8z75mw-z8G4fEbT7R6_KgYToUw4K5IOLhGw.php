<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__b3839d0b3c19527b75839cfe3fb8793c65483b91cddd62db24fb459959463500 */
class __TwigTemplate_a9f8e8b44f49811b6f355e1fc8ce8acc9b0e8732bdf34e986ac660699314108d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "/* Generated on Mon, 28 Dec 2020 23:40:14 GMT */
 .coh-style-hide-default-listing-view + .coh-row .default-listing-view { display: none; }
.coh-style-link-location-with-icon { font-size: 1rem; letter-spacing: 0.125rem; padding-top: 0.5rem; padding-right: 1.25rem; padding-bottom: 0.5rem; display: inline-block; }
.coh-style-link-location-with-icon:before { line-height: 1.0; font-weight: normal; text-transform: none; speak: none; font-variant: normal; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; font-size: 1.5rem; content: \"\\F041\"; font-family: \"icomoon\"; margin-right: 0.3125rem; vertical-align: sub; }
.coh-style-pagination-list { margin-top: 1.875rem; margin-bottom: 1.875rem; }
.coh-style-pagination-list li { padding-right: 0.625rem; display: inline-block; margin-bottom: 0; margin-left: 1rem; }
.coh-style-pagination-list li.is-active a { color: #036093; }
.coh-style-pagination-list li a { font-size: 1rem; letter-spacing: 0.0625rem; color: black; }
.coh-style-pagination-list li a:hover { color: #036093; }
.coh-style-padding-bottom---small { padding-bottom: 2.5rem; }
@media (max-width: 73.0625rem) { .coh-style-padding-bottom---small { padding-bottom: 2rem; } }
.coh-ce-6e4c0cf0 { background-color: white; }
.coh-ce-420e53ef { margin-top: -1.875rem; padding-top: 0.5rem; padding-right: 0.5rem; padding-bottom: 0.5rem; padding-left: 0.5rem; position: absolute; background-color: #f0f0f0; }
.coh-ce-cc91ecb2 { padding-top: 1.5rem; padding-right: 2rem; padding-bottom: 1.6875rem; padding-left: 2rem; }
@media (max-width: 35.25rem) { .coh-ce-cc91ecb2 { padding-top: 0.625rem; padding-right: 1.125rem; padding-bottom: 1.6875rem; padding-left: 1.125rem; } }
.coh-ce-957cc35c { padding-bottom: 0.75rem; }
.coh-ce-4ac96aec { padding-top: 16px; padding-bottom: 2px; margin-bottom: 0; font-size: 24px; line-height: 30px; }
.coh-ce-5fb71fcc { padding-bottom: 0.75rem; }
.coh-ce-88203719 { font-size: 14px; }
.coh-ce-5fb71fcc { padding-bottom: 0.75rem; }
.coh-ce-297aa362 { font-size: 12px; }
.coh-ce-297aa362:after { line-height: 1.0; font-weight: normal; text-transform: none; speak: none; font-variant: normal; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; content: \"\\F054\"; font-family: \"icomoon\"; }
.coh-ce-b0787194 { padding-top: 0.75rem; }
.coh-ce-93d0e607 { margin-bottom: 1.875rem; }
.coh-ce-2047c3db { display: -webkit-box; display: -webkit-flex; display: -ms-flexbox; display: flex; -webkit-box-align: center; -webkit-align-items: center; -ms-flex-align: center; align-items: center; }
@media (max-width: 35.25rem) { .coh-ce-2047c3db { display: none; } }
.coh-ce-c36868b8 { width: 3.4375rem; -webkit-border-radius: 1.875rem; border-radius: 1.875rem; margin-right: 1.25rem; }
.coh-ce-e74e71e5 { margin-bottom: 0.625rem; }
.coh-ce-3d1bbf1c { display: block; }
@media (max-width: 35.25rem) { .coh-ce-3d1bbf1c { margin-right: -1.5625rem; margin-left: -1.5625rem; } }
.coh-ce-3d1bbf1c > div > p { margin-top: 0; }
@media (max-width: 35.25rem) { .coh-ce-3d1bbf1c > div { margin-right: 1.5625rem; margin-left: 1.5625rem; } }
.coh-ce-ce0544c2 { width: auto; margin-right: 3rem; margin-bottom: 1.25rem; float: left; }
.coh-ce-44071a14 { background-color: white; }
.coh-ce-44071a14 .coh-row-xl .coh-col-xl-8 { padding-left: 4rem; }
@media (max-width: 63.9375rem) { .coh-ce-44071a14 .coh-row-xl .coh-col-xl-8 { padding-left: 2rem; } }
@media (max-width: 35.25rem) { .coh-ce-44071a14 .coh-row-xl .coh-col-xl-8 { padding-left: 1rem; } }
@media (max-width: 35.25rem) { .coh-ce-44071a14 .coh-row-xl .coh-col-xl-8 .coh-ce-424b9497 { padding-right: 1rem; padding-left: 1rem; } }
@media (max-width: 35.25rem) { .coh-ce-44071a14 .coh-row-xl .coh-col-xl-8 .coh-ce-fbc742db { padding-right: 1rem; padding-left: 1rem; } }
@media (max-width: 35.25rem) { .coh-ce-44071a14 .coh-row-xl .coh-col-xl-8 .coh-ce-2f126ed8 { padding-right: 1rem; padding-left: 1rem; } }
@media (max-width: 35.25rem) { .coh-ce-112e6be0 { -webkit-box-orient: vertical; -webkit-box-direction: reverse; -webkit-flex-direction: column-reverse; -ms-flex-direction: column-reverse; flex-direction: column-reverse; } }
.coh-ce-ec4adb16 { padding-bottom: 0.75rem; }
@media (max-width: 35.25rem) { .coh-ce-ec4adb16 { padding-right: 0.75rem; padding-left: 0.75rem; } }
.coh-ce-957cc35c { padding-bottom: 0.75rem; }
.coh-ce-358fb07f { font-size: 2rem; padding-top: 2rem; margin-bottom: 0; }
@media (max-width: 63.9375rem) { .coh-ce-358fb07f { font-size: 1.5rem; padding-top: 0.625rem; margin-bottom: 0; } }
@media (max-width: 35.25rem) { .coh-ce-358fb07f { font-size: 1.5rem; margin-bottom: 0; } }
.coh-ce-cc7929b6 { padding-top: 2rem; padding-bottom: 2rem; }
@media (max-width: 63.9375rem) { .coh-ce-cc7929b6 { padding-top: 0; padding-bottom: 0; } }
@media (max-width: 35.25rem) { .coh-ce-cc7929b6 { padding-top: 0; padding-bottom: 0.75rem; } }
.coh-ce-2f126ed8 { font-size: 0.75rem; }
@media (max-width: 35.25rem) { .coh-ce-2f126ed8 { font-size: 0.75rem; } }
.coh-ce-d0c287de { background-color: white; }
.coh-ce-b75fb311 { width: 100%; }
@media (max-width: 35.25rem) { .coh-ce-af9cee6f { padding-top: 0.75rem; } }
.coh-ce-60a703f { display: -webkit-box; display: -webkit-flex; display: -ms-flexbox; display: flex; -webkit-box-pack: justify; -webkit-justify-content: space-between; -ms-flex-pack: justify; justify-content: space-between; -webkit-align-content: space-between; -ms-flex-line-pack: justify; align-content: space-between; }
@media (max-width: 35.25rem) { .coh-ce-60a703f { -webkit-box-orient: vertical; -webkit-box-direction: normal; -webkit-flex-direction: column; -ms-flex-direction: column; flex-direction: column; -webkit-box-pack: initial; -webkit-justify-content: initial; -ms-flex-pack: initial; justify-content: initial; -webkit-align-content: initial; -ms-flex-line-pack: initial; align-content: initial; -webkit-box-align: initial; -webkit-align-items: initial; -ms-flex-align: initial; align-items: initial; } }
.coh-ce-cb20c9e6 { display: block; }
.coh-ce-7580d9c { text-transform: uppercase; font-size: 0.875rem; }
.coh-ce-ee07c2ef { padding-bottom: 0.75rem; }
@media (max-width: 35.25rem) { .coh-ce-ee07c2ef { padding-top: 0.75rem; } }
.coh-ce-18495c3e { font-size: 0.875rem; }
.coh-ce-5fb71fcc { padding-bottom: 0.75rem; }
.coh-ce-92471042:after { line-height: 1.0; font-weight: normal; text-transform: none; speak: none; font-variant: normal; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; content: \"\\F054\"; font-family: \"icomoon\"; }
@media (max-width: 35.25rem) { .coh-ce-5a95001 { display: none; } }
@media (max-width: 35.25rem) { .coh-ce-847fc552 { display: none; } }
.coh-ce-b0787194 { padding-top: 0.75rem; }
";
    }

    public function getTemplateName()
    {
        return "__string_template__b3839d0b3c19527b75839cfe3fb8793c65483b91cddd62db24fb459959463500";
    }

    public function getDebugInfo()
    {
        return array (  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__b3839d0b3c19527b75839cfe3fb8793c65483b91cddd62db24fb459959463500", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array();
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
