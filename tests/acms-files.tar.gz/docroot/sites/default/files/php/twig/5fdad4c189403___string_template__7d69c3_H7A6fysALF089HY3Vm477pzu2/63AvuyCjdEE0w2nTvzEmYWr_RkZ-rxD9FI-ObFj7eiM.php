<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__7d69c381406f43cfc44df418eba8b919ba8979ab3eed5831f75d8d497caa70b5 */
class __TwigTemplate_f9bf0add6b289922144d4ce0cc848a430b8a4fa50c718074ba82f9caba7eb038 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "/* Generated on Thu, 17 Dec 2020 03:49:27 GMT */
 .coh-ce-6e4c0cf0 { background-color: white; }
.coh-ce-420e53ef { margin-top: -1.875rem; padding-top: 0.5rem; padding-right: 0.5rem; padding-bottom: 0.5rem; padding-left: 0.5rem; position: absolute; background-color: #f0f0f0; }
.coh-ce-cc91ecb2 { padding-top: 1.5rem; padding-right: 2rem; padding-bottom: 1.6875rem; padding-left: 2rem; }
@media (max-width: 35.25rem) { .coh-ce-cc91ecb2 { padding-top: 0.625rem; padding-right: 1.125rem; padding-bottom: 1.6875rem; padding-left: 1.125rem; } }
.coh-ce-957cc35c { padding-bottom: 0.75rem; }
.coh-ce-4ac96aec { padding-top: 16px; padding-bottom: 2px; margin-bottom: 0; font-size: 24px; line-height: 30px; }
.coh-ce-5fb71fcc { padding-bottom: 0.75rem; }
.coh-ce-88203719 { font-size: 14px; }
.coh-ce-5fb71fcc { padding-bottom: 0.75rem; }
.coh-ce-297aa362 { font-size: 12px; }
.coh-ce-297aa362:after { line-height: 1.0; font-weight: normal; text-transform: none; speak: none; font-variant: normal; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; content: \"\\F054\"; font-family: \"icomoon\"; }
.coh-ce-b0787194 { padding-top: 0.75rem; }
.coh-ce-93d0e607 { margin-bottom: 1.875rem; }
.coh-ce-2047c3db { display: -webkit-box; display: -webkit-flex; display: -ms-flexbox; display: flex; -webkit-box-align: center; -webkit-align-items: center; -ms-flex-align: center; align-items: center; }
@media (max-width: 35.25rem) { .coh-ce-2047c3db { display: none; } }
.coh-ce-c36868b8 { width: 3.4375rem; -webkit-border-radius: 1.875rem; border-radius: 1.875rem; margin-right: 1.25rem; }
.coh-ce-e74e71e5 { margin-bottom: 0.625rem; }
.coh-ce-3d1bbf1c { display: block; }
@media (max-width: 35.25rem) { .coh-ce-3d1bbf1c { margin-right: -1.5625rem; margin-left: -1.5625rem; } }
.coh-ce-3d1bbf1c > div > p { margin-top: 0; }
@media (max-width: 35.25rem) { .coh-ce-3d1bbf1c > div { margin-right: 1.5625rem; margin-left: 1.5625rem; } }
.coh-ce-ce0544c2 { width: auto; margin-right: 3rem; margin-bottom: 1.25rem; float: left; }
";
    }

    public function getTemplateName()
    {
        return "__string_template__7d69c381406f43cfc44df418eba8b919ba8979ab3eed5831f75d8d497caa70b5";
    }

    public function getDebugInfo()
    {
        return array (  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "__string_template__7d69c381406f43cfc44df418eba8b919ba8979ab3eed5831f75d8d497caa70b5", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array();
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
